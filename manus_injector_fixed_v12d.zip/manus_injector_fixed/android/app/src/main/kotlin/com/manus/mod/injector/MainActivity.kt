package com.manus.mod.injector

import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import io.flutter.plugin.common.EventChannel
import android.os.Bundle

class MainActivity: FlutterActivity() {
    private val CHANNEL = "com.manus.mod/network_interceptor"
    private val EVENT_CHANNEL = "com.manus.mod/network_events"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        // Method channel para comandos (ativar/desativar interceptação)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call, result ->
            when (call.method) {
                "installCACert" -> {
                    // Instalar certificado CA no system store (requer root)
                    val certPath = call.argument<String>("certPath") ?: ""
                    val success = installSystemCert(certPath)
                    result.success(success)
                }
                "isRooted" -> {
                    result.success(checkRoot())
                }
                "getNetworkInfo" -> {
                    result.success(getNetworkInfo())
                }
                else -> result.notImplemented()
            }
        }
    }

    private fun checkRoot(): Boolean {
        try {
            val paths = arrayOf(
                "/system/app/Superuser.apk",
                "/sbin/su",
                "/system/bin/su",
                "/system/xbin/su",
                "/data/local/xbin/su",
                "/data/local/bin/su",
                "/system/sd/xbin/su",
                "/system/bin/failsafe/su",
                "/data/local/su",
                "/su/bin/su"
            )
            for (path in paths) {
                if (java.io.File(path).exists()) return true
            }
            val process = Runtime.getRuntime().exec(arrayOf("/system/xbin/which", "su"))
            val reader = java.io.BufferedReader(java.io.InputStreamReader(process.inputStream))
            val line = reader.readLine()
            return line != null && line.isNotEmpty()
        } catch (e: Exception) {
            return false
        }
    }

    private fun installSystemCert(certPath: String): Boolean {
        try {
            // Requer root - instala cert no system store
            val commands = arrayOf(
                "su",
                "-c",
                "mount -o rw,remount /system && " +
                "cp $certPath /system/etc/security/cacerts/ && " +
                "chmod 644 /system/etc/security/cacerts/$(basename $certPath) && " +
                "mount -o ro,remount /system"
            )
            val process = Runtime.getRuntime().exec(commands)
            return process.waitFor() == 0
        } catch (e: Exception) {
            return false
        }
    }

    private fun getNetworkInfo(): Map<String, Any> {
        val info = mutableMapOf<String, Any>()
        try {
            val connectivityManager = getSystemService(CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
            val network = connectivityManager.activeNetwork
            val capabilities = connectivityManager.getNetworkCapabilities(network)
            info["isConnected"] = network != null
            info["hasWifi"] = capabilities?.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI) ?: false
            info["hasCellular"] = capabilities?.hasTransport(android.net.NetworkCapabilities.TRANSPORT_CELLULAR) ?: false
        } catch (e: Exception) {
            info["error"] = e.message ?: "unknown"
        }
        return info
    }
}
