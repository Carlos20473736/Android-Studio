import 'dart:math';

class FakeDevice {
  final String name; // profile name
  final String brand;
  final String manufacturer;
  final String model;
  final String device;
  final String product;
  final String hardware;
  final String board;
  final String buildId;
  final String buildFingerprint;
  final String buildDisplay;
  final String buildTags;
  final String buildType;
  final String host;
  final String serial;
  final String androidId;
  final String advertisingId;
  final String imei;
  final String simSerial;
  final String subscriberId;
  final String macAddress;
  final String bluetoothMac;
  final int screenWidth;
  final int screenHeight;
  final double screenDensity;
  final int sdkInt;
  final String androidVersion;

  FakeDevice({
    required this.name,
    required this.brand,
    required this.manufacturer,
    required this.model,
    required this.device,
    required this.product,
    required this.hardware,
    required this.board,
    required this.buildId,
    required this.buildFingerprint,
    required this.buildDisplay,
    required this.buildTags,
    required this.buildType,
    required this.host,
    required this.serial,
    required this.androidId,
    required this.advertisingId,
    required this.imei,
    required this.simSerial,
    required this.subscriberId,
    required this.macAddress,
    required this.bluetoothMac,
    required this.screenWidth,
    required this.screenHeight,
    required this.screenDensity,
    required this.sdkInt,
    required this.androidVersion,
  });

  Map<String, String> toJson() => {
    'name': name,
    'brand': brand,
    'manufacturer': manufacturer,
    'model': model,
    'device': device,
    'product': product,
    'hardware': hardware,
    'board': board,
    'buildId': buildId,
    'buildFingerprint': buildFingerprint,
    'buildDisplay': buildDisplay,
    'buildTags': buildTags,
    'buildType': buildType,
    'host': host,
    'serial': serial,
    'androidId': androidId,
    'advertisingId': advertisingId,
    'imei': imei,
    'simSerial': simSerial,
    'subscriberId': subscriberId,
    'macAddress': macAddress,
    'bluetoothMac': bluetoothMac,
    'screenWidth': screenWidth.toString(),
    'screenHeight': screenHeight.toString(),
    'screenDensity': screenDensity.toString(),
    'sdkInt': sdkInt.toString(),
    'androidVersion': androidVersion,
  };

  factory FakeDevice.fromJson(Map<String, String> json) => FakeDevice(
    name: json['name'] ?? 'Unknown',
    brand: json['brand'] ?? '',
    manufacturer: json['manufacturer'] ?? '',
    model: json['model'] ?? '',
    device: json['device'] ?? '',
    product: json['product'] ?? '',
    hardware: json['hardware'] ?? '',
    board: json['board'] ?? '',
    buildId: json['buildId'] ?? '',
    buildFingerprint: json['buildFingerprint'] ?? '',
    buildDisplay: json['buildDisplay'] ?? '',
    buildTags: json['buildTags'] ?? '',
    buildType: json['buildType'] ?? '',
    host: json['host'] ?? '',
    serial: json['serial'] ?? '',
    androidId: json['androidId'] ?? '',
    advertisingId: json['advertisingId'] ?? '',
    imei: json['imei'] ?? '',
    simSerial: json['simSerial'] ?? '',
    subscriberId: json['subscriberId'] ?? '',
    macAddress: json['macAddress'] ?? '',
    bluetoothMac: json['bluetoothMac'] ?? '',
    screenWidth: int.tryParse(json['screenWidth'] ?? '') ?? 1080,
    screenHeight: int.tryParse(json['screenHeight'] ?? '') ?? 2340,
    screenDensity: double.tryParse(json['screenDensity'] ?? '') ?? 2.75,
    sdkInt: int.tryParse(json['sdkInt'] ?? '') ?? 34,
    androidVersion: json['androidVersion'] ?? '14',
  );
}

class DeviceGenerator {
  static final _rng = Random();

  static const _brands = [
    _BrandData('Samsung', 'samsung', [
      _ModelData('SM-G998B', 'o1s', 'o1sxeea', 'exynos2100', 'exynos2100'),
      _ModelData('SM-S908B', 'b0s', 'b0sxeea', 'exynos2200', 'exynos2200'),
      _ModelData('SM-A536B', 'a53x', 'a53xeea', 'exynos1280', 's5e8825'),
      _ModelData('SM-S911B', 'dm1s', 'dm1sxeea', 'exynos2300', 'exynos2300'),
      _ModelData('SM-A546B', 'a54x', 'a54xeea', 'exynos1380', 's5e8835'),
      _ModelData('SM-G991B', 'o1s', 'o1sxeea', 'exynos2100', 'exynos2100'),
      _ModelData('SM-S921B', 'e1s', 'e1sxeea', 'exynos2400', 'exynos2400'),
    ]),
    _BrandData('Xiaomi', 'Xiaomi', [
      _ModelData('M2101K6G', 'haydn', 'haydn_global', 'qcom', 'sm8350'),
      _ModelData('2201116SG', 'vili', 'vili_global', 'qcom', 'sm8350'),
      _ModelData('2203121C', 'ingres', 'ingres_global', 'qcom', 'sm7325'),
      _ModelData('23049PCD8G', 'marble', 'marble_global', 'qcom', 'sm7475'),
      _ModelData('2211133G', 'mondrian', 'mondrian_global', 'qcom', 'sm8475'),
      _ModelData('23078PND5G', 'corot', 'corot_global', 'qcom', 'sm8550'),
    ]),
    _BrandData('OnePlus', 'OnePlus', [
      _ModelData('IN2023', 'OnePlus8Pro', 'OnePlus8Pro', 'qcom', 'sm8250'),
      _ModelData('LE2123', 'OnePlus9Pro', 'OnePlus9Pro', 'qcom', 'sm8350'),
      _ModelData('NE2213', 'OnePlus10Pro', 'OnePlus10Pro', 'qcom', 'sm8450'),
      _ModelData('CPH2449', 'OnePlus11', 'OnePlus11', 'qcom', 'sm8550'),
      _ModelData('PHB110', 'OnePlus12', 'OnePlus12', 'qcom', 'sm8650'),
    ]),
    _BrandData('Google', 'google', [
      _ModelData('Pixel 7', 'panther', 'panther', 'tensor', 'gs201'),
      _ModelData('Pixel 7 Pro', 'cheetah', 'cheetah', 'tensor', 'gs201'),
      _ModelData('Pixel 8', 'shiba', 'shiba', 'tensor', 'gs301'),
      _ModelData('Pixel 8 Pro', 'husky', 'husky', 'tensor', 'gs301'),
      _ModelData('Pixel 9', 'tokay', 'tokay', 'tensor', 'zuma'),
      _ModelData('Pixel 9 Pro', 'caiman', 'caiman', 'tensor', 'zuma'),
    ]),
    _BrandData('Motorola', 'motorola', [
      _ModelData('moto g84 5G', 'bangkk', 'bangkk_g', 'qcom', 'sm6375'),
      _ModelData('moto g54 5G', 'cancunf', 'cancunf_g', 'mt6878', 'mt6878'),
      _ModelData('moto edge 40', 'lyriq', 'lyriq_g', 'mt6879', 'mt6879'),
      _ModelData('moto edge 50 pro', 'rtwo', 'rtwo_g', 'qcom', 'sm7550'),
    ]),
    _BrandData('Realme', 'realme', [
      _ModelData('RMX3630', 'RE58B2', 'RE58B2', 'mt6877', 'mt6877'),
      _ModelData('RMX3686', 'RE5889', 'RE5889', 'qcom', 'sm7325'),
      _ModelData('RMX3771', 'RE5C4F', 'RE5C4F', 'mt6895', 'mt6895'),
    ]),
  ];

  static const _buildIds = [
    'TP1A.220624.014',
    'TQ3A.230901.001',
    'TQ3A.230905.001',
    'UP1A.231005.007',
    'UP1A.231105.001',
    'AP2A.240805.005',
    'AP2A.240905.003',
    'BP1A.250305.001',
  ];

  static const _screens = [
    _ScreenData(1080, 2340, 2.625),
    _ScreenData(1080, 2400, 2.75),
    _ScreenData(1440, 3120, 3.5),
    _ScreenData(1284, 2778, 3.0),
    _ScreenData(1080, 2340, 2.625),
    _ScreenData(1080, 2460, 2.75),
    _ScreenData(1344, 2992, 3.0),
  ];

  static const _sdkVersions = [
    _SdkData(33, '13'),
    _SdkData(34, '14'),
    _SdkData(35, '15'),
  ];

  static String _randomHex(int length) {
    const chars = '0123456789abcdef';
    return List.generate(length, (_) => chars[_rng.nextInt(chars.length)]).join();
  }

  static String _randomDigits(int length) {
    return List.generate(length, (_) => _rng.nextInt(10).toString()).join();
  }

  static String _randomMac() {
    final parts = List.generate(6, (_) => _randomHex(2));
    // Locally administered, unicast
    var first = int.parse(parts[0], radix: 16);
    first = (first | 0x02) & 0xFE;
    parts[0] = first.toRadixString(16).padLeft(2, '0');
    return parts.join(':');
  }

  static String _randomUuid() {
    return '${_randomHex(8)}-${_randomHex(4)}-4${_randomHex(3)}-${_randomHex(4)}-${_randomHex(12)}';
  }

  static T _pick<T>(List<T> list) => list[_rng.nextInt(list.length)];

  static FakeDevice generate({String? profileName}) {
    final brand = _pick(_brands);
    final model = _pick(brand.models);
    final buildId = _pick(_buildIds);
    final screen = _pick(_screens);
    final sdk = _pick(_sdkVersions);
    final serial = _randomHex(16).toUpperCase();

    final fingerprint =
        '${brand.manufacturer}/${model.product}/${model.device}:${sdk.version}/$buildId/${_randomDigits(8)}:user/release-keys';

    return FakeDevice(
      name: profileName ?? '${brand.name} ${model.modelName}',
      brand: brand.name,
      manufacturer: brand.manufacturer,
      model: model.modelName,
      device: model.device,
      product: model.product,
      hardware: model.hardware,
      board: model.board,
      buildId: buildId,
      buildFingerprint: fingerprint,
      buildDisplay: buildId,
      buildTags: 'release-keys',
      buildType: 'user',
      host: 'build${_randomDigits(3)}.google.com',
      serial: serial,
      androidId: _randomHex(16),
      advertisingId: _randomUuid(),
      imei: _randomDigits(15),
      simSerial: _randomDigits(20),
      subscriberId: _randomDigits(15),
      macAddress: _randomMac(),
      bluetoothMac: _randomMac(),
      screenWidth: screen.width,
      screenHeight: screen.height,
      screenDensity: screen.density,
      sdkInt: sdk.sdkInt,
      androidVersion: sdk.version,
    );
  }
}

class _BrandData {
  final String name;
  final String manufacturer;
  final List<_ModelData> models;
  const _BrandData(this.name, this.manufacturer, this.models);
}

class _ModelData {
  final String modelName;
  final String device;
  final String product;
  final String hardware;
  final String board;
  const _ModelData(this.modelName, this.device, this.product, this.hardware, this.board);
}

class _ScreenData {
  final int width;
  final int height;
  final double density;
  const _ScreenData(this.width, this.height, this.density);
}

class _SdkData {
  final int sdkInt;
  final String version;
  const _SdkData(this.sdkInt, this.version);
}
