import 'dart:convert';
import 'package:http/http.dart' as http;
import 'anti_detect.dart';
import 'webview_api_bridge.dart';

/// Estado da autenticação completa
class AuthState {
  String? googleEmail;
  String? googleName;
  String? googlePhotoUrl;
  String? sessionToken;
  String? sessionCookieName;
  Map<String, String> cookies = {};
  Map<String, dynamic>? userInfo;
  String? userId;
  String? displayName;
  bool isBlocked = false;
  String? blockMessage;

  bool get hasSession => sessionToken != null && sessionToken!.isNotEmpty;
  bool get hasUserInfo => userInfo != null;
  bool get isFullyAuthenticated => hasSession && hasUserInfo;

  Map<String, String> toTokenMap() {
    final map = <String, String>{};
    if (sessionToken != null) map['SESSION_TOKEN'] = sessionToken!;
    if (sessionCookieName != null) map['COOKIE_NAME'] = sessionCookieName!;
    if (googleEmail != null) map['EMAIL'] = googleEmail!;
    if (googleName != null) map['NAME'] = googleName!;
    if (userId != null) map['USER_ID'] = userId!;
    if (cookies.isNotEmpty) {
      map['ALL_COOKIES'] = cookies.entries
          .map((e) =>
              '${e.key}=${e.value.length > 50 ? '${e.value.substring(0, 50)}...' : e.value}')
          .join('; ');
    }
    return map;
  }
}

/// Log de cada etapa da autenticação
class AuthLog {
  final String step;
  final String status;
  final String message;
  final DateTime timestamp;
  final Map<String, dynamic>? details;

  AuthLog({
    required this.step,
    required this.status,
    required this.message,
    this.details,
  }) : timestamp = DateTime.now();
}

/// Serviço de autenticação v11d - HTTP Direto (sem WebView Bridge para API calls)
///
/// Mudança principal: UserInfo e outras chamadas API são feitas via HTTP Dart
/// usando o session_id cookie capturado, ao invés do WebView Bridge.
/// O WebView Bridge ainda pode ser usado como fallback.
class AuthService {
  static const String _apiBase = 'https://api.manus.im';

  WebViewApiBridgeController? _bridge;
  final AuthState state = AuthState();
  final List<AuthLog> logs = [];
  late final DeviceProfile profile;

  AuthService() {
    profile = generateDeviceProfile();
  }

  /// Cria um AuthService com um perfil de dispositivo específico
  AuthService.withProfile(DeviceProfile customProfile) {
    profile = customProfile;
  }

  void setBridge(WebViewApiBridgeController bridge) {
    _bridge = bridge;
  }

  void _log(String step, String status, String message,
      {Map<String, dynamic>? details}) {
    logs.add(AuthLog(
        step: step, status: status, message: message, details: details));
  }

  /// Gera headers completos para chamadas autenticadas
  Map<String, String> _buildAuthHeaders() {
    final headers = profile.generateHeaders(includeDCR: true);
    // Adicionar Authorization Bearer com o session token
    if (state.sessionToken != null && state.sessionToken!.isNotEmpty) {
      headers['Authorization'] = 'Bearer ${state.sessionToken!}';
    }
    // Também enviar cookies (para compatibilidade)
    if (state.cookies.isNotEmpty) {
      final cookieStr = state.cookies.entries
          .map((e) => '${e.key}=${e.value}')
          .join('; ');
      headers['Cookie'] = cookieStr;
    }
    return headers;
  }

  /// Chamada HTTP direta para a API do Manus (Connect protocol)
  Future<Map<String, dynamic>> callConnectDirect(
    String servicePath, {
    Map<String, dynamic>? body,
  }) async {
    if (state.isBlocked) {
      return {'error': true, 'message': 'Conta bloqueada.', 'blocked': true};
    }

    try {
      final headers = _buildAuthHeaders();
      final resp = await http
          .post(
            Uri.parse('$_apiBase/$servicePath'),
            headers: headers,
            body: jsonEncode(body ?? {}),
          )
          .timeout(const Duration(seconds: 15));

      if (resp.statusCode == 200) {
        try {
          final data = jsonDecode(resp.body);
          return data is Map<String, dynamic> ? data : {'data': data};
        } catch (_) {
          return {'raw_body': resp.body};
        }
      }

      // Verificar bloqueio
      if (resp.statusCode == 403) {
        final bodyLower = resp.body.toLowerCase();
        if (bodyLower.contains('blocked') ||
            bodyLower.contains('user_is_blocked')) {
          state.isBlocked = true;
          state.blockMessage = resp.body;
          return {
            'error': true,
            'blocked': true,
            'status': resp.statusCode,
            'message': resp.body,
          };
        }
      }

      return {
        'error': true,
        'status': resp.statusCode,
        'message': resp.body,
      };
    } catch (e) {
      return {'error': true, 'message': 'Erro HTTP: $e'};
    }
  }

  /// Step 1: Obter URL de redirect do Google OAuth
  Future<String?> getOauth2AuthorizeUrl() async {
    _log('OAuth2 Authorize', 'info', 'Obtendo URL de redirect do Google...');
    _log('OAuth2 Authorize', 'info',
        'Client ID: ${profile.clientId}, DCR: ativo');

    try {
      final headers = profile.generateHeaders(includeDCR: true);

      final resp = await http
          .post(
            Uri.parse(
                '$_apiBase/user.v1.UserAuthPublicService/Oauth2Authorize'),
            headers: headers,
            body: jsonEncode({
              'type': 'O_AUTH2_TYPE_GOOGLE',
              'authCommand': {
                'locale': profile.locale,
                'tz': profile.timezone,
                'tzOffset': profile.timezoneOffset.toString(),
                'firstEntry': '1',
              },
            }),
          )
          .timeout(const Duration(seconds: 10));

      if (resp.statusCode == 200) {
        final data = jsonDecode(resp.body);
        final redirectUrl = data['redirectUrl'] as String?;
        if (redirectUrl != null && redirectUrl.isNotEmpty) {
          _log('OAuth2 Authorize', 'success', 'URL obtida!', details: {
            'url_length': redirectUrl.length,
            'has_state': redirectUrl.contains('state='),
          });
          return redirectUrl;
        }
      }

      _log('OAuth2 Authorize', 'error',
          'Erro ${resp.statusCode}: ${resp.body}');
      return null;
    } catch (e) {
      _log('OAuth2 Authorize', 'error', 'Exceção: $e');
      return null;
    }
  }

  /// Step 2: Processar cookies recebidos após o callback do Google
  void processSessionCookies(Map<String, String> cookies) {
    state.cookies = cookies;

    if (cookies.containsKey('session_id') &&
        cookies['session_id']!.isNotEmpty) {
      state.sessionToken = cookies['session_id'];
      state.sessionCookieName = 'session_id';
      _log('Session', 'success', 'Cookie session_id encontrado', details: {
        'token_length': cookies['session_id']!.length,
      });
    } else {
      String? longestKey;
      int longestLen = 0;
      for (final entry in cookies.entries) {
        if (entry.value.length > longestLen) {
          longestLen = entry.value.length;
          longestKey = entry.key;
        }
      }
      if (longestKey != null && longestLen > 20) {
        state.sessionToken = cookies[longestKey];
        state.sessionCookieName = longestKey;
        _log('Session', 'info',
            'Usando cookie $longestKey ($longestLen chars) como sessão');
      } else {
        _log('Session', 'warning',
            'Nenhum cookie de sessão encontrado');
      }
    }

    _log('Session', 'info', 'Cookies processados', details: {
      'total_cookies': cookies.length,
      'cookie_names': cookies.keys.toList(),
    });
  }

  void processSessionToken(String token) {
    state.sessionToken = token;
    _log('Session', 'success',
        'Token de sessão configurado (${token.length} chars)');
  }

  /// Step 3: Buscar informações do usuário via HTTP direto
  Future<bool> fetchUserInfo() async {
    if (state.isBlocked) {
      _log('User Info', 'error', 'Conta bloqueada, não tentando novamente');
      return false;
    }

    if (!state.hasSession) {
      _log('User Info', 'error', 'Sem token de sessão');
      return false;
    }

    _log('User Info', 'info',
        'Buscando UserInfo via HTTP direto (com DCR + Cookie)...');

    try {
      final result =
          await callConnectDirect('user.v1.UserService/UserInfo');

      if (result.containsKey('error') && result['error'] == true) {
        if (result['blocked'] == true) {
          state.isBlocked = true;
          state.blockMessage = result['message'] as String?;
          _log('User Info', 'error', 'CONTA BLOQUEADA!', details: result);
          return false;
        }
        _log('User Info', 'error', 'Erro na chamada', details: result);
        return false;
      }

      return _processUserInfoResponse(result);
    } catch (e) {
      _log('User Info', 'error', 'Exceção: $e');
      return false;
    }
  }

  bool _processUserInfoResponse(Map<String, dynamic> data) {
    state.userInfo = data;
    state.googleEmail =
        data['email'] as String? ?? state.googleEmail;
    state.googleName = data['name'] as String? ??
        data['displayName'] as String? ??
        state.googleName;
    state.userId = data['userId'] as String? ??
        data['id'] as String? ??
        data['openId'] as String?;
    state.displayName = data['displayname'] as String? ??
        data['displayName'] as String? ??
        data['name'] as String?;

    _log('User Info', 'success', 'UserInfo obtido via HTTP direto!',
        details: {
          'email': state.googleEmail,
          'name': state.displayName,
          'userId': state.userId,
          'fields': data.keys.toList(),
        });
    return true;
  }

  /// Chamada genérica - tenta HTTP direto primeiro, fallback para Bridge
  Future<Map<String, dynamic>?> callConnect(String servicePath,
      {Map<String, dynamic>? body}) async {
    // Tentar HTTP direto primeiro (mais confiável)
    final result = await callConnectDirect(servicePath, body: body);
    if (result['error'] != true) return result;

    // Fallback para WebView Bridge se disponível
    if (_bridge != null && _bridge!.isReady) {
      _log('API', 'info', 'Fallback para WebView Bridge...');
      return _bridge!.callApi(servicePath, body: body);
    }

    return result;
  }

  Future<void> runPostLoginFlow({
    Function(String step, String status)? onProgress,
  }) async {
    onProgress?.call('User Info', 'loading');
    final userInfoOk = await fetchUserInfo();
    onProgress?.call('User Info', userInfoOk ? 'success' : 'error');
  }
}
