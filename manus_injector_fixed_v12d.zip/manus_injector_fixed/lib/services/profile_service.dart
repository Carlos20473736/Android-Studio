import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/fake_device.dart';

class ProfileService {
  static const _profilesKey = 'saved_profiles';
  static const _activeProfileKey = 'active_profile';

  /// Salva um perfil de dispositivo
  static Future<void> saveProfile(FakeDevice device) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final profiles = await loadProfiles();
      profiles.removeWhere((p) => p.name == device.name);
      profiles.add(device);
      final jsonList = profiles.map((p) => jsonEncode(p.toJson())).toList();
      await prefs.setStringList(_profilesKey, jsonList);
    } catch (_) {}
  }

  /// Carrega todos os perfis salvos
  static Future<List<FakeDevice>> loadProfiles() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final jsonList = prefs.getStringList(_profilesKey) ?? [];
      return jsonList.map((jsonStr) {
        final map = Map<String, String>.from(jsonDecode(jsonStr) as Map);
        return FakeDevice.fromJson(map);
      }).toList();
    } catch (_) {
      return [];
    }
  }

  /// Deleta um perfil
  static Future<void> deleteProfile(String name) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final profiles = await loadProfiles();
      profiles.removeWhere((p) => p.name == name);
      final jsonList = profiles.map((p) => jsonEncode(p.toJson())).toList();
      await prefs.setStringList(_profilesKey, jsonList);
    } catch (_) {}
  }

  /// Salva o perfil ativo (ultimo aplicado)
  static Future<void> setActiveProfile(FakeDevice device) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_activeProfileKey, jsonEncode(device.toJson()));
    } catch (_) {}
  }

  /// Carrega o perfil ativo
  static Future<FakeDevice?> getActiveProfile() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final jsonStr = prefs.getString(_activeProfileKey);
      if (jsonStr == null) return null;
      final map = Map<String, String>.from(jsonDecode(jsonStr) as Map);
      return FakeDevice.fromJson(map);
    } catch (_) {
      return null;
    }
  }
}
