import 'dart:io';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import '../models/fake_device.dart';
import 'root_service.dart';

class InjectionService {
  static const _configPath = '/data/local/tmp/manus_mod_config.txt';
  static const _statusPath = '/data/local/tmp/manus_mod_status.txt';
  static const _hookLogPath = '/data/local/tmp/manus_mod_hooklog.txt';
  static const _hookLibName = 'libmanus_hook.so';
  static const _injectorName = 'injector';
  static const _installDir = '/data/local/tmp/manus_mod';
  static const _manusPackage = 'tech.butterfly.app';

  /// Detecta a arquitetura do dispositivo
  static Future<String> getDeviceArch() async {
    try {
      final result = await RootService.exec('getprop ro.product.cpu.abi');
      final abi = result.output.trim();
      if (abi.contains('x86_64')) return 'x86_64';
      if (abi.contains('x86')) return 'x86';
      if (abi.contains('arm64') || abi.contains('aarch64')) return 'arm64-v8a';
      if (abi.contains('arm')) return 'armeabi-v7a';
      return 'x86_64';
    } catch (e) {
      return 'x86_64';
    }
  }

  /// Instala os binarios nativos extraindo dos Flutter assets
  static Future<List<String>> installBinaries() async {
    final logs = <String>[];
    final installDir = _installDir;
    final hookLibName = _hookLibName;
    final injectorName = _injectorName;

    try {
      final arch = await getDeviceArch();
      logs.add('Arquitetura detectada: $arch');

      // Criar diretorio de instalacao com root
      var r = await RootService.exec('mkdir -p $installDir && chmod 777 $installDir');
      if (!r.success) {
        logs.add('[ERRO] Falha ao criar diretorio: ${r.error}');
        return logs;
      }
      logs.add('[OK] Diretorio $installDir criado');

      // Obter diretorio de cache do app
      Directory? cacheDir;
      try {
        cacheDir = await getTemporaryDirectory();
      } catch (e) {
        try {
          cacheDir = await getApplicationDocumentsDirectory();
        } catch (e2) {
          logs.add('[ERRO] Nao foi possivel obter diretorio temporario: $e2');
          return logs;
        }
      }
      final tmpDir = cacheDir!.path;
      logs.add('Diretorio temporario: $tmpDir');

      logs.add('Extraindo binarios dos assets...');
      try {
        // Extrair hook lib
        final hookAssetPath = 'assets/native/$arch/$hookLibName';
        logs.add('Carregando asset: $hookAssetPath');
        final hookData = await rootBundle.load(hookAssetPath);
        final hookBytes = hookData.buffer.asUint8List();
        final hookTmpPath = '$tmpDir/$hookLibName';
        final hookTmpFile = File(hookTmpPath);
        await hookTmpFile.writeAsBytes(hookBytes, flush: true);
        logs.add('[OK] $hookLibName salvo (${hookBytes.length} bytes)');

        final hookDestPath = '$installDir/$hookLibName';
        r = await RootService.exec('cp "$hookTmpPath" "$hookDestPath"');
        if (!r.success) {
          r = await RootService.exec('cat "$hookTmpPath" > "$hookDestPath"');
        }
        logs.add(r.success ? '[OK] $hookLibName instalado' : '[ERRO] ${r.error}');

        // Extrair injector
        final injAssetPath = 'assets/native/$arch/$injectorName';
        logs.add('Carregando asset: $injAssetPath');
        final injData = await rootBundle.load(injAssetPath);
        final injBytes = injData.buffer.asUint8List();
        final injTmpPath = '$tmpDir/$injectorName';
        final injTmpFile = File(injTmpPath);
        await injTmpFile.writeAsBytes(injBytes, flush: true);
        logs.add('[OK] $injectorName salvo (${injBytes.length} bytes)');

        final injDestPath = '$installDir/$injectorName';
        r = await RootService.exec('cp "$injTmpPath" "$injDestPath"');
        if (!r.success) {
          r = await RootService.exec('cat "$injTmpPath" > "$injDestPath"');
        }
        logs.add(r.success ? '[OK] $injectorName instalado' : '[ERRO] ${r.error}');

        try { await hookTmpFile.delete(); } catch (_) {}
        try { await injTmpFile.delete(); } catch (_) {}
      } catch (e) {
        logs.add('[ERRO] Falha ao extrair dos assets: $e');
        return logs;
      }

      // Permissoes
      r = await RootService.exec(
        'chmod 755 $installDir/$injectorName && '
        'chmod 755 $installDir/$hookLibName'
      );
      logs.add(r.success ? '[OK] Permissoes configuradas' : '[ERRO] Permissoes: ${r.error}');

      // Verificar
      r = await RootService.exec('ls -la $installDir/');
      logs.add('');
      logs.add('Arquivos instalados:');
      for (final line in r.output.split('\n')) {
        if (line.trim().isNotEmpty) logs.add('  $line');
      }

      // Verificar tipo do arquivo
      r = await RootService.exec('file $installDir/$hookLibName 2>/dev/null');
      logs.add('Tipo: ${r.output.trim()}');

    } catch (e) {
      logs.add('[ERRO] Excecao geral: $e');
    }

    return logs;
  }

  /// Escreve o arquivo de configuracao
  static Future<bool> writeConfig(FakeDevice device) async {
    try {
      final configPath = _configPath;
      final lines = [
        'active=1',
        'android_id=${device.androidId}',
        'model=${device.model}',
        'brand=${device.brand}',
        'manufacturer=${device.manufacturer}',
        'device=${device.device}',
        'product=${device.product}',
        'hardware=${device.hardware}',
        'board=${device.board}',
        'build_id=${device.buildId}',
        'fingerprint=${device.buildFingerprint}',
        'serial=${device.serial}',
        'imei=${device.imei}',
        'mac=${device.macAddress}',
        'bt_mac=${device.bluetoothMac}',
        'sdk_int=${device.sdkInt}',
      ];

      // Usar heredoc para escrever config (mais confiavel que echo)
      final content = lines.join('\n');
      final r = await RootService.exec(
        "cat > $configPath << 'MANUS_EOF'\n$content\nMANUS_EOF"
      );

      if (r.success) {
        await RootService.exec('chmod 666 $configPath');
        return true;
      }

      // Fallback: printf linha por linha
      await RootService.exec('rm -f $configPath');
      for (final line in lines) {
        final escaped = line.replaceAll('"', '\\"');
        await RootService.exec('printf "%s\\n" "$escaped" >> $configPath');
      }
      await RootService.exec('chmod 666 $configPath');

      // Verificar se foi escrito
      final check = await RootService.exec('wc -l $configPath 2>/dev/null');
      return check.success && check.output.trim().isNotEmpty;
    } catch (e) {
      return false;
    }
  }

  /// Encontra o PID do Manus
  static Future<int?> getManusProcessId() async {
    try {
      final pkg = _manusPackage;
      // Tentar pidof primeiro
      var r = await RootService.exec('pidof $pkg');
      if (r.success && r.output.trim().isNotEmpty) {
        final pids = r.output.trim().split(RegExp(r'\s+'));
        return int.tryParse(pids.first);
      }
      // Fallback: ps + grep
      r = await RootService.exec("ps -A | grep $pkg | grep -v grep | head -1");
      if (r.success && r.output.trim().isNotEmpty) {
        final parts = r.output.trim().split(RegExp(r'\s+'));
        if (parts.length >= 2) {
          return int.tryParse(parts[1]);
        }
      }
      return null;
    } catch (e) {
      return null;
    }
  }

  /// Verifica se o hook ja esta ativo no processo
  static Future<bool> isHookActive() async {
    try {
      final pid = await getManusProcessId();
      if (pid == null) return false;
      final r = await RootService.exec('cat /proc/$pid/maps 2>/dev/null | grep manus_hook');
      return r.success && r.output.contains('manus_hook');
    } catch (e) {
      return false;
    }
  }

  /// Verificacao detalhada pos-injecao
  static Future<List<String>> verifyInjection() async {
    final logs = <String>[];
    final pkg = _manusPackage;
    final configPath = _configPath;
    final statusPath = _statusPath;
    final hookLogPath = _hookLogPath;

    final pid = await getManusProcessId();
    if (pid == null) {
      logs.add('[VERIFICACAO] Manus nao esta rodando');

      // Tentar iniciar o Manus
      logs.add('Tentando iniciar Manus...');
      final r = await RootService.exec('am start -n $pkg/.MainActivity 2>&1');
      logs.add('am start: ${r.output.trim()}');
      await Future.delayed(const Duration(seconds: 5));

      final pid2 = await getManusProcessId();
      if (pid2 == null) {
        logs.add('[FALHA] Manus nao iniciou');
        return logs;
      }
      logs.add('[OK] Manus iniciou com PID: $pid2');
      return _verifyPid(pid2, logs);
    }

    return _verifyPid(pid, logs);
  }

  static Future<List<String>> _verifyPid(int pid, List<String> logs) async {
    final statusPath = _statusPath;
    final hookLogPath = _hookLogPath;
    final configPath = _configPath;
    final pkg = _manusPackage;

    logs.add('=== VERIFICACAO (PID: $pid) ===');

    // 1. /proc/pid/maps
    logs.add('');
    logs.add('--- /proc/$pid/maps ---');
    var r = await RootService.exec('cat /proc/$pid/maps 2>/dev/null | grep -i manus_hook');
    if (r.success && r.output.trim().isNotEmpty) {
      logs.add('[OK] libmanus_hook.so ENCONTRADA no processo!');
      for (final line in r.output.split('\n').where((l) => l.isNotEmpty).take(3)) {
        logs.add('  $line');
      }
    } else {
      logs.add('[FALHA] libmanus_hook.so NAO encontrada em /proc/$pid/maps');
    }

    // 2. Status file
    logs.add('');
    logs.add('--- Status File ---');
    r = await RootService.exec('cat $statusPath 2>/dev/null');
    if (r.success && r.output.trim().isNotEmpty) {
      logs.add('[OK] Status file encontrado!');
      for (final line in r.output.split('\n').where((l) => l.isNotEmpty)) {
        logs.add('  $line');
      }
    } else {
      logs.add('[FALHA] Status file nao encontrado ou vazio');
    }

    // 3. Hook log
    logs.add('');
    logs.add('--- Hook Log ---');
    r = await RootService.exec('cat $hookLogPath 2>/dev/null');
    if (r.success && r.output.trim().isNotEmpty) {
      logs.add('[OK] Hook log encontrado!');
      for (final line in r.output.split('\n').where((l) => l.isNotEmpty).take(20)) {
        logs.add('  $line');
      }
    } else {
      logs.add('[INFO] Hook log nao criado');
    }

    // 4. Logcat
    logs.add('');
    logs.add('--- Logcat (ManusHook) ---');
    r = await RootService.exec('logcat -d -s ManusHook 2>/dev/null | tail -30');
    if (r.success && r.output.trim().isNotEmpty) {
      for (final line in r.output.split('\n').where((l) => l.isNotEmpty).take(30)) {
        logs.add('  $line');
      }
    } else {
      logs.add('[INFO] Nenhum log do ManusHook no logcat');
    }

    // 5. Verificar LD_PRELOAD no environ
    logs.add('');
    logs.add('--- LD_PRELOAD check ---');
    r = await RootService.exec('cat /proc/$pid/environ 2>/dev/null | tr "\\0" "\\n" | grep -i preload');
    if (r.success && r.output.trim().isNotEmpty) {
      logs.add('[OK] LD_PRELOAD ativo: ${r.output.trim()}');
    } else {
      logs.add('[INFO] LD_PRELOAD nao detectado no environ');
    }

    // 6. Verificar ld.so.preload
    logs.add('');
    logs.add('--- ld.so.preload ---');
    r = await RootService.exec('cat /etc/ld.so.preload 2>/dev/null; cat /system/etc/ld.so.preload 2>/dev/null');
    if (r.success && r.output.trim().isNotEmpty) {
      logs.add('Conteudo ld.so.preload:');
      for (final line in r.output.split('\n').where((l) => l.isNotEmpty)) {
        logs.add('  $line');
      }
    } else {
      logs.add('[INFO] ld.so.preload vazio ou inexistente');
    }

    // 7. Config file
    logs.add('');
    logs.add('--- Config File ---');
    r = await RootService.exec('cat $configPath 2>/dev/null');
    if (r.success && r.output.trim().isNotEmpty) {
      final lineCount = r.output.trim().split('\n').length;
      logs.add('[OK] Config file presente ($lineCount linhas)');
      for (final line in r.output.split('\n').where((l) => l.isNotEmpty).take(5)) {
        logs.add('  $line');
      }
      if (lineCount > 5) logs.add('  ...');
    } else {
      logs.add('[FALHA] Config file nao encontrado');
    }

    // Resumo
    final hookInMaps = await isHookActive();
    logs.add('');
    if (hookInMaps) {
      logs.add('========================================');
      logs.add('  RESULTADO: HOOK ATIVO E FUNCIONANDO!');
      logs.add('========================================');
    } else {
      r = await RootService.exec('cat $statusPath 2>/dev/null');
      if (r.success && r.output.contains('active')) {
        logs.add('========================================');
        logs.add('  RESULTADO: HOOK ATIVO (via status file)');
        logs.add('========================================');
      } else {
        logs.add('========================================');
        logs.add('  RESULTADO: HOOK NAO CONFIRMADO');
        logs.add('  Verifique os logs acima para detalhes');
        logs.add('========================================');
      }
    }

    return logs;
  }

  /// Fluxo completo de injecao
  static Future<List<String>> fullInject(FakeDevice device) async {
    final logs = <String>[];
    final installDir = _installDir;
    final hookLibName = _hookLibName;
    final injectorName = _injectorName;
    final pkg = _manusPackage;
    final configPath = _configPath;
    final statusPath = _statusPath;
    final hookLogPath = _hookLogPath;

    try {
      // === PREPARACAO ===
      logs.add('=== PREPARANDO ===');

      // Limpar logs anteriores
      await RootService.exec('rm -f $statusPath $hookLogPath 2>/dev/null');
      await RootService.exec('logcat -c 2>/dev/null');

      // Desabilitar SELinux
      logs.add('Desabilitando SELinux...');
      await RootService.exec('setenforce 0 2>/dev/null');
      var r = await RootService.exec('getenforce 2>/dev/null');
      logs.add('SELinux: ${r.output.trim()}');

      // Fechar Manus
      logs.add('Fechando Manus...');
      await RootService.exec('am force-stop $pkg');
      await Future.delayed(const Duration(seconds: 2));
      logs.add('[OK] Manus fechado');

      // Limpar dados do Manus
      logs.add('Limpando dados do Manus...');
      r = await RootService.exec('pm clear $pkg 2>&1');
      logs.add(r.success ? '[OK] Dados do Manus limpos' : '[AVISO] pm clear: ${r.output} ${r.error}');

      // Mudar Android ID
      logs.add('Mudando Android ID: ${device.androidId}');
      r = await RootService.exec('settings put secure android_id ${device.androidId} 2>&1');
      logs.add(r.success ? '[OK] Android ID alterado' : '[AVISO] settings put: ${r.output} ${r.error}');

      // Tentar resetprop (Magisk)
      r = await RootService.exec('which resetprop 2>/dev/null');
      if (r.success && r.output.trim().isNotEmpty) {
        logs.add('Magisk detectado! Aplicando resetprop...');
        final props = {
          'ro.product.model': device.model,
          'ro.product.brand': device.brand,
          'ro.product.manufacturer': device.manufacturer,
          'ro.product.device': device.device,
          'ro.product.name': device.product,
          'ro.build.display.id': device.buildDisplay,
          'ro.build.id': device.buildId,
          'ro.build.fingerprint': device.buildFingerprint,
          'ro.serialno': device.serial,
          'ro.hardware': device.hardware,
          'ro.product.board': device.board,
        };
        for (final entry in props.entries) {
          await RootService.exec('resetprop ${entry.key} "${entry.value}"');
        }
        logs.add('[OK] ${props.length} props alteradas via resetprop');
      } else {
        logs.add('[INFO] resetprop nao disponivel (sem Magisk)');
      }

      // Escrever config
      logs.add('Escrevendo config do hook...');
      final configOk = await writeConfig(device);
      logs.add(configOk ? '[OK] Config escrita em $configPath' : '[ERRO] Falha ao escrever config');

      // Verificar config
      r = await RootService.exec('wc -l $configPath 2>/dev/null');
      logs.add('Config: ${r.output.trim()}');
      r = await RootService.exec('head -3 $configPath 2>/dev/null');
      logs.add('Primeiras linhas: ${r.output.trim()}');

      // Verificar/instalar binarios
      final libPath = '$installDir/$hookLibName';
      r = await RootService.exec('test -f $libPath && echo OK');
      if (!r.success || !r.output.contains('OK')) {
        logs.add('');
        logs.add('=== INSTALANDO BINARIOS ===');
        final installLogs = await installBinaries();
        logs.addAll(installLogs);
      } else {
        logs.add('[OK] Binarios ja instalados');
        r = await RootService.exec('file $libPath 2>/dev/null');
        logs.add('Tipo lib: ${r.output.trim()}');
      }

      // ============================================================
      // METODO 1: /system/lib + ld.so.preload (PRINCIPAL)
      // ============================================================
      logs.add('');
      logs.add('=== METODO 1: ld.so.preload (PRINCIPAL) ===');

      final arch = await getDeviceArch();
      final systemLibDir = arch.contains('64') ? '/system/lib64' : '/system/lib';
      final systemLibPath = '$systemLibDir/$hookLibName';

      // Remontar /system como rw
      logs.add('Remontando /system como rw...');
      await RootService.exec('mount -o rw,remount /system 2>/dev/null');
      await RootService.exec('mount -o rw,remount / 2>/dev/null');

      // Copiar lib para /system/lib64
      r = await RootService.exec('cp $libPath $systemLibPath 2>&1');
      if (r.success) {
        logs.add('[OK] lib copiada para $systemLibPath');
      } else {
        logs.add('[AVISO] cp falhou: ${r.output} ${r.error}');
        r = await RootService.exec('dd if=$libPath of=$systemLibPath 2>&1');
        logs.add(r.success ? '[OK] lib copiada via dd' : '[ERRO] dd tambem falhou');
      }

      // Permissoes e contexto SELinux
      await RootService.exec('chmod 644 $systemLibPath 2>/dev/null');
      await RootService.exec('chown root:root $systemLibPath 2>/dev/null');
      await RootService.exec('chcon u:object_r:system_lib_file:s0 $systemLibPath 2>/dev/null');

      // Verificar que a lib esta la
      r = await RootService.exec('ls -la $systemLibPath 2>/dev/null');
      logs.add('Verificacao: ${r.output.trim()}');

      // Limpar ld.so.preload existente
      await RootService.exec('sed -i "/manus_hook/d" /etc/ld.so.preload 2>/dev/null');
      await RootService.exec('sed -i "/manus_hook/d" /system/etc/ld.so.preload 2>/dev/null');

      // Adicionar ao ld.so.preload
      r = await RootService.exec('echo "$systemLibPath" >> /etc/ld.so.preload 2>/dev/null');
      if (!r.success) {
        r = await RootService.exec('echo "$systemLibPath" >> /system/etc/ld.so.preload 2>/dev/null');
      }
      logs.add(r.success ? '[OK] Adicionado ao ld.so.preload' : '[AVISO] ld.so.preload: ${r.error}');

      // Verificar ld.so.preload
      r = await RootService.exec('cat /etc/ld.so.preload 2>/dev/null');
      logs.add('ld.so.preload: ${r.output.trim()}');

      // Iniciar Manus
      logs.add('');
      logs.add('Iniciando Manus...');
      r = await RootService.exec('am start -n $pkg/.MainActivity 2>&1');
      logs.add('am start: ${r.output.trim()}');

      logs.add('Aguardando 8 segundos...');
      await Future.delayed(const Duration(seconds: 8));

      var hookActive = await isHookActive();
      if (hookActive) {
        logs.add('');
        logs.add('[OK] *** METODO 1 FUNCIONOU! Hook ativo! ***');
        final verifyLogs = await verifyInjection();
        logs.addAll(verifyLogs);
        return logs;
      }

      var manusPid = await getManusProcessId();
      if (manusPid != null) {
        logs.add('[INFO] Manus rodando (PID: $manusPid) mas hook nao detectado em maps');
        r = await RootService.exec('cat $statusPath 2>/dev/null');
        if (r.success && r.output.trim().isNotEmpty) {
          logs.add('[INFO] Status file: ${r.output.trim()}');
        }
      } else {
        logs.add('[AVISO] Manus nao esta rodando - pode ter crashado');
        logs.add('Tentando iniciar novamente...');
        await RootService.exec('am start -n $pkg/.MainActivity 2>&1');
        await Future.delayed(const Duration(seconds: 5));
        manusPid = await getManusProcessId();
        if (manusPid != null) {
          logs.add('[OK] Manus iniciou (PID: $manusPid)');
          hookActive = await isHookActive();
          if (hookActive) {
            logs.add('[OK] *** Hook ativo na segunda tentativa! ***');
            final verifyLogs = await verifyInjection();
            logs.addAll(verifyLogs);
            return logs;
          }
        } else {
          logs.add('[ERRO] Manus nao iniciou. Removendo ld.so.preload...');
          await _cleanupLdPreload();
        }
      }

      logs.add('[INFO] Metodo 1 nao confirmou hook ativo');

      // ============================================================
      // METODO 2: ptrace + dlopen
      // ============================================================
      logs.add('');
      logs.add('=== METODO 2: ptrace + dlopen ===');

      manusPid = await getManusProcessId();
      if (manusPid == null) {
        logs.add('Manus nao esta rodando. Iniciando...');
        await _cleanupLdPreload();
        await RootService.exec('am start -n $pkg/.MainActivity 2>&1');
        await Future.delayed(const Duration(seconds: 5));
        manusPid = await getManusProcessId();
      }

      if (manusPid != null) {
        logs.add('Manus PID: $manusPid');
        await RootService.exec('setenforce 0 2>/dev/null');
        await RootService.exec('supolicy --live "allow untrusted_app untrusted_app process ptrace" 2>/dev/null');

        final injectorPath = '$installDir/$injectorName';
        logs.add('Executando: $injectorPath $manusPid $libPath');
        r = await RootService.exec('$injectorPath $manusPid $libPath 2>&1');

        if (r.output.isNotEmpty) {
          for (final line in r.output.split('\n').where((l) => l.isNotEmpty)) {
            logs.add('[ptrace] $line');
          }
        }
        if (r.error.isNotEmpty) {
          logs.add('[ptrace stderr] ${r.error}');
        }

        await Future.delayed(const Duration(seconds: 3));

        hookActive = await isHookActive();
        if (hookActive) {
          logs.add('');
          logs.add('[OK] *** METODO 2 FUNCIONOU! Hook ativo! ***');
          final verifyLogs = await verifyInjection();
          logs.addAll(verifyLogs);
          return logs;
        }
        logs.add('[INFO] ptrace inject nao confirmou hook ativo');
      } else {
        logs.add('[ERRO] Manus nao esta rodando');
      }

      // ============================================================
      // METODO 3: wrap property + LD_PRELOAD
      // ============================================================
      logs.add('');
      logs.add('=== METODO 3: wrap property + LD_PRELOAD ===');

      await RootService.exec('am force-stop $pkg');
      await Future.delayed(const Duration(seconds: 1));

      // Criar wrap script usando heredoc
      r = await RootService.exec(
        "cat > /data/local/tmp/manus_wrap.sh << 'WRAPEOF'\n"
        "#!/system/bin/sh\n"
        "export LD_PRELOAD=$libPath\n"
        'exec "\$@"\n'
        "WRAPEOF"
      );
      await RootService.exec('chmod 755 /data/local/tmp/manus_wrap.sh');
      logs.add(r.success ? '[OK] wrap script criado' : '[AVISO] ${r.error}');

      // Verificar conteudo do wrap script
      r = await RootService.exec('cat /data/local/tmp/manus_wrap.sh');
      logs.add('wrap.sh conteudo: ${r.output.trim()}');

      // Setar wrap property
      r = await RootService.exec('setprop wrap.$pkg /data/local/tmp/manus_wrap.sh');
      logs.add('[OK] wrap property setada');

      r = await RootService.exec('getprop wrap.$pkg');
      logs.add('wrap property: ${r.output.trim()}');

      // Iniciar Manus
      r = await RootService.exec('am start -n $pkg/.MainActivity 2>&1');
      logs.add('am start: ${r.output.trim()}');
      await Future.delayed(const Duration(seconds: 8));

      hookActive = await isHookActive();
      if (hookActive) {
        logs.add('');
        logs.add('[OK] *** METODO 3 FUNCIONOU! Hook ativo! ***');
        final verifyLogs = await verifyInjection();
        logs.addAll(verifyLogs);
        return logs;
      }
      logs.add('[INFO] Metodo 3 nao confirmou hook ativo');

      // ============================================================
      // METODO 4: LD_PRELOAD direto via am start
      // ============================================================
      logs.add('');
      logs.add('=== METODO 4: LD_PRELOAD direto ===');

      await RootService.exec('am force-stop $pkg');
      await Future.delayed(const Duration(seconds: 1));
      await RootService.exec('setprop wrap.$pkg ""');

      r = await RootService.exec('LD_PRELOAD=$libPath am start -n $pkg/.MainActivity 2>&1');
      logs.add('LD_PRELOAD am start: ${r.output.trim()}');
      await Future.delayed(const Duration(seconds: 5));

      hookActive = await isHookActive();
      if (hookActive) {
        logs.add('');
        logs.add('[OK] *** METODO 4 FUNCIONOU! Hook ativo! ***');
        final verifyLogs = await verifyInjection();
        logs.addAll(verifyLogs);
        return logs;
      }
      logs.add('[INFO] Metodo 4 nao confirmou hook ativo');

      // === DIAGNOSTICO FINAL ===
      logs.add('');
      logs.add('=== DIAGNOSTICO FINAL ===');

      // Testar se a lib pode ser carregada
      logs.add('Testando se a lib pode ser carregada...');
      r = await RootService.exec('LD_PRELOAD=$libPath ls /dev/null 2>&1');
      logs.add('Teste LD_PRELOAD: exit=${r.success ? "0" : "non-zero"} out=${r.output.trim()} err=${r.error.trim()}');

      // Verificar dmesg
      r = await RootService.exec('dmesg 2>/dev/null | tail -20 | grep -i -E "denied|error|fault|killed" 2>/dev/null');
      if (r.success && r.output.trim().isNotEmpty) {
        logs.add('');
        logs.add('dmesg erros recentes:');
        for (final line in r.output.split('\n').where((l) => l.isNotEmpty).take(5)) {
          logs.add('  $line');
        }
      }

      final verifyLogs = await verifyInjection();
      logs.addAll(verifyLogs);

    } catch (e) {
      logs.add('[ERRO] Excecao: $e');
    }

    return logs;
  }

  /// Limpa entradas do ld.so.preload
  static Future<void> _cleanupLdPreload() async {
    await RootService.exec('sed -i "/manus_hook/d" /etc/ld.so.preload 2>/dev/null');
    await RootService.exec('sed -i "/manus_hook/d" /system/etc/ld.so.preload 2>/dev/null');
    await RootService.exec('test -s /etc/ld.so.preload || rm -f /etc/ld.so.preload 2>/dev/null');
  }

  /// Le o arquivo de status escrito pelo hook
  static Future<Map<String, String>> readStatus() async {
    try {
      final r = await RootService.exec('cat $_statusPath 2>/dev/null');
      if (r.success && r.output.trim().isNotEmpty) {
        final map = <String, String>{};
        for (final line in r.output.split('\n')) {
          final idx = line.indexOf('=');
          if (idx > 0) {
            map[line.substring(0, idx).trim()] = line.substring(idx + 1).trim();
          }
        }
        return map;
      }
      return {};
    } catch (e) {
      return {};
    }
  }

  /// Remove o hook e limpa tudo
  static Future<List<String>> cleanup() async {
    final logs = <String>[];
    final pkg = _manusPackage;
    final hookLibName = _hookLibName;

    logs.add('=== LIMPEZA ===');

    await _cleanupLdPreload();
    logs.add('[OK] ld.so.preload limpo');

    await RootService.exec('setprop wrap.$pkg ""');
    logs.add('[OK] wrap property removida');

    final arch = await getDeviceArch();
    final systemLibDir = arch.contains('64') ? '/system/lib64' : '/system/lib';
    await RootService.exec('mount -o rw,remount /system 2>/dev/null');
    await RootService.exec('rm -f $systemLibDir/$hookLibName 2>/dev/null');
    logs.add('[OK] lib removida de $systemLibDir');

    await RootService.exec('rm -f $_configPath $_statusPath $_hookLogPath 2>/dev/null');
    logs.add('[OK] Arquivos temporarios removidos');

    await RootService.exec('mount -o ro,remount /system 2>/dev/null');
    logs.add('[OK] /system remontado como ro');

    return logs;
  }
}
