import 'dart:io';
import '../models/fake_device.dart';

class RootResult {
  final bool success;
  final String output;
  final String error;
  RootResult({required this.success, this.output = '', this.error = ''});
}

class RootService {
  /// Verifica se o dispositivo tem root
  static Future<bool> checkRoot() async {
    try {
      final result = await Process.run('su', ['-c', 'id'],
          runInShell: true)
          .timeout(const Duration(seconds: 5));
      return result.exitCode == 0 && result.stdout.toString().contains('uid=0');
    } catch (e) {
      return false;
    }
  }

  /// Verifica se o Magisk esta instalado (para resetprop)
  static Future<bool> checkMagisk() async {
    try {
      final result = await Process.run('su', ['-c', 'which magisk'],
          runInShell: true)
          .timeout(const Duration(seconds: 5));
      return result.exitCode == 0 && result.stdout.toString().trim().isNotEmpty;
    } catch (e) {
      return false;
    }
  }

  /// Verifica se resetprop esta disponivel
  static Future<bool> checkResetprop() async {
    try {
      final result = await Process.run('su', ['-c', 'which resetprop'],
          runInShell: true)
          .timeout(const Duration(seconds: 5));
      if (result.exitCode == 0 && result.stdout.toString().trim().isNotEmpty) {
        return true;
      }
      final result2 = await Process.run('su', ['-c', 'ls /data/adb/magisk/resetprop'],
          runInShell: true)
          .timeout(const Duration(seconds: 5));
      return result2.exitCode == 0;
    } catch (e) {
      return false;
    }
  }

  /// Executa um comando com root
  static Future<RootResult> exec(String command) async {
    try {
      final result = await Process.run('su', ['-c', command],
          runInShell: true)
          .timeout(const Duration(seconds: 15));
      return RootResult(
        success: result.exitCode == 0,
        output: result.stdout.toString().trim(),
        error: result.stderr.toString().trim(),
      );
    } catch (e) {
      return RootResult(success: false, error: e.toString());
    }
  }

  /// Executa multiplos comandos com root em sequencia
  static Future<RootResult> execMultiple(List<String> commands) async {
    final script = commands.join(' && ');
    return exec(script);
  }

  /// Muda uma system property via resetprop (Magisk)
  static Future<RootResult> resetProp(String prop, String value) async {
    var result = await exec('resetprop $prop "$value"');
    if (!result.success) {
      result = await exec('/data/adb/magisk/resetprop $prop "$value"');
    }
    if (!result.success) {
      result = await exec('setprop $prop "$value"');
    }
    return result;
  }

  /// Muda o Android ID via settings
  static Future<RootResult> setAndroidId(String newId) async {
    return exec('settings put secure android_id $newId');
  }

  /// Muda o Advertising ID
  static Future<RootResult> resetAdvertisingId() async {
    return exec(
      'rm -f /data/data/com.google.android.gms/shared_prefs/adid_settings.xml && '
      'rm -f /data/data/com.google.android.gms/shared_prefs/AdIdCacheSharedPref.xml'
    );
  }

  /// Limpa dados do app Manus
  static Future<RootResult> clearManusData() async {
    return exec('pm clear tech.butterfly.app');
  }

  /// Limpa apenas o cache do app Manus (mantem login)
  static Future<RootResult> clearManusCache() async {
    return exec(
      'rm -rf /data/data/tech.butterfly.app/cache/* && '
      'rm -rf /data/data/tech.butterfly.app/code_cache/*'
    );
  }

  /// Limpa dados do FingerprintJS Pro (shared prefs)
  static Future<RootResult> clearFingerprintData() async {
    return exec(
      'rm -f /data/data/tech.butterfly.app/shared_prefs/fpjs_*.xml && '
      'rm -f /data/data/tech.butterfly.app/shared_prefs/com.fingerprintjs*.xml && '
      'rm -f /data/data/tech.butterfly.app/shared_prefs/fp_*.xml'
    );
  }

  /// Limpa dados do Amplitude (analytics device_id)
  static Future<RootResult> clearAmplitudeData() async {
    return exec(
      'rm -f /data/data/tech.butterfly.app/shared_prefs/com.amplitude*.xml && '
      'rm -f /data/data/tech.butterfly.app/databases/com.amplitude*'
    );
  }

  /// Limpa dados do Adjust SDK
  static Future<RootResult> clearAdjustData() async {
    return exec(
      'rm -f /data/data/tech.butterfly.app/shared_prefs/adjust_*.xml && '
      'rm -f /data/data/tech.butterfly.app/shared_prefs/com.adjust*.xml'
    );
  }

  /// Abre o app Manus
  static Future<RootResult> launchManus() async {
    return exec('am start -n tech.butterfly.app/.MainActivity');
  }

  /// Fecha o app Manus
  static Future<RootResult> killManus() async {
    return exec('am force-stop tech.butterfly.app');
  }

  /// Verifica se o Manus esta instalado
  static Future<bool> isManusInstalled() async {
    try {
      final result = await exec('pm list packages | grep tech.butterfly.app');
      return result.success && result.output.contains('tech.butterfly.app');
    } catch (e) {
      return false;
    }
  }

  /// Le o valor atual de uma system property
  static Future<String> getProp(String prop) async {
    try {
      final result = await exec('getprop $prop');
      return result.success ? result.output : '???';
    } catch (e) {
      return '???';
    }
  }

  /// Le o Android ID atual
  static Future<String> getCurrentAndroidId() async {
    try {
      final result = await exec('settings get secure android_id');
      return result.success ? result.output : '???';
    } catch (e) {
      return '???';
    }
  }

  /// Le informacoes atuais do dispositivo
  static Future<Map<String, String>> getCurrentDeviceInfo() async {
    try {
      return {
        'Model': await getProp('ro.product.model'),
        'Brand': await getProp('ro.product.brand'),
        'Manufacturer': await getProp('ro.product.manufacturer'),
        'Device': await getProp('ro.product.device'),
        'Build ID': await getProp('ro.build.id'),
        'Fingerprint': await getProp('ro.build.fingerprint'),
        'Android ID': await getCurrentAndroidId(),
        'Serial': await getProp('ro.serialno'),
        'SDK': await getProp('ro.build.version.sdk'),
      };
    } catch (e) {
      return {'Erro': e.toString()};
    }
  }
}
