import 'package:flutter/material.dart';
import 'anti_detect.dart';

/// Tela de configuração do dispositivo virtual
/// Permite editar todos os campos do fingerprint ou gerar um novo aleatoriamente
class DeviceConfigScreen extends StatefulWidget {
  final DeviceProfile? currentProfile;

  const DeviceConfigScreen({super.key, this.currentProfile});

  @override
  State<DeviceConfigScreen> createState() => _DeviceConfigScreenState();
}

class _DeviceConfigScreenState extends State<DeviceConfigScreen> {
  late TextEditingController _clientIdCtrl;
  late TextEditingController _userAgentCtrl;
  late TextEditingController _localeCtrl;
  late TextEditingController _languagesCtrl;
  late TextEditingController _timezoneCtrl;
  late TextEditingController _tzOffsetCtrl;
  late TextEditingController _screenWCtrl;
  late TextEditingController _screenHCtrl;
  late TextEditingController _viewportWCtrl;
  late TextEditingController _viewportHCtrl;

  String _dcrPreview = '';

  @override
  void initState() {
    super.initState();
    final p = widget.currentProfile ?? generateDeviceProfile();
    _initControllers(p);
    _updateDcrPreview();
  }

  void _initControllers(DeviceProfile p) {
    _clientIdCtrl = TextEditingController(text: p.clientId);
    _userAgentCtrl = TextEditingController(text: p.userAgent);
    _localeCtrl = TextEditingController(text: p.locale);
    _languagesCtrl = TextEditingController(text: p.languages.join(', '));
    _timezoneCtrl = TextEditingController(text: p.timezone);
    _tzOffsetCtrl = TextEditingController(text: p.timezoneOffset.toString());
    _screenWCtrl =
        TextEditingController(text: p.screen['width']?.toString() ?? '1920');
    _screenHCtrl =
        TextEditingController(text: p.screen['height']?.toString() ?? '1080');
    _viewportWCtrl =
        TextEditingController(text: p.viewport['width']?.toString() ?? '1920');
    _viewportHCtrl =
        TextEditingController(text: p.viewport['height']?.toString() ?? '969');
  }

  void _disposeControllers() {
    _clientIdCtrl.dispose();
    _userAgentCtrl.dispose();
    _localeCtrl.dispose();
    _languagesCtrl.dispose();
    _timezoneCtrl.dispose();
    _tzOffsetCtrl.dispose();
    _screenWCtrl.dispose();
    _screenHCtrl.dispose();
    _viewportWCtrl.dispose();
    _viewportHCtrl.dispose();
  }

  @override
  void dispose() {
    _disposeControllers();
    super.dispose();
  }

  /// Gera um novo perfil aleatório e preenche todos os campos
  void _generateNew() {
    final p = generateDeviceProfile();
    _disposeControllers();
    _initControllers(p);
    _updateDcrPreview();
    setState(() {});
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Text('Novo dispositivo gerado!'),
        backgroundColor: const Color(0xFF7C3AED),
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 2),
      ),
    );
  }

  /// Gera apenas um novo Client ID
  void _generateNewClientId() {
    _clientIdCtrl.text = generateClientId();
    _updateDcrPreview();
    setState(() {});
  }

  /// Monta o DeviceProfile a partir dos campos editados
  DeviceProfile _buildProfile() {
    return DeviceProfile(
      clientId: _clientIdCtrl.text.trim(),
      userAgent: _userAgentCtrl.text.trim(),
      locale: _localeCtrl.text.trim(),
      languages: _languagesCtrl.text
          .split(',')
          .map((s) => s.trim())
          .where((s) => s.isNotEmpty)
          .toList(),
      timezone: _timezoneCtrl.text.trim(),
      timezoneOffset: int.tryParse(_tzOffsetCtrl.text.trim()) ?? 180,
      screen: {
        'width': int.tryParse(_screenWCtrl.text.trim()) ?? 1920,
        'height': int.tryParse(_screenHCtrl.text.trim()) ?? 1080,
      },
      viewport: {
        'width': int.tryParse(_viewportWCtrl.text.trim()) ?? 1920,
        'height': int.tryParse(_viewportHCtrl.text.trim()) ?? 969,
      },
      fgRequestId: generateFingerprintRequestId(),
      visitorId: generateVisitorId(),
    );
  }

  void _updateDcrPreview() {
    try {
      final p = _buildProfile();
      _dcrPreview = p.generateDCR();
      if (_dcrPreview.length > 80) {
        _dcrPreview = '${_dcrPreview.substring(0, 80)}...';
      }
    } catch (_) {
      _dcrPreview = 'Erro ao gerar DCR';
    }
  }

  void _confirmAndReturn() {
    final profile = _buildProfile();
    Navigator.pop(context, profile);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D0D1A),
      appBar: AppBar(
        title: const Text('Configurar Dispositivo'),
        backgroundColor: const Color(0xFF1A1A2E),
        actions: [
          IconButton(
            icon: const Icon(Icons.casino, color: Color(0xFF7C3AED)),
            tooltip: 'Gerar tudo novo',
            onPressed: _generateNew,
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    const Color(0xFF7C3AED).withOpacity(0.15),
                    const Color(0xFF2563EB).withOpacity(0.15),
                  ],
                ),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                    color: const Color(0xFF7C3AED).withOpacity(0.3)),
              ),
              child: Column(
                children: [
                  const Icon(Icons.devices, color: Color(0xFF7C3AED), size: 32),
                  const SizedBox(height: 8),
                  const Text(
                    'Perfil do Dispositivo Virtual',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'Edite os campos ou gere um novo perfil aleatório',
                    style: TextStyle(
                        color: Colors.white.withOpacity(0.5), fontSize: 12),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 20),

            // ── Identidade ──
            _sectionHeader('IDENTIDADE', Icons.fingerprint),
            const SizedBox(height: 8),
            _fieldWithAction(
              'Client ID (nanoid 22)',
              _clientIdCtrl,
              actionIcon: Icons.refresh,
              actionTooltip: 'Gerar novo ID',
              onAction: _generateNewClientId,
            ),
            const SizedBox(height: 10),
            _field('User-Agent', _userAgentCtrl, maxLines: 3),

            const SizedBox(height: 20),

            // ── Localização ──
            _sectionHeader('LOCALIZAÇÃO', Icons.language),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(child: _field('Locale', _localeCtrl)),
                const SizedBox(width: 10),
                Expanded(
                    child: _field('Timezone Offset', _tzOffsetCtrl,
                        keyboardType: TextInputType.number)),
              ],
            ),
            const SizedBox(height: 10),
            _field('Timezone', _timezoneCtrl),
            const SizedBox(height: 10),
            _field('Languages (separar com vírgula)', _languagesCtrl),

            const SizedBox(height: 20),

            // ── Tela ──
            _sectionHeader('TELA', Icons.monitor),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                    child: _field('Screen W', _screenWCtrl,
                        keyboardType: TextInputType.number)),
                const SizedBox(width: 10),
                Expanded(
                    child: _field('Screen H', _screenHCtrl,
                        keyboardType: TextInputType.number)),
              ],
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                    child: _field('Viewport W', _viewportWCtrl,
                        keyboardType: TextInputType.number)),
                const SizedBox(width: 10),
                Expanded(
                    child: _field('Viewport H', _viewportHCtrl,
                        keyboardType: TextInputType.number)),
              ],
            ),

            const SizedBox(height: 20),

            // ── Presets rápidos ──
            _sectionHeader('PRESETS RÁPIDOS', Icons.bolt),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                _presetChip('Windows + Chrome 131', () {
                  _userAgentCtrl.text =
                      'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';
                  _screenWCtrl.text = '1920';
                  _screenHCtrl.text = '1080';
                  _viewportWCtrl.text = '1920';
                  _viewportHCtrl.text = '969';
                  setState(() {});
                }),
                _presetChip('Mac + Chrome 131', () {
                  _userAgentCtrl.text =
                      'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';
                  _screenWCtrl.text = '2560';
                  _screenHCtrl.text = '1440';
                  _viewportWCtrl.text = '1903';
                  _viewportHCtrl.text = '969';
                  setState(() {});
                }),
                _presetChip('Linux + Chrome 131', () {
                  _userAgentCtrl.text =
                      'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';
                  _screenWCtrl.text = '1920';
                  _screenHCtrl.text = '1080';
                  _viewportWCtrl.text = '1920';
                  _viewportHCtrl.text = '969';
                  setState(() {});
                }),
                _presetChip('pt-BR / São Paulo', () {
                  _localeCtrl.text = 'pt-BR';
                  _languagesCtrl.text = 'pt-BR, pt, en-US, en';
                  _timezoneCtrl.text = 'America/Sao_Paulo';
                  _tzOffsetCtrl.text = '180';
                  setState(() {});
                }),
                _presetChip('en-US / New York', () {
                  _localeCtrl.text = 'en-US';
                  _languagesCtrl.text = 'en-US, en';
                  _timezoneCtrl.text = 'America/New_York';
                  _tzOffsetCtrl.text = '300';
                  setState(() {});
                }),
                _presetChip('en-US / Los Angeles', () {
                  _localeCtrl.text = 'en-US';
                  _languagesCtrl.text = 'en-US, en';
                  _timezoneCtrl.text = 'America/Los_Angeles';
                  _tzOffsetCtrl.text = '480';
                  setState(() {});
                }),
                _presetChip('en-GB / London', () {
                  _localeCtrl.text = 'en-GB';
                  _languagesCtrl.text = 'en-GB, en';
                  _timezoneCtrl.text = 'Europe/London';
                  _tzOffsetCtrl.text = '0';
                  setState(() {});
                }),
              ],
            ),

            const SizedBox(height: 20),

            // ── DCR Preview ──
            _sectionHeader('DCR PREVIEW', Icons.shield),
            const SizedBox(height: 8),
            GestureDetector(
              onTap: () {
                _updateDcrPreview();
                setState(() {});
              },
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: const Color(0xFF1A1A2E),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: const Color(0xFF2A2A4A)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'x-client-dcr:',
                      style: TextStyle(
                          color: Colors.greenAccent.withOpacity(0.7),
                          fontSize: 10,
                          fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      _dcrPreview,
                      style: TextStyle(
                          color: Colors.white.withOpacity(0.5),
                          fontSize: 10,
                          fontFamily: 'monospace'),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Toque para atualizar preview',
                      style: TextStyle(
                          color: Colors.white.withOpacity(0.2), fontSize: 9),
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 30),

            // ── Botões ──
            Row(
              children: [
                Expanded(
                  child: SizedBox(
                    height: 50,
                    child: OutlinedButton.icon(
                      onPressed: _generateNew,
                      icon: const Icon(Icons.casino, size: 18),
                      label: const Text('Gerar Novo'),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: const Color(0xFF7C3AED),
                        side: const BorderSide(color: Color(0xFF7C3AED)),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12)),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: SizedBox(
                    height: 50,
                    child: ElevatedButton.icon(
                      onPressed: _confirmAndReturn,
                      icon: const Icon(Icons.check, size: 18),
                      label: const Text('Usar Este Perfil'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF7C3AED),
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12)),
                        elevation: 0,
                      ),
                    ),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 30),
          ],
        ),
      ),
    );
  }

  // ── Widgets auxiliares ──

  Widget _sectionHeader(String title, IconData icon) {
    return Row(
      children: [
        Icon(icon, size: 14, color: const Color(0xFF7C3AED)),
        const SizedBox(width: 6),
        Text(
          title,
          style: TextStyle(
            color: const Color(0xFF7C3AED).withOpacity(0.8),
            fontSize: 11,
            fontWeight: FontWeight.bold,
            letterSpacing: 1.5,
          ),
        ),
      ],
    );
  }

  Widget _field(String label, TextEditingController ctrl,
      {int maxLines = 1, TextInputType? keyboardType}) {
    return TextField(
      controller: ctrl,
      maxLines: maxLines,
      keyboardType: keyboardType,
      style: const TextStyle(color: Colors.white, fontSize: 13),
      decoration: InputDecoration(
        labelText: label,
        labelStyle: TextStyle(color: Colors.white.withOpacity(0.4), fontSize: 12),
        filled: true,
        fillColor: const Color(0xFF1A1A2E),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: const BorderSide(color: Color(0xFF2A2A4A)),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: const BorderSide(color: Color(0xFF2A2A4A)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: const BorderSide(color: Color(0xFF7C3AED)),
        ),
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      ),
    );
  }

  Widget _fieldWithAction(String label, TextEditingController ctrl,
      {required IconData actionIcon,
      required String actionTooltip,
      required VoidCallback onAction}) {
    return Row(
      children: [
        Expanded(child: _field(label, ctrl)),
        const SizedBox(width: 8),
        IconButton(
          icon: Icon(actionIcon, color: const Color(0xFF7C3AED), size: 20),
          tooltip: actionTooltip,
          onPressed: onAction,
          style: IconButton.styleFrom(
            backgroundColor: const Color(0xFF1A1A2E),
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
          ),
        ),
      ],
    );
  }

  Widget _presetChip(String label, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          color: const Color(0xFF1A1A2E),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: const Color(0xFF2A2A4A)),
        ),
        child: Text(
          label,
          style: TextStyle(
              color: Colors.white.withOpacity(0.7),
              fontSize: 11),
        ),
      ),
    );
  }
}
