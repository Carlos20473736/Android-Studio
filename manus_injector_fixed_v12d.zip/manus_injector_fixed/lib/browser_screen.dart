import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:webview_flutter_android/webview_flutter_android.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'anti_detect.dart';

// ═══════════════════════════════════════════════════════════════════════════════
// MANUS BROWSER - Navegador Completo (padrão Young Browser)
// Multi-abas + Sniffer + Breakpoint
// ═══════════════════════════════════════════════════════════════════════════════

class BrowserScreen extends StatefulWidget {
  final DeviceProfile deviceProfile;
  final String? initialUrl;
  final Map<String, String>? cookies;

  const BrowserScreen({
    super.key,
    required this.deviceProfile,
    this.initialUrl,
    this.cookies,
  });

  @override
  State<BrowserScreen> createState() => _BrowserScreenState();
}

class _BrowserScreenState extends State<BrowserScreen>
    with SingleTickerProviderStateMixin {
  // ══════════════════════════════════════════════════════════════════════════
  // TABS
  // ══════════════════════════════════════════════════════════════════════════
  final List<_BrowserTab> _tabs = [];
  int _activeTabIndex = 0;
  bool _showTabsView = false;

  // ══════════════════════════════════════════════════════════════════════════
  // UI
  // ══════════════════════════════════════════════════════════════════════════
  final TextEditingController _urlController = TextEditingController();
  bool _showMenu = false;

  // ══════════════════════════════════════════════════════════════════════════
  // DATA
  // ══════════════════════════════════════════════════════════════════════════
  final List<String> _bookmarks = [];
  final List<_HistoryEntry> _history = [];

  // ══════════════════════════════════════════════════════════════════════════
  // SNIFFER & BREAKPOINT
  // ══════════════════════════════════════════════════════════════════════════
  final Map<String, Map<String, String>> _allSiteCookies = {};
  final List<_CapturedRequest> _capturedApis = [];
  bool _breakpointEnabled = false;
  final List<_BreakpointRule> _breakpointRules = [];
  final List<_PendingRequest> _pendingRequests = [];

  @override
  void initState() {
    super.initState();
    _loadBookmarks();
    if (widget.cookies != null && widget.cookies!.isNotEmpty) {
      _allSiteCookies['manus.im (login)'] =
          Map<String, String>.from(widget.cookies!);
    }
    _createNewTab(widget.initialUrl ?? 'https://www.google.com');
  }

  @override
  void dispose() {
    _urlController.dispose();
    super.dispose();
  }

  Future<void> _loadBookmarks() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getStringList('browser_bookmarks') ?? [];
    if (mounted) setState(() => _bookmarks.addAll(saved));
  }

  Future<void> _saveBookmarks() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('browser_bookmarks', _bookmarks);
  }

  // ══════════════════════════════════════════════════════════════════════════
  // TAB MANAGEMENT
  // ══════════════════════════════════════════════════════════════════════════

  _BrowserTab get _activeTab => _tabs[_activeTabIndex];

  void _createNewTab(String url) {
    final tab = _BrowserTab(url: url);
    _initTabWebView(tab);
    setState(() {
      _tabs.add(tab);
      _activeTabIndex = _tabs.length - 1;
      _urlController.text = url;
    });
  }

  void _closeTab(int index) {
    if (_tabs.length <= 1) return;
    setState(() {
      _tabs.removeAt(index);
      if (_activeTabIndex >= _tabs.length) {
        _activeTabIndex = _tabs.length - 1;
      }
      _urlController.text = _activeTab.currentUrl;
    });
  }

  void _switchTab(int index) {
    setState(() {
      _activeTabIndex = index;
      _showTabsView = false;
      _urlController.text = _activeTab.currentUrl;
    });
  }

  // ══════════════════════════════════════════════════════════════════════════
  // WEBVIEW INIT (mesmo padrão do Young Browser que funciona)
  // ══════════════════════════════════════════════════════════════════════════

  void _initTabWebView(_BrowserTab tab) {
    tab.controller = WebViewController()
      ..setUserAgent(widget.deviceProfile.userAgent)
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageStarted: (url) {
            setState(() {
              tab.isLoading = true;
              tab.currentUrl = url;
              if (_tabs.indexOf(tab) == _activeTabIndex) {
                _urlController.text = url;
              }
            });
          },
          onProgress: (progress) {
            setState(() {
              tab.loadingProgress = progress;
            });
          },
          onPageFinished: (url) {
            setState(() {
              tab.isLoading = false;
              tab.currentUrl = url;
              if (_tabs.indexOf(tab) == _activeTabIndex) {
                _urlController.text = url;
              }
            });
            _updateTabTitle(tab);
            _addToHistory(url, tab.title);
            _captureSiteCookies(tab);
            _injectInterceptor(tab);
          },
          onWebResourceError: (error) {
            setState(() {
              tab.isLoading = false;
            });
          },
        ),
      );

    // JavaScript channels para sniffer/breakpoint
    tab.controller.addJavaScriptChannel(
      'CookieBridge',
      onMessageReceived: (msg) => _processCookieMessage(msg.message),
    );
    tab.controller.addJavaScriptChannel(
      'ApiBridge',
      onMessageReceived: (msg) => _processApiMessage(msg.message),
    );
    tab.controller.addJavaScriptChannel(
      'BreakpointBridge',
      onMessageReceived: (msg) => _processBreakpointMessage(msg.message),
    );

    // Configurações Android (mesmo padrão Young Browser)
    final androidController =
        tab.controller.platform as AndroidWebViewController;
    androidController.setMediaPlaybackRequiresUserGesture(false);
    androidController.setGeolocationEnabled(true);

    tab.controller.loadRequest(Uri.parse(tab.url));
  }

  Future<void> _updateTabTitle(_BrowserTab tab) async {
    try {
      final t = await tab.controller.getTitle();
      if (mounted && t != null && t.isNotEmpty) {
        setState(() => tab.title = t);
      }
    } catch (_) {}
  }

  // ══════════════════════════════════════════════════════════════════════════
  // NAVIGATION
  // ══════════════════════════════════════════════════════════════════════════

  void _navigateToUrl(String input) {
    String url = input.trim();
    if (url.isEmpty) return;

    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      if (url.contains('.') && !url.contains(' ')) {
        url = 'https://$url';
      } else {
        url = 'https://www.google.com/search?q=${Uri.encodeComponent(url)}';
      }
    }

    _activeTab.controller.loadRequest(Uri.parse(url));
    FocusScope.of(context).unfocus();
  }

  void _addToHistory(String url, String title) {
    if (_history.isNotEmpty && _history.first.url == url) return;
    _history.insert(0, _HistoryEntry(url: url, title: title, timestamp: DateTime.now()));
    if (_history.length > 500) _history.removeLast();
  }

  // ══════════════════════════════════════════════════════════════════════════
  // COOKIES CAPTURE
  // ══════════════════════════════════════════════════════════════════════════

  Future<void> _captureSiteCookies(_BrowserTab tab) async {
    try {
      await tab.controller.runJavaScript('''
(function(){
  try {
    var c = document.cookie || '';
    var h = window.location.hostname || '';
    var s = {};
    try { for(var i=0; i<localStorage.length; i++) { var k=localStorage.key(i); s['ls_'+k]=localStorage.getItem(k); } } catch(e){}
    try { for(var i=0; i<sessionStorage.length; i++) { var k=sessionStorage.key(i); s['ss_'+k]=sessionStorage.getItem(k); } } catch(e){}
    CookieBridge.postMessage(JSON.stringify({type:'site_cookies', hostname:h, cookies:c, storage:s}));
  } catch(e){}
})();
      ''');
    } catch (_) {}
  }

  void _processCookieMessage(String message) {
    try {
      final data = jsonDecode(message);
      if (data['type'] == 'site_cookies') {
        final hostname = data['hostname'] as String? ?? 'unknown';
        final cookieStr = data['cookies'] as String? ?? '';
        final storage = data['storage'] as Map<String, dynamic>? ?? {};
        final sc = <String, String>{};
        if (cookieStr.isNotEmpty) {
          for (final p in cookieStr.split(';')) {
            final t = p.trim();
            final eq = t.indexOf('=');
            if (eq > 0) sc[t.substring(0, eq).trim()] = t.substring(eq + 1).trim();
          }
        }
        for (final e in storage.entries) {
          if (e.value is String && (e.value as String).isNotEmpty) {
            final v = e.value as String;
            sc[e.key] = v.length <= 500 ? v : '${v.substring(0, 200)}...[${v.length}]';
          }
        }
        if (sc.isNotEmpty) {
          setState(() => _allSiteCookies[hostname] = {...(_allSiteCookies[hostname] ?? {}), ...sc});
        }
      }
    } catch (_) {}
  }

  // ══════════════════════════════════════════════════════════════════════════
  // INTERCEPTOR INJECTION (captura fetch, XHR, WebSocket, resources)
  // ══════════════════════════════════════════════════════════════════════════

  Future<void> _injectInterceptor(_BrowserTab tab) async {
    try {
      await tab.controller.runJavaScript('''
(function(){
  if(window.__manusBrowserV3) return;
  window.__manusBrowserV3 = true;
  var hostname = window.location.hostname || '';
  var reqId = 0;
  window.__manusPendingResolvers = {};
  window.__manusBreakpointEnabled = ${_breakpointEnabled ? 'true' : 'false'};
  window.__manusBreakpointRules = [];

  window.__manusResolveBreakpoint = function(id, action, modifiedData) {
    var resolver = window.__manusPendingResolvers[id];
    if(resolver) { resolver({action:action, data:modifiedData}); delete window.__manusPendingResolvers[id]; }
  };

  function shouldBreakpoint(method, url) {
    if(!window.__manusBreakpointEnabled) return false;
    var rules = window.__manusBreakpointRules || [];
    if(rules.length === 0) return true;
    for(var i=0; i<rules.length; i++) {
      var r = rules[i];
      if(!r.enabled) continue;
      var mu = !r.urlPattern || url.indexOf(r.urlPattern) >= 0;
      var mm = !r.method || r.method === '*' || r.method === method;
      if(mu && mm) return true;
    }
    return false;
  }

  function waitForDecision(id, method, url, headers, body) {
    return new Promise(function(resolve) {
      window.__manusPendingResolvers[id] = resolve;
      BreakpointBridge.postMessage(JSON.stringify({type:'breakpoint_hit', id:id, method:method, url:url, headers:headers, body:body, hostname:hostname, timestamp:Date.now()}));
    });
  }

  // ═══ FETCH ═══
  var origFetch = window.fetch;
  window.fetch = async function() {
    var id = ++reqId, url = '', method = 'GET', reqHeaders = {}, body = null;
    if(typeof arguments[0] === 'string') { url = arguments[0]; }
    else if(arguments[0] instanceof Request) { url = arguments[0].url; method = arguments[0].method || 'GET'; try { arguments[0].headers.forEach(function(v,k){ reqHeaders[k]=v; }); } catch(e){} }
    if(arguments[1]) { method = arguments[1].method || method; try { var h = arguments[1].headers; if(h instanceof Headers) h.forEach(function(v,k){ reqHeaders[k]=v; }); else if(typeof h === 'object' && h) Object.keys(h).forEach(function(k){ reqHeaders[k]=h[k]; }); } catch(e){} body = arguments[1].body || null; }
    try { if(url && !url.startsWith('http') && !url.startsWith('//')) url = new URL(url, window.location.href).href; } catch(e){}
    var bodyStr = null;
    try { if(body && typeof body === 'string') bodyStr = body.substring(0,4000); else if(body && body instanceof FormData) bodyStr = '[FormData]'; else if(body) bodyStr = '[Binary]'; } catch(e){}
    ApiBridge.postMessage(JSON.stringify({type:'request', id:id, transport:'fetch', method:method.toUpperCase(), url:url, hostname:hostname, requestHeaders:reqHeaders, body:bodyStr, timestamp:Date.now()}));

    if(shouldBreakpoint(method.toUpperCase(), url)) {
      var decision = await waitForDecision(id, method.toUpperCase(), url, reqHeaders, bodyStr);
      if(decision.action === 'block') { ApiBridge.postMessage(JSON.stringify({type:'response', id:id, status:0, statusText:'BLOCKED', responseHeaders:{}, url:url})); return new Response('', {status:0}); }
      if(decision.action === 'modify' && decision.data) {
        var m = decision.data; url = m.url || url; method = m.method || method; reqHeaders = m.headers || reqHeaders;
        var newOpts = {method:method, headers:reqHeaders};
        if(m.body && method !== 'GET' && method !== 'HEAD') newOpts.body = m.body;
        var resp = await origFetch.call(window, url, newOpts);
        var rh = {}; try { resp.headers.forEach(function(v,k){ rh[k]=v; }); } catch(e){}
        ApiBridge.postMessage(JSON.stringify({type:'response', id:id, status:resp.status, statusText:resp.statusText, responseHeaders:rh, url:url}));
        return resp;
      }
    }
    try {
      var resp = await origFetch.apply(window, arguments);
      var rh = {}; try { resp.headers.forEach(function(v,k){ rh[k]=v; }); } catch(e){}
      ApiBridge.postMessage(JSON.stringify({type:'response', id:id, status:resp.status, statusText:resp.statusText, responseHeaders:rh, url:url}));
      return resp;
    } catch(err) { ApiBridge.postMessage(JSON.stringify({type:'response', id:id, status:0, statusText:'ERR:'+err.message, responseHeaders:{}, url:url})); throw err; }
  };

  // ═══ XHR ═══
  var origOpen = XMLHttpRequest.prototype.open, origSend = XMLHttpRequest.prototype.send, origSetH = XMLHttpRequest.prototype.setRequestHeader;
  XMLHttpRequest.prototype.open = function(m, u) { this.__mid = ++reqId; this.__mm = m; this.__mu = u; this.__mh = {}; try { if(u && !u.startsWith('http') && !u.startsWith('//')) this.__mu = new URL(u, window.location.href).href; } catch(e){} return origOpen.apply(this, arguments); };
  XMLHttpRequest.prototype.setRequestHeader = function(k, v) { if(this.__mh) this.__mh[k] = v; return origSetH.apply(this, arguments); };
  XMLHttpRequest.prototype.send = function(body) {
    var self = this, bodyStr = null;
    try { if(body && typeof body === 'string') bodyStr = body.substring(0,4000); else if(body) bodyStr = '[Binary]'; } catch(e){}
    ApiBridge.postMessage(JSON.stringify({type:'request', id:self.__mid, transport:'xhr', method:(self.__mm||'GET').toUpperCase(), url:self.__mu||'', hostname:hostname, requestHeaders:self.__mh||{}, body:bodyStr, timestamp:Date.now()}));
    if(shouldBreakpoint((self.__mm||'GET').toUpperCase(), self.__mu||'')) {
      waitForDecision(self.__mid, (self.__mm||'GET').toUpperCase(), self.__mu||'', self.__mh||{}, bodyStr).then(function(d) {
        if(d.action === 'block') { ApiBridge.postMessage(JSON.stringify({type:'response', id:self.__mid, status:0, statusText:'BLOCKED', responseHeaders:{}, url:self.__mu})); return; }
        var fu = self.__mu, fm = self.__mm, fh = self.__mh, fb = body;
        if(d.action === 'modify' && d.data) { fu = d.data.url||fu; fm = d.data.method||fm; fh = d.data.headers||fh; fb = d.data.body||fb; }
        origOpen.call(self, fm, fu);
        if(fh) Object.keys(fh).forEach(function(k){ try { origSetH.call(self, k, fh[k]); } catch(e){} });
        self.addEventListener('loadend', function(){ var rh={}; try { var a=self.getAllResponseHeaders()||''; a.split('\\r\\n').forEach(function(l){ var i=l.indexOf(':'); if(i>0) rh[l.substring(0,i).trim().toLowerCase()]=l.substring(i+1).trim(); }); } catch(e){} ApiBridge.postMessage(JSON.stringify({type:'response', id:self.__mid, status:self.status, statusText:self.statusText||'', responseHeaders:rh, url:fu})); });
        origSend.call(self, fb);
      });
      return;
    }
    this.addEventListener('loadend', function(){ var rh={}; try { var a=self.getAllResponseHeaders()||''; a.split('\\r\\n').forEach(function(l){ var i=l.indexOf(':'); if(i>0) rh[l.substring(0,i).trim().toLowerCase()]=l.substring(i+1).trim(); }); } catch(e){} ApiBridge.postMessage(JSON.stringify({type:'response', id:self.__mid, status:self.status, statusText:self.statusText||'', responseHeaders:rh, url:self.__mu||''})); });
    return origSend.apply(this, arguments);
  };

  // ═══ WEBSOCKET ═══
  var origWS = window.WebSocket;
  window.WebSocket = function(url, protocols) {
    var id = ++reqId;
    ApiBridge.postMessage(JSON.stringify({type:'request', id:id, transport:'websocket', method:'WS', url:url, hostname:hostname, requestHeaders:{'Sec-WebSocket-Protocol': protocols ? String(protocols) : ''}, body:null, timestamp:Date.now()}));
    var ws = new origWS(url, protocols);
    ws.addEventListener('open', function(){ ApiBridge.postMessage(JSON.stringify({type:'response', id:id, status:101, statusText:'Switching Protocols', responseHeaders:{'upgrade':'websocket'}, url:url})); });
    return ws;
  };
  window.WebSocket.prototype = origWS.prototype;
  window.WebSocket.CONNECTING = origWS.CONNECTING; window.WebSocket.OPEN = origWS.OPEN; window.WebSocket.CLOSING = origWS.CLOSING; window.WebSocket.CLOSED = origWS.CLOSED;

  // ═══ PERFORMANCE OBSERVER (resources) ═══
  try {
    var po = new PerformanceObserver(function(list){
      var entries = list.getEntries();
      for(var i=0; i<entries.length; i++){
        var e = entries[i];
        if(e.entryType === 'resource' && e.name) {
          var id = ++reqId;
          ApiBridge.postMessage(JSON.stringify({type:'request', id:id, transport:'resource', method:'GET', url:e.name, hostname:hostname, requestHeaders:{'initiatorType':e.initiatorType||'other', 'transferSize':String(e.transferSize||0), 'duration':String(Math.round(e.duration||0))+'ms'}, body:null, timestamp:Date.now()}));
          ApiBridge.postMessage(JSON.stringify({type:'response', id:id, status:200, statusText:'OK', responseHeaders:{'content-type':e.initiatorType||'unknown', 'transfer-size':String(e.transferSize||0)}, url:e.name}));
        }
      }
    });
    po.observe({type:'resource', buffered:true});
  } catch(e){}
})();
      ''');
    } catch (_) {}
  }

  // ══════════════════════════════════════════════════════════════════════════
  // PROCESS MESSAGES
  // ══════════════════════════════════════════════════════════════════════════

  void _processApiMessage(String message) {
    try {
      final data = jsonDecode(message);
      final type = data['type'] as String? ?? '';
      if (type == 'request') {
        final req = _CapturedRequest(
          id: data['id'] as int? ?? 0,
          transport: data['transport'] as String? ?? 'fetch',
          method: data['method'] as String? ?? 'GET',
          fullUrl: data['url'] as String? ?? '',
          hostname: data['hostname'] as String? ?? '',
          requestHeaders: Map<String, String>.from(
              (data['requestHeaders'] as Map<String, dynamic>? ?? {})
                  .map((k, v) => MapEntry(k, v.toString()))),
          body: data['body'] as String?,
          timestamp: data['timestamp'] as int? ?? 0,
        );
        setState(() {
          _capturedApis.insert(0, req);
          if (_capturedApis.length > 1000) _capturedApis.removeLast();
        });
      } else if (type == 'response') {
        final id = data['id'] as int? ?? 0;
        setState(() {
          for (int i = 0; i < _capturedApis.length; i++) {
            if (_capturedApis[i].id == id) {
              _capturedApis[i].statusCode = data['status'] as int? ?? 0;
              _capturedApis[i].statusText = data['statusText'] as String? ?? '';
              _capturedApis[i].responseHeaders = Map<String, String>.from(
                  (data['responseHeaders'] as Map<String, dynamic>? ?? {})
                      .map((k, v) => MapEntry(k, v.toString())));
              break;
            }
          }
        });
      }
    } catch (_) {}
  }

  void _processBreakpointMessage(String message) {
    try {
      final data = jsonDecode(message);
      if (data['type'] == 'breakpoint_hit') {
        final pending = _PendingRequest(
          id: data['id'] as int? ?? 0,
          method: data['method'] as String? ?? 'GET',
          url: data['url'] as String? ?? '',
          headers: Map<String, String>.from(
              (data['headers'] as Map<String, dynamic>? ?? {})
                  .map((k, v) => MapEntry(k, v.toString()))),
          body: data['body'] as String?,
          hostname: data['hostname'] as String? ?? '',
        );
        setState(() => _pendingRequests.add(pending));
        _showBreakpointSnack(pending);
      }
    } catch (_) {}
  }

  void _showBreakpointSnack(_PendingRequest req) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Row(children: [
        const Icon(Icons.pause_circle, color: Colors.amber, size: 16),
        const SizedBox(width: 6),
        Expanded(child: Text('[${req.method}] ${req.url.length > 40 ? '${req.url.substring(0, 40)}...' : req.url}', style: const TextStyle(fontSize: 10))),
      ]),
      backgroundColor: const Color(0xFF1E1E3A),
      duration: const Duration(seconds: 3),
      action: SnackBarAction(label: 'EDITAR', textColor: const Color(0xFF7C3AED), onPressed: () => _showBreakpointEditor(req)),
    ));
  }

  // ══════════════════════════════════════════════════════════════════════════
  // BREAKPOINT CONTROLS
  // ══════════════════════════════════════════════════════════════════════════

  void _toggleBreakpoint() {
    setState(() => _breakpointEnabled = !_breakpointEnabled);
    _syncBreakpointState();
  }

  void _syncBreakpointState() {
    final rulesList = <Map<String, dynamic>>[];
    for (final r in _breakpointRules) {
      rulesList.add({'enabled': r.enabled, 'urlPattern': r.urlPattern, 'method': r.method});
    }
    final rulesJson = jsonEncode(rulesList);
    _activeTab.controller.runJavaScript('''
      window.__manusBreakpointEnabled = ${_breakpointEnabled ? 'true' : 'false'};
      window.__manusBreakpointRules = $rulesJson;
    ''');
  }

  void _resolveBreakpoint(_PendingRequest req, String action, {Map<String, dynamic>? modifiedData}) {
    final dataJson = modifiedData != null ? jsonEncode(modifiedData) : 'null';
    _activeTab.controller.runJavaScript(
        'if(window.__manusResolveBreakpoint)window.__manusResolveBreakpoint(${req.id},"$action",$dataJson);');
    setState(() => _pendingRequests.removeWhere((p) => p.id == req.id));
  }

  void _forwardAllPending() {
    for (final req in List.from(_pendingRequests)) {
      _resolveBreakpoint(req, 'forward');
    }
  }

  // ══════════════════════════════════════════════════════════════════════════
  // BUILD
  // ══════════════════════════════════════════════════════════════════════════

  @override
  Widget build(BuildContext context) {
    if (_tabs.isEmpty) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    return Scaffold(
      backgroundColor: const Color(0xFF0F3460),
      body: SafeArea(
        child: _showTabsView ? _buildTabsOverview() : _buildBrowserView(),
      ),
    );
  }

  Widget _buildBrowserView() {
    return Column(
      children: [
        _buildNavigationBar(),
        if (_activeTab.isLoading)
          LinearProgressIndicator(
            value: _activeTab.loadingProgress / 100,
            backgroundColor: Colors.transparent,
            valueColor: const AlwaysStoppedAnimation<Color>(Color(0xFF7C3AED)),
            minHeight: 2,
          ),
        if (_breakpointEnabled) _buildBreakpointBanner(),
        Expanded(
          child: Stack(
            children: [
              WebViewWidget(controller: _activeTab.controller),
              if (_showMenu) _buildMenuOverlay(),
              if (_pendingRequests.isNotEmpty) _buildPendingIndicator(),
            ],
          ),
        ),
        _buildBottomBar(),
      ],
    );
  }

  // ══════════════════════════════════════════════════════════════════════════
  // NAVIGATION BAR (mesmo estilo Young Browser)
  // ══════════════════════════════════════════════════════════════════════════

  Widget _buildNavigationBar() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
      color: const Color(0xFF16213E),
      child: Row(
        children: [
          IconButton(
            icon: const Icon(Icons.arrow_back_ios, color: Colors.white54, size: 18),
            onPressed: () => _activeTab.controller.goBack(),
            padding: EdgeInsets.zero,
            constraints: const BoxConstraints(minWidth: 32, minHeight: 32),
          ),
          IconButton(
            icon: const Icon(Icons.arrow_forward_ios, color: Colors.white54, size: 18),
            onPressed: () => _activeTab.controller.goForward(),
            padding: EdgeInsets.zero,
            constraints: const BoxConstraints(minWidth: 32, minHeight: 32),
          ),
          IconButton(
            icon: const Icon(Icons.refresh, color: Colors.white54, size: 20),
            onPressed: () => _activeTab.controller.reload(),
            padding: EdgeInsets.zero,
            constraints: const BoxConstraints(minWidth: 32, minHeight: 32),
          ),
          const SizedBox(width: 4),
          // URL Bar
          Expanded(
            child: Container(
              height: 36,
              decoration: BoxDecoration(
                color: const Color(0xFF1A1A2E),
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: Colors.white12),
              ),
              child: TextField(
                controller: _urlController,
                style: const TextStyle(color: Colors.white, fontSize: 13),
                decoration: const InputDecoration(
                  hintText: 'Digite URL ou pesquise...',
                  hintStyle: TextStyle(color: Colors.white30, fontSize: 13),
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  prefixIcon: Icon(Icons.search, color: Colors.white30, size: 18),
                  prefixIconConstraints: BoxConstraints(minWidth: 36),
                  isDense: true,
                ),
                onSubmitted: _navigateToUrl,
                textInputAction: TextInputAction.go,
              ),
            ),
          ),
          const SizedBox(width: 4),
          // Tabs count
          GestureDetector(
            onTap: () => setState(() => _showTabsView = true),
            child: Container(
              width: 28,
              height: 28,
              decoration: BoxDecoration(
                border: Border.all(color: Colors.white54, width: 1.5),
                borderRadius: BorderRadius.circular(6),
              ),
              child: Center(
                child: Text('${_tabs.length}',
                    style: const TextStyle(color: Colors.white70, fontSize: 11, fontWeight: FontWeight.bold)),
              ),
            ),
          ),
          const SizedBox(width: 4),
          // Menu
          IconButton(
            icon: const Icon(Icons.more_vert, color: Colors.white70, size: 20),
            onPressed: () => setState(() => _showMenu = !_showMenu),
            padding: EdgeInsets.zero,
            constraints: const BoxConstraints(minWidth: 32, minHeight: 32),
          ),
        ],
      ),
    );
  }

  // ══════════════════════════════════════════════════════════════════════════
  // BOTTOM BAR
  // ══════════════════════════════════════════════════════════════════════════

  Widget _buildBottomBar() {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 6),
      decoration: const BoxDecoration(
        color: Color(0xFF1A1A2E),
        border: Border(top: BorderSide(color: Colors.white12)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          _buildBottomButton(
            icon: Icons.home,
            label: 'Home',
            onTap: () => _navigateToUrl('https://www.google.com'),
          ),
          _buildBottomButton(
            icon: Icons.bookmark_outline,
            label: 'Favoritos',
            color: Colors.cyanAccent,
            onTap: _showBookmarks,
          ),
          _buildBottomButton(
            icon: Icons.bug_report,
            label: 'Sniffer',
            color: const Color(0xFF7C3AED),
            onTap: _showSnifferPanel,
            badge: _capturedApis.isNotEmpty ? '${_capturedApis.length}' : null,
          ),
          _buildBottomButton(
            icon: _breakpointEnabled ? Icons.pause_circle_filled : Icons.pause_circle_outline,
            label: 'Breakpoint',
            color: _breakpointEnabled ? Colors.amber : Colors.white54,
            onTap: _showBreakpointPanel,
            badge: _pendingRequests.isNotEmpty ? '${_pendingRequests.length}' : null,
          ),
          // Nova aba
          _buildBottomButton(
            icon: Icons.add_box_outlined,
            label: 'Nova aba',
            onTap: () => _createNewTab('https://www.google.com'),
          ),
        ],
      ),
    );
  }

  Widget _buildBottomButton({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    Color? color,
    String? badge,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Stack(
              clipBehavior: Clip.none,
              children: [
                Icon(icon, color: color ?? Colors.white54, size: 20),
                if (badge != null)
                  Positioned(
                    right: -8,
                    top: -4,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 3, vertical: 1),
                      decoration: BoxDecoration(
                        color: const Color(0xFF7C3AED),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(badge, style: const TextStyle(color: Colors.white, fontSize: 7, fontWeight: FontWeight.bold)),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 2),
            Text(label, style: TextStyle(color: (color ?? Colors.white54).withOpacity(0.7), fontSize: 9)),
          ],
        ),
      ),
    );
  }

  // ══════════════════════════════════════════════════════════════════════════
  // TABS OVERVIEW
  // ══════════════════════════════════════════════════════════════════════════

  Widget _buildTabsOverview() {
    return Container(
      color: const Color(0xFF0F3460),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            child: Row(
              children: [
                Text('${_tabs.length} aba${_tabs.length > 1 ? 's' : ''}',
                    style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
                const Spacer(),
                IconButton(
                  icon: const Icon(Icons.add, color: Color(0xFF7C3AED), size: 24),
                  onPressed: () {
                    _createNewTab('https://www.google.com');
                    setState(() => _showTabsView = false);
                  },
                ),
                IconButton(
                  icon: const Icon(Icons.close, color: Colors.white70, size: 24),
                  onPressed: () => setState(() => _showTabsView = false),
                ),
              ],
            ),
          ),
          Expanded(
            child: GridView.builder(
              padding: const EdgeInsets.all(12),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 10,
                mainAxisSpacing: 10,
                childAspectRatio: 0.8,
              ),
              itemCount: _tabs.length,
              itemBuilder: (_, i) {
                final tab = _tabs[i];
                final isActive = i == _activeTabIndex;
                return GestureDetector(
                  onTap: () => _switchTab(i),
                  child: Container(
                    decoration: BoxDecoration(
                      color: const Color(0xFF16213E),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: isActive ? const Color(0xFF7C3AED) : Colors.white12,
                        width: isActive ? 2 : 1,
                      ),
                    ),
                    child: Column(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: const BoxDecoration(
                            border: Border(bottom: BorderSide(color: Colors.white12)),
                          ),
                          child: Row(
                            children: [
                              const Icon(Icons.public, size: 12, color: Colors.white38),
                              const SizedBox(width: 4),
                              Expanded(
                                child: Text(
                                  tab.title.isNotEmpty ? tab.title : 'Nova aba',
                                  style: const TextStyle(color: Colors.white70, fontSize: 10),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                              if (_tabs.length > 1)
                                GestureDetector(
                                  onTap: () => _closeTab(i),
                                  child: const Icon(Icons.close, size: 14, color: Colors.white38),
                                ),
                            ],
                          ),
                        ),
                        Expanded(
                          child: Padding(
                            padding: const EdgeInsets.all(8),
                            child: Text(
                              tab.currentUrl,
                              style: TextStyle(color: Colors.white.withOpacity(0.3), fontSize: 8, fontFamily: 'monospace'),
                              maxLines: 5,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  // ══════════════════════════════════════════════════════════════════════════
  // BREAKPOINT BANNER & PENDING
  // ══════════════════════════════════════════════════════════════════════════

  Widget _buildBreakpointBanner() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      color: Colors.amber.withOpacity(0.1),
      child: Row(
        children: [
          const Icon(Icons.pause_circle_filled, color: Colors.amber, size: 14),
          const SizedBox(width: 6),
          Text('BREAKPOINT ATIVO',
              style: TextStyle(color: Colors.amber.withOpacity(0.8), fontSize: 9, fontWeight: FontWeight.bold)),
          if (_pendingRequests.isNotEmpty) ...[
            const SizedBox(width: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
              decoration: BoxDecoration(color: Colors.amber, borderRadius: BorderRadius.circular(4)),
              child: Text('${_pendingRequests.length}',
                  style: const TextStyle(color: Colors.black, fontSize: 7, fontWeight: FontWeight.bold)),
            ),
          ],
          const Spacer(),
          GestureDetector(
            onTap: _toggleBreakpoint,
            child: const Text('DESLIGAR', style: TextStyle(color: Colors.redAccent, fontSize: 8, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  Widget _buildPendingIndicator() {
    return Positioned(
      bottom: 8,
      left: 8,
      right: 8,
      child: GestureDetector(
        onTap: _showBreakpointPanel,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          decoration: BoxDecoration(
            color: const Color(0xFF16213E).withOpacity(0.95),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: Colors.amber.withOpacity(0.5)),
          ),
          child: Row(
            children: [
              const Icon(Icons.pause_circle, color: Colors.amber, size: 18),
              const SizedBox(width: 8),
              Expanded(child: Text('${_pendingRequests.length} pausada(s)',
                  style: const TextStyle(color: Colors.amber, fontSize: 11, fontWeight: FontWeight.bold))),
              TextButton(
                onPressed: _forwardAllPending,
                child: const Text('Soltar', style: TextStyle(color: Colors.greenAccent, fontSize: 10)),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ══════════════════════════════════════════════════════════════════════════
  // MENU OVERLAY
  // ══════════════════════════════════════════════════════════════════════════

  Widget _buildMenuOverlay() {
    return Positioned(
      top: 0,
      right: 8,
      child: Material(
        color: Colors.transparent,
        child: Container(
          width: 240,
          decoration: BoxDecoration(
            color: const Color(0xFF16213E),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Colors.white12),
            boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.5), blurRadius: 20)],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _menuItem(Icons.add_box_outlined, 'Nova aba', () {
                setState(() => _showMenu = false);
                _createNewTab('https://www.google.com');
              }),
              _menuItem(Icons.bookmark_add_outlined, 'Adicionar favorito', () {
                setState(() => _showMenu = false);
                _addBookmark();
              }),
              _menuItem(Icons.history, 'Histórico', () {
                setState(() => _showMenu = false);
                _showHistoryPanel();
              }),
              _menuItem(Icons.share_outlined, 'Copiar URL', () {
                setState(() => _showMenu = false);
                Clipboard.setData(ClipboardData(text: _activeTab.currentUrl));
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('URL copiada!')));
              }),
              const Divider(color: Colors.white12, height: 1),
              _menuItem(Icons.bug_report, 'Sniffer (${_capturedApis.length})', () {
                setState(() => _showMenu = false);
                _showSnifferPanel();
              }),
              _menuItem(
                _breakpointEnabled ? Icons.pause_circle : Icons.pause_circle_outline,
                'Breakpoint ${_breakpointEnabled ? "ON" : "OFF"}',
                () { setState(() => _showMenu = false); _toggleBreakpoint(); },
              ),
              const Divider(color: Colors.white12, height: 1),
              _menuItem(Icons.delete_sweep, 'Limpar dados', () {
                setState(() => _showMenu = false);
                _clearAllData();
              }),
              _menuItem(Icons.close, 'Fechar menu', () => setState(() => _showMenu = false)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _menuItem(IconData icon, String label, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        child: Row(
          children: [
            Icon(icon, color: Colors.white60, size: 18),
            const SizedBox(width: 12),
            Expanded(child: Text(label, style: const TextStyle(color: Colors.white70, fontSize: 12))),
          ],
        ),
      ),
    );
  }

  // ══════════════════════════════════════════════════════════════════════════
  // BOOKMARKS / HISTORY / CLEAR
  // ══════════════════════════════════════════════════════════════════════════

  void _addBookmark() {
    if (_activeTab.currentUrl.isNotEmpty && !_bookmarks.contains(_activeTab.currentUrl)) {
      setState(() => _bookmarks.add(_activeTab.currentUrl));
      _saveBookmarks();
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Favorito adicionado!')));
    }
  }

  void _showBookmarks() {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF16213E),
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(16))),
      builder: (ctx) => Container(
        constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.5),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _panelHeader('Favoritos', Icons.bookmark),
            Flexible(
              child: _bookmarks.isEmpty
                  ? const Center(child: Padding(padding: EdgeInsets.all(32), child: Text('Nenhum favorito', style: TextStyle(color: Colors.white38))))
                  : ListView.builder(
                      shrinkWrap: true,
                      itemCount: _bookmarks.length,
                      itemBuilder: (_, i) => ListTile(
                        leading: const Icon(Icons.bookmark, color: Colors.cyanAccent, size: 16),
                        title: Text(_bookmarks[i], style: const TextStyle(color: Colors.white70, fontSize: 11), maxLines: 1, overflow: TextOverflow.ellipsis),
                        trailing: IconButton(
                          icon: const Icon(Icons.delete_outline, color: Colors.redAccent, size: 16),
                          onPressed: () { setState(() => _bookmarks.removeAt(i)); _saveBookmarks(); Navigator.pop(ctx); _showBookmarks(); },
                        ),
                        dense: true,
                        onTap: () { Navigator.pop(ctx); _navigateToUrl(_bookmarks[i]); },
                      ),
                    ),
            ),
          ],
        ),
      ),
    );
  }

  void _showHistoryPanel() {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF16213E),
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(16))),
      builder: (ctx) => Container(
        height: MediaQuery.of(context).size.height * 0.6,
        child: Column(
          children: [
            _panelHeader('Histórico', Icons.history),
            Expanded(
              child: _history.isEmpty
                  ? const Center(child: Text('Vazio', style: TextStyle(color: Colors.white38)))
                  : ListView.builder(
                      itemCount: _history.length,
                      itemBuilder: (_, i) {
                        final h = _history[i];
                        return ListTile(
                          leading: const Icon(Icons.public, color: Colors.white24, size: 16),
                          title: Text(h.title.isNotEmpty ? h.title : h.url, style: const TextStyle(color: Colors.white70, fontSize: 11), maxLines: 1, overflow: TextOverflow.ellipsis),
                          subtitle: Text(h.url, style: TextStyle(color: Colors.white.withOpacity(0.3), fontSize: 9), maxLines: 1, overflow: TextOverflow.ellipsis),
                          dense: true,
                          onTap: () { Navigator.pop(ctx); _navigateToUrl(h.url); },
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _clearAllData() async {
    await _activeTab.controller.clearCache();
    await _activeTab.controller.clearLocalStorage();
    try {
      await _activeTab.controller.runJavaScript('''
        try { localStorage.clear(); } catch(e) {}
        try { sessionStorage.clear(); } catch(e) {}
        try { document.cookie.split(";").forEach(function(c) { document.cookie = c.replace(/^ +/, "").replace(/=.*/, "=;expires=" + new Date().toUTCString() + ";path=/"); }); } catch(e) {}
      ''');
    } catch (_) {}
    setState(() {
      _allSiteCookies.clear();
      _capturedApis.clear();
      _pendingRequests.clear();
    });
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Dados limpos!')));
    }
  }

  Widget _panelHeader(String title, IconData icon) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          Icon(icon, color: const Color(0xFF7C3AED), size: 20),
          const SizedBox(width: 8),
          Text(title, style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }

  // ══════════════════════════════════════════════════════════════════════════
  // SNIFFER PANEL (Cookies + APIs)
  // ══════════════════════════════════════════════════════════════════════════

  void _showSnifferPanel() {
    _captureSiteCookies(_activeTab);
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF16213E),
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(16))),
      builder: (ctx) => _SnifferPanelWidget(
        allSiteCookies: _allSiteCookies,
        capturedApis: _capturedApis,
        onClearApis: () { setState(() => _capturedApis.clear()); Navigator.pop(ctx); },
      ),
    );
  }

  // ══════════════════════════════════════════════════════════════════════════
  // BREAKPOINT PANEL
  // ══════════════════════════════════════════════════════════════════════════

  void _showBreakpointPanel() {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF16213E),
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(16))),
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setModalState) => Container(
          height: MediaQuery.of(context).size.height * 0.7,
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(child: Container(width: 40, height: 4, decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2)))),
              const SizedBox(height: 12),
              Row(
                children: [
                  const Icon(Icons.pause_circle, color: Colors.amber, size: 22),
                  const SizedBox(width: 8),
                  const Text('Breakpoint', style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
                  const Spacer(),
                  Switch(value: _breakpointEnabled, activeColor: Colors.amber, onChanged: (v) { setState(() => _breakpointEnabled = v); setModalState(() {}); _syncBreakpointState(); }),
                ],
              ),
              const SizedBox(height: 8),
              if (_pendingRequests.isNotEmpty)
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(color: Colors.amber.withOpacity(0.05), borderRadius: BorderRadius.circular(8), border: Border.all(color: Colors.amber.withOpacity(0.2))),
                  child: Row(
                    children: [
                      const Icon(Icons.pause_circle, color: Colors.amber, size: 14),
                      const SizedBox(width: 6),
                      Text('${_pendingRequests.length} pausada(s)', style: const TextStyle(color: Colors.amber, fontSize: 11)),
                      const Spacer(),
                      TextButton(onPressed: () { _forwardAllPending(); setModalState(() {}); }, child: const Text('Soltar Todas', style: TextStyle(color: Colors.greenAccent, fontSize: 10))),
                    ],
                  ),
                ),
              const SizedBox(height: 8),
              OutlinedButton.icon(
                onPressed: () { setState(() => _breakpointRules.add(_BreakpointRule(urlPattern: '', method: '*', enabled: true))); setModalState(() {}); _syncBreakpointState(); },
                icon: const Icon(Icons.add, size: 14),
                label: const Text('Adicionar Regra', style: TextStyle(fontSize: 11)),
                style: OutlinedButton.styleFrom(foregroundColor: const Color(0xFF7C3AED), side: const BorderSide(color: Color(0xFF7C3AED))),
              ),
              const SizedBox(height: 8),
              Expanded(
                child: ListView(
                  children: [
                    ..._breakpointRules.asMap().entries.map((entry) {
                      final i = entry.key;
                      final rule = entry.value;
                      return Container(
                        margin: const EdgeInsets.only(bottom: 6),
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(color: const Color(0xFF1A1A2E), borderRadius: BorderRadius.circular(8)),
                        child: Row(
                          children: [
                            Switch(value: rule.enabled, activeColor: const Color(0xFF7C3AED), materialTapTargetSize: MaterialTapTargetSize.shrinkWrap, onChanged: (v) { setState(() => rule.enabled = v); setModalState(() {}); _syncBreakpointState(); }),
                            Text(rule.method, style: const TextStyle(color: Colors.white54, fontSize: 9, fontFamily: 'monospace')),
                            const SizedBox(width: 6),
                            Expanded(child: Text(rule.urlPattern.isEmpty ? '* (tudo)' : rule.urlPattern, style: TextStyle(color: Colors.white.withOpacity(0.5), fontSize: 9, fontFamily: 'monospace'))),
                            IconButton(icon: const Icon(Icons.delete, color: Colors.redAccent, size: 14), onPressed: () { setState(() => _breakpointRules.removeAt(i)); setModalState(() {}); _syncBreakpointState(); }, padding: EdgeInsets.zero, constraints: const BoxConstraints(minWidth: 28, minHeight: 28)),
                          ],
                        ),
                      );
                    }),
                    const SizedBox(height: 12),
                    if (_pendingRequests.isNotEmpty) ...[
                      const Text('Requisições Pausadas:', style: TextStyle(color: Colors.amber, fontSize: 11, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 4),
                      ..._pendingRequests.map((p) => Container(
                        margin: const EdgeInsets.only(bottom: 4),
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(color: Colors.amber.withOpacity(0.03), borderRadius: BorderRadius.circular(6), border: Border.all(color: Colors.amber.withOpacity(0.2))),
                        child: Row(
                          children: [
                            Container(padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2), decoration: BoxDecoration(color: Colors.amber.withOpacity(0.1), borderRadius: BorderRadius.circular(3)), child: Text(p.method, style: const TextStyle(color: Colors.amber, fontSize: 8, fontWeight: FontWeight.bold, fontFamily: 'monospace'))),
                            const SizedBox(width: 6),
                            Expanded(child: Text(p.url, style: TextStyle(color: Colors.white.withOpacity(0.5), fontSize: 8, fontFamily: 'monospace'), maxLines: 1, overflow: TextOverflow.ellipsis)),
                            IconButton(icon: const Icon(Icons.edit, color: Color(0xFF7C3AED), size: 14), onPressed: () { Navigator.pop(ctx); _showBreakpointEditor(p); }, padding: EdgeInsets.zero, constraints: const BoxConstraints(minWidth: 28)),
                            IconButton(icon: const Icon(Icons.play_arrow, color: Colors.greenAccent, size: 14), onPressed: () { _resolveBreakpoint(p, 'forward'); setModalState(() {}); }, padding: EdgeInsets.zero, constraints: const BoxConstraints(minWidth: 28)),
                            IconButton(icon: const Icon(Icons.block, color: Colors.redAccent, size: 14), onPressed: () { _resolveBreakpoint(p, 'block'); setModalState(() {}); }, padding: EdgeInsets.zero, constraints: const BoxConstraints(minWidth: 28)),
                          ],
                        ),
                      )),
                    ],
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ══════════════════════════════════════════════════════════════════════════
  // BREAKPOINT EDITOR
  // ══════════════════════════════════════════════════════════════════════════

  void _showBreakpointEditor(_PendingRequest req) {
    final urlCtrl = TextEditingController(text: req.url);
    final methodCtrl = TextEditingController(text: req.method);
    final bodyCtrl = TextEditingController(text: req.body ?? '');
    final headersCtrl = TextEditingController(text: req.headers.entries.map((e) => '${e.key}: ${e.value}').join('\n'));

    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF16213E),
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(16))),
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
        child: Container(
          height: MediaQuery.of(context).size.height * 0.85,
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(child: Container(width: 40, height: 4, decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2)))),
              const SizedBox(height: 12),
              Row(
                children: [
                  const Icon(Icons.edit_note, color: Colors.amber, size: 22),
                  const SizedBox(width: 8),
                  const Text('Editar Request', style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
                  const Spacer(),
                  Container(padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2), decoration: BoxDecoration(color: Colors.amber.withOpacity(0.1), borderRadius: BorderRadius.circular(4)), child: const Text('PAUSADA', style: TextStyle(color: Colors.amber, fontSize: 8, fontWeight: FontWeight.bold))),
                ],
              ),
              const SizedBox(height: 16),
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _editorLabel('MÉTODO'),
                      _editorField(methodCtrl, 'GET'),
                      const SizedBox(height: 10),
                      _editorLabel('URL'),
                      _editorField(urlCtrl, 'https://...', maxLines: 3),
                      const SizedBox(height: 10),
                      _editorLabel('HEADERS (Key: Value, um por linha)'),
                      _editorField(headersCtrl, 'Content-Type: application/json', maxLines: 8),
                      const SizedBox(height: 10),
                      _editorLabel('BODY'),
                      _editorField(bodyCtrl, '{"key":"value"}', maxLines: 6),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: () { Navigator.pop(ctx); _resolveBreakpoint(req, 'block'); },
                      icon: const Icon(Icons.block, size: 14),
                      label: const Text('Bloquear', style: TextStyle(fontSize: 10)),
                      style: ElevatedButton.styleFrom(backgroundColor: Colors.redAccent, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 10), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8))),
                    ),
                  ),
                  const SizedBox(width: 6),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () { Navigator.pop(ctx); _resolveBreakpoint(req, 'forward'); },
                      icon: const Icon(Icons.play_arrow, size: 14),
                      label: const Text('Soltar', style: TextStyle(fontSize: 10)),
                      style: OutlinedButton.styleFrom(foregroundColor: Colors.greenAccent, side: const BorderSide(color: Colors.greenAccent), padding: const EdgeInsets.symmetric(vertical: 10), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8))),
                    ),
                  ),
                  const SizedBox(width: 6),
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: () {
                        final editedHeaders = <String, String>{};
                        for (final line in headersCtrl.text.split('\n')) {
                          final idx = line.indexOf(':');
                          if (idx > 0) editedHeaders[line.substring(0, idx).trim()] = line.substring(idx + 1).trim();
                        }
                        Navigator.pop(ctx);
                        _resolveBreakpoint(req, 'modify', modifiedData: {
                          'url': urlCtrl.text,
                          'method': methodCtrl.text.toUpperCase(),
                          'headers': editedHeaders,
                          'body': bodyCtrl.text.isNotEmpty ? bodyCtrl.text : null,
                        });
                      },
                      icon: const Icon(Icons.send, size: 14),
                      label: const Text('Enviar', style: TextStyle(fontSize: 10)),
                      style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF7C3AED), foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 10), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8))),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _editorLabel(String t) => Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Text(t, style: TextStyle(color: Colors.white.withOpacity(0.4), fontSize: 9, fontWeight: FontWeight.bold)));

  Widget _editorField(TextEditingController c, String h, {int maxLines = 1}) => Container(
      decoration: BoxDecoration(color: const Color(0xFF1A1A2E), borderRadius: BorderRadius.circular(8), border: Border.all(color: Colors.white12)),
      child: TextField(
        controller: c,
        maxLines: maxLines,
        style: const TextStyle(color: Colors.white, fontSize: 11, fontFamily: 'monospace'),
        decoration: InputDecoration(hintText: h, hintStyle: TextStyle(color: Colors.white.withOpacity(0.2), fontSize: 11), border: InputBorder.none, contentPadding: const EdgeInsets.all(10)),
      ));
}

// ═══════════════════════════════════════════════════════════════════════════════
// MODELS
// ═══════════════════════════════════════════════════════════════════════════════

class _BrowserTab {
  String url;
  String currentUrl;
  String title;
  bool isLoading;
  int loadingProgress;
  late WebViewController controller;

  _BrowserTab({required this.url})
      : currentUrl = url,
        title = '',
        isLoading = true,
        loadingProgress = 0;
}

class _CapturedRequest {
  final int id;
  final String transport;
  final String method;
  final String fullUrl;
  final String hostname;
  final Map<String, String> requestHeaders;
  final String? body;
  final int timestamp;
  int? statusCode;
  String? statusText;
  Map<String, String>? responseHeaders;

  _CapturedRequest({
    required this.id,
    required this.transport,
    required this.method,
    required this.fullUrl,
    required this.hostname,
    required this.requestHeaders,
    this.body,
    required this.timestamp,
  });
}

class _PendingRequest {
  final int id;
  final String method;
  final String url;
  final Map<String, String> headers;
  final String? body;
  final String hostname;

  _PendingRequest({
    required this.id,
    required this.method,
    required this.url,
    required this.headers,
    this.body,
    required this.hostname,
  });
}

class _BreakpointRule {
  String urlPattern;
  String method;
  bool enabled;

  _BreakpointRule({required this.urlPattern, required this.method, required this.enabled});
}

class _HistoryEntry {
  final String url;
  final String title;
  final DateTime timestamp;

  _HistoryEntry({required this.url, required this.title, required this.timestamp});
}

// ═══════════════════════════════════════════════════════════════════════════════
// SNIFFER PANEL WIDGET
// ═══════════════════════════════════════════════════════════════════════════════

class _SnifferPanelWidget extends StatefulWidget {
  final Map<String, Map<String, String>> allSiteCookies;
  final List<_CapturedRequest> capturedApis;
  final VoidCallback onClearApis;

  const _SnifferPanelWidget({
    required this.allSiteCookies,
    required this.capturedApis,
    required this.onClearApis,
  });

  @override
  State<_SnifferPanelWidget> createState() => _SnifferPanelWidgetState();
}

class _SnifferPanelWidgetState extends State<_SnifferPanelWidget>
    with SingleTickerProviderStateMixin {
  late TabController _tabCtrl;
  String? _expDomain;
  int? _expApiId;

  @override
  void initState() {
    super.initState();
    _tabCtrl = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabCtrl.dispose();
    super.dispose();
  }

  int get _totalCookies {
    int t = 0;
    for (final s in widget.allSiteCookies.values) t += s.length;
    return t;
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height * 0.85,
      child: Column(
        children: [
          Container(margin: const EdgeInsets.only(top: 8), width: 40, height: 4, decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2))),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
            child: Row(
              children: [
                const Icon(Icons.bug_report, color: Color(0xFF7C3AED), size: 22),
                const SizedBox(width: 8),
                const Text('Network Sniffer', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(width: 6),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(color: Colors.greenAccent.withOpacity(0.1), borderRadius: BorderRadius.circular(4), border: Border.all(color: Colors.greenAccent.withOpacity(0.3))),
                  child: const Text('LIVE', style: TextStyle(color: Colors.greenAccent, fontSize: 8, fontWeight: FontWeight.bold)),
                ),
              ],
            ),
          ),
          const SizedBox(height: 8),
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 16),
            decoration: BoxDecoration(color: const Color(0xFF1A1A2E), borderRadius: BorderRadius.circular(10)),
            child: TabBar(
              controller: _tabCtrl,
              indicator: BoxDecoration(color: const Color(0xFF7C3AED).withOpacity(0.2), borderRadius: BorderRadius.circular(10)),
              indicatorSize: TabBarIndicatorSize.tab,
              labelColor: const Color(0xFF7C3AED),
              unselectedLabelColor: Colors.white38,
              labelStyle: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
              dividerColor: Colors.transparent,
              tabs: [
                Tab(child: Text('Cookies ($_totalCookies)')),
                Tab(child: Text('APIs (${widget.capturedApis.length})')),
              ],
            ),
          ),
          const SizedBox(height: 8),
          Expanded(child: TabBarView(controller: _tabCtrl, children: [_buildCookies(), _buildApis()])),
        ],
      ),
    );
  }

  Widget _buildCookies() {
    final domains = widget.allSiteCookies.keys.toList();
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: () {
                final b = StringBuffer();
                for (final e in widget.allSiteCookies.entries) {
                  b.writeln('=== ${e.key} ===');
                  for (final c in e.value.entries) b.writeln('${c.key}=${c.value}');
                  b.writeln();
                }
                Clipboard.setData(ClipboardData(text: b.toString()));
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Todos cookies copiados!')));
              },
              icon: const Icon(Icons.copy_all, size: 14),
              label: const Text('Copiar Todos', style: TextStyle(fontSize: 11)),
              style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF7C3AED), foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 8), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)), elevation: 0),
            ),
          ),
        ),
        const SizedBox(height: 8),
        Expanded(
          child: domains.isEmpty
              ? Center(child: Text('Navegue para capturar cookies', style: TextStyle(color: Colors.white.withOpacity(0.3))))
              : ListView.builder(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  itemCount: domains.length,
                  itemBuilder: (_, i) {
                    final d = domains[i];
                    final c = widget.allSiteCookies[d]!;
                    final exp = _expDomain == d;
                    return Container(
                      margin: const EdgeInsets.only(bottom: 8),
                      decoration: BoxDecoration(color: const Color(0xFF1A1A2E), borderRadius: BorderRadius.circular(10), border: Border.all(color: Colors.white12)),
                      child: Column(
                        children: [
                          InkWell(
                            onTap: () => setState(() => _expDomain = exp ? null : d),
                            child: Padding(
                              padding: const EdgeInsets.all(10),
                              child: Row(
                                children: [
                                  const Icon(Icons.language, size: 14, color: Color(0xFF7C3AED)),
                                  const SizedBox(width: 6),
                                  Expanded(child: Text(d, style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold), maxLines: 1, overflow: TextOverflow.ellipsis)),
                                  Text('${c.length}', style: TextStyle(color: Colors.white.withOpacity(0.3), fontSize: 9)),
                                  const SizedBox(width: 4),
                                  Icon(exp ? Icons.expand_less : Icons.expand_more, size: 16, color: Colors.white38),
                                ],
                              ),
                            ),
                          ),
                          if (exp) ...[
                            const Divider(color: Colors.white12, height: 1),
                            ...c.entries.map((e) {
                              final isAuth = e.key.toLowerCase().contains('session') || e.key.toLowerCase().contains('token') || e.key.toLowerCase().contains('auth');
                              return Padding(
                                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      children: [
                                        Icon(isAuth ? Icons.vpn_key : Icons.circle, size: 7, color: isAuth ? Colors.amber : Colors.white24),
                                        const SizedBox(width: 4),
                                        Expanded(child: Text(e.key, style: TextStyle(color: isAuth ? Colors.amber : Colors.white70, fontSize: 9, fontWeight: FontWeight.bold, fontFamily: 'monospace'))),
                                        GestureDetector(
                                          onTap: () { Clipboard.setData(ClipboardData(text: '${e.key}=${e.value}')); ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${e.key} copiado!'))); },
                                          child: const Icon(Icons.copy, size: 9, color: Colors.white24),
                                        ),
                                      ],
                                    ),
                                    Text(e.value.length > 80 ? '${e.value.substring(0, 80)}...' : e.value, style: TextStyle(color: Colors.white.withOpacity(0.3), fontSize: 7, fontFamily: 'monospace'), maxLines: 2),
                                  ],
                                ),
                              );
                            }),
                            const SizedBox(height: 4),
                          ],
                        ],
                      ),
                    );
                  },
                ),
        ),
      ],
    );
  }

  Widget _buildApis() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: () {
                    final b = StringBuffer();
                    for (final a in widget.capturedApis) {
                      b.writeln('[${a.method}] ${a.fullUrl}');
                      b.writeln('Status: ${a.statusCode ?? "?"} | Transport: ${a.transport}');
                      if (a.requestHeaders.isNotEmpty) { b.writeln('Req Headers:'); for (final h in a.requestHeaders.entries) b.writeln('  ${h.key}: ${h.value}'); }
                      if (a.body != null) b.writeln('Body: ${a.body}');
                      if (a.responseHeaders != null) { b.writeln('Resp Headers:'); for (final h in a.responseHeaders!.entries) b.writeln('  ${h.key}: ${h.value}'); }
                      b.writeln('---');
                    }
                    Clipboard.setData(ClipboardData(text: b.toString()));
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('APIs copiadas!')));
                  },
                  icon: const Icon(Icons.copy_all, size: 14),
                  label: const Text('Copiar', style: TextStyle(fontSize: 11)),
                  style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF7C3AED), foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 8), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)), elevation: 0),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: widget.onClearApis,
                  icon: const Icon(Icons.delete_outline, size: 14),
                  label: const Text('Limpar', style: TextStyle(fontSize: 11)),
                  style: OutlinedButton.styleFrom(foregroundColor: Colors.redAccent, side: const BorderSide(color: Colors.redAccent), padding: const EdgeInsets.symmetric(vertical: 8), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8))),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 8),
        Expanded(
          child: widget.capturedApis.isEmpty
              ? Center(child: Text('Navegue para capturar APIs', style: TextStyle(color: Colors.white.withOpacity(0.3))))
              : ListView.builder(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  itemCount: widget.capturedApis.length,
                  itemBuilder: (_, i) => _apiItem(widget.capturedApis[i]),
                ),
        ),
      ],
    );
  }

  Widget _apiItem(_CapturedRequest api) {
    final exp = _expApiId == api.id;
    Color mc;
    switch (api.method) {
      case 'GET': mc = Colors.greenAccent; break;
      case 'POST': mc = Colors.amber; break;
      case 'PUT': mc = Colors.blue; break;
      case 'DELETE': mc = Colors.redAccent; break;
      case 'WS': mc = Colors.purpleAccent; break;
      default: mc = Colors.white54;
    }
    Color? sc;
    if (api.statusCode != null) {
      if (api.statusCode! >= 200 && api.statusCode! < 300) sc = Colors.greenAccent;
      else if (api.statusCode! >= 300 && api.statusCode! < 400) sc = Colors.amber;
      else sc = Colors.redAccent;
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 4),
      decoration: BoxDecoration(color: const Color(0xFF1A1A2E), borderRadius: BorderRadius.circular(8), border: Border.all(color: exp ? const Color(0xFF7C3AED).withOpacity(0.4) : Colors.white12.withOpacity(0.3))),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          InkWell(
            onTap: () => setState(() => _expApiId = exp ? null : api.id),
            child: Padding(
              padding: const EdgeInsets.all(8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
                        decoration: BoxDecoration(color: mc.withOpacity(0.15), borderRadius: BorderRadius.circular(3), border: Border.all(color: mc.withOpacity(0.3))),
                        child: Text(api.method, style: TextStyle(color: mc, fontSize: 8, fontWeight: FontWeight.bold, fontFamily: 'monospace')),
                      ),
                      const SizedBox(width: 4),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 3, vertical: 1),
                        decoration: BoxDecoration(color: Colors.white.withOpacity(0.03), borderRadius: BorderRadius.circular(2)),
                        child: Text(api.transport, style: TextStyle(color: Colors.white.withOpacity(0.25), fontSize: 7, fontFamily: 'monospace')),
                      ),
                      const Spacer(),
                      if (api.statusCode != null) Text('${api.statusCode}', style: TextStyle(color: sc, fontSize: 9, fontWeight: FontWeight.bold, fontFamily: 'monospace')),
                      const SizedBox(width: 4),
                      Icon(exp ? Icons.expand_less : Icons.expand_more, size: 12, color: Colors.white38),
                    ],
                  ),
                  const SizedBox(height: 3),
                  Text(api.fullUrl, style: TextStyle(color: Colors.white.withOpacity(0.6), fontSize: 8, fontFamily: 'monospace'), maxLines: exp ? 10 : 1, overflow: TextOverflow.ellipsis),
                ],
              ),
            ),
          ),
          if (exp) ...[
            const Divider(color: Colors.white12, height: 1),
            Padding(
              padding: const EdgeInsets.all(8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (api.requestHeaders.isNotEmpty) ...[
                    Text('REQUEST HEADERS', style: TextStyle(color: Colors.white.withOpacity(0.3), fontSize: 7, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 2),
                    ...api.requestHeaders.entries.map((h) {
                      final isAuth = h.key.toLowerCase().contains('auth') || h.key.toLowerCase().contains('cookie') || h.key.toLowerCase().contains('token');
                      return Text('${h.key}: ${h.value}', style: TextStyle(color: isAuth ? Colors.amber.withOpacity(0.7) : Colors.white.withOpacity(0.4), fontSize: 7, fontFamily: 'monospace'), maxLines: 2, overflow: TextOverflow.ellipsis);
                    }),
                    const SizedBox(height: 6),
                  ],
                  if (api.body != null) ...[
                    Text('BODY', style: TextStyle(color: Colors.white.withOpacity(0.3), fontSize: 7, fontWeight: FontWeight.bold)),
                    Text(api.body!, style: TextStyle(color: Colors.white.withOpacity(0.4), fontSize: 7, fontFamily: 'monospace'), maxLines: 5),
                    const SizedBox(height: 6),
                  ],
                  if (api.responseHeaders != null && api.responseHeaders!.isNotEmpty) ...[
                    Text('RESPONSE HEADERS', style: TextStyle(color: Colors.white.withOpacity(0.3), fontSize: 7, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 2),
                    ...api.responseHeaders!.entries.map((h) => Text('${h.key}: ${h.value}', style: TextStyle(color: Colors.white.withOpacity(0.4), fontSize: 7, fontFamily: 'monospace'), maxLines: 2)),
                    const SizedBox(height: 6),
                  ],
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      onPressed: () {
                        final b = StringBuffer();
                        b.writeln('[${api.method}] ${api.fullUrl}');
                        b.writeln('Status: ${api.statusCode} ${api.statusText}');
                        b.writeln('Transport: ${api.transport}');
                        if (api.requestHeaders.isNotEmpty) { b.writeln('\nRequest Headers:'); for (final h in api.requestHeaders.entries) b.writeln('  ${h.key}: ${h.value}'); }
                        if (api.body != null) b.writeln('\nBody: ${api.body}');
                        if (api.responseHeaders != null) { b.writeln('\nResponse Headers:'); for (final h in api.responseHeaders!.entries) b.writeln('  ${h.key}: ${h.value}'); }
                        Clipboard.setData(ClipboardData(text: b.toString()));
                        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Copiado!')));
                      },
                      icon: const Icon(Icons.copy_all, size: 10),
                      label: const Text('Copiar Completo', style: TextStyle(fontSize: 9)),
                      style: OutlinedButton.styleFrom(foregroundColor: const Color(0xFF7C3AED), side: const BorderSide(color: Color(0xFF7C3AED)), padding: const EdgeInsets.symmetric(vertical: 4), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6))),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }
}
