import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:webview_flutter_android/webview_flutter_android.dart';
import 'anti_detect.dart';
import 'auth_service.dart';
import 'device_config_screen.dart';
import 'webview_api_bridge.dart';
import 'browser_screen.dart';

// ═══════════════════════════════════════════════════════════════════════════════
// Login Screen v12 - Anti-Ban + Reset Total + fgRequestId
// Um clique reseta tudo: novo dispositivo, limpa cookies, limpa cache
// ═══════════════════════════════════════════════════════════════════════════════
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  AuthService _auth = AuthService();
  WebViewApiBridgeController? _bridgeController;
  final GlobalKey<WebViewApiBridgeState> _bridgeKey = GlobalKey();
  bool _isLoading = false;
  bool _bridgeReady = false;
  bool _isResetting = false;
  int _currentView = 0; // 0=login, 1=tokens, 2=explorer

  final Map<String, String> _stepStatus = {
    'OAuth2 Authorize': 'pending',
    'Google Login': 'pending',
    'Session Cookie': 'pending',
    'WebView Bridge': 'pending',
    'User Info': 'pending',
  };

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D0D1A),
      body: SafeArea(
        child: Stack(
          children: [
            Positioned.fill(
              child: _currentView == 0
                  ? _buildLoginView()
                  : _currentView == 1
                      ? _buildTokensView()
                      : _buildExplorerView(),
            ),
            // WebView Bridge invisível
            Positioned(
              left: -9999,
              top: -9999,
              width: 10,
              height: 10,
              child: WebViewApiBridge(
                key: _bridgeKey,
                deviceProfile: _auth.profile,
                onReady: (controller) {
                  debugPrint('[Screen] Bridge pronto com DCR!');
                  setState(() {
                    _bridgeController = controller;
                    _bridgeReady = true;
                    _auth.setBridge(controller);
                  });
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── Login View ──────────────────────────────────────────────────────────────
  Widget _buildLoginView() {
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Logo
            Container(
              width: 80,
              height: 80,
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF7C3AED), Color(0xFF2563EB)],
                ),
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFF7C3AED).withOpacity(0.4),
                    blurRadius: 20,
                    offset: const Offset(0, 8),
                  ),
                ],
              ),
              child: const Icon(Icons.shield, color: Colors.white, size: 40),
            ),
            const SizedBox(height: 20),
            const Text(
              'Manus Login',
              style: TextStyle(
                color: Colors.white,
                fontSize: 28,
                fontWeight: FontWeight.bold,
                letterSpacing: -0.5,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              'v12 - Anti-Ban + Reset Total',
              style:
                  TextStyle(color: Colors.white.withOpacity(0.4), fontSize: 13),
            ),
            const SizedBox(height: 32),

            // Device Profile Info
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.blue.withOpacity(0.08),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.blue.withOpacity(0.2)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(Icons.fingerprint,
                          size: 14,
                          color: Colors.lightBlueAccent.withOpacity(0.7)),
                      const SizedBox(width: 6),
                      Text('DEVICE PROFILE',
                          style: TextStyle(
                              color: Colors.lightBlueAccent.withOpacity(0.7),
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 1)),
                    ],
                  ),
                  const SizedBox(height: 6),
                  _profileRow('Client ID', _auth.profile.clientId),
                  _profileRow('FP Request', _auth.profile.fgRequestId),
                  _profileRow('Visitor ID', _auth.profile.visitorId),
                  _profileRow('Locale', _auth.profile.locale),
                  _profileRow('Timezone', _auth.profile.timezone),
                  _profileRow('UA',
                      '...${_auth.profile.userAgent.substring(_auth.profile.userAgent.length - 40)}'),
                ],
              ),
            ),

            const SizedBox(height: 14),

            // ══════════════════════════════════════════════════════════════════
            // BOTÃO PRINCIPAL: RESETAR TUDO + NOVO DISPOSITIVO
            // ══════════════════════════════════════════════════════════════════
            SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton.icon(
                onPressed: (_isLoading || _isResetting) ? null : _resetTudo,
                icon: _isResetting
                    ? const SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(
                            strokeWidth: 2, color: Colors.white))
                    : const Icon(Icons.restart_alt, size: 22),
                label: Text(
                    _isResetting
                        ? 'Limpando tudo...'
                        : 'Resetar Tudo + Novo Dispositivo',
                    style: const TextStyle(
                        fontSize: 14, fontWeight: FontWeight.bold)),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.redAccent.shade700,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12)),
                  elevation: 0,
                ),
              ),
            ),

            const SizedBox(height: 10),

            // Botões secundários
            Row(
              children: [
                // Configurar Dispositivo
                Expanded(
                  child: SizedBox(
                    height: 44,
                    child: OutlinedButton.icon(
                      onPressed: _isLoading ? null : _openDeviceConfig,
                      icon: const Icon(Icons.settings, size: 14),
                      label: const Text('Configurar',
                          style: TextStyle(fontSize: 12)),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: const Color(0xFF7C3AED),
                        side: const BorderSide(color: Color(0xFF7C3AED)),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12)),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                // Gerar Novo Dispositivo (sem limpar cookies)
                Expanded(
                  child: SizedBox(
                    height: 44,
                    child: OutlinedButton.icon(
                      onPressed: _isLoading ? null : _regenerateDevice,
                      icon: const Icon(Icons.casino, size: 14),
                      label: const Text('Novo Device',
                          style: TextStyle(fontSize: 12)),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: Colors.orangeAccent,
                        side: const BorderSide(color: Colors.orangeAccent),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12)),
                      ),
                    ),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 16),

            // Login Button
            SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton(
                onPressed: _isLoading ? null : _startWebLogin,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.white,
                  foregroundColor: Colors.black87,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12)),
                  elevation: 0,
                ),
                child: _isLoading
                    ? const SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(strokeWidth: 2))
                    : const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          _GoogleIcon(),
                          SizedBox(width: 10),
                          Text('Entrar com Google',
                              style: TextStyle(
                                  fontSize: 15, fontWeight: FontWeight.w600)),
                        ],
                      ),
              ),
            ),

            const SizedBox(height: 24),

            // Botão Navegador (disponível mesmo sem login)
            SizedBox(
              width: double.infinity,
              height: 48,
              child: OutlinedButton.icon(
                onPressed: _isLoading ? null : _openBrowser,
                icon: const Icon(Icons.public, size: 18),
                label: const Text('Abrir Navegador',
                    style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
                style: OutlinedButton.styleFrom(
                  foregroundColor: const Color(0xFF2563EB),
                  side: const BorderSide(color: Color(0xFF2563EB)),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12)),
                ),
              ),
            ),
            const SizedBox(height: 16),

            // Auth flow status
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: const Color(0xFF1A1A2E),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: const Color(0xFF2A2A4A)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('FLUXO DE AUTENTICAÇÃO',
                      style: TextStyle(
                          color: Colors.white.withOpacity(0.3),
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1.5)),
                  const SizedBox(height: 10),
                  _buildStepRow('1. OAuth2 Authorize (com DCR)',
                      _stepStatus['OAuth2 Authorize']!),
                  _buildStepRow('2. Google Login (WebView)',
                      _stepStatus['Google Login']!),
                  _buildStepRow(
                      '3. Session Cookie', _stepStatus['Session Cookie']!),
                  _buildStepRow('4. WebView Bridge (com DCR)',
                      _stepStatus['WebView Bridge']!),
                  _buildStepRow('5. User Info (via HTTP)',
                      _stepStatus['User Info']!),
                ],
              ),
            ),

            // Anti-ban info
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.green.withOpacity(0.08),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.green.withOpacity(0.2)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(Icons.verified_user,
                          size: 14,
                          color: Colors.greenAccent.withOpacity(0.7)),
                      const SizedBox(width: 6),
                      Text('PROTEÇÃO ANTI-BAN',
                          style: TextStyle(
                              color: Colors.greenAccent.withOpacity(0.7),
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 1)),
                    ],
                  ),
                  const SizedBox(height: 6),
                  _protectionRow('x-client-dcr', true),
                  _protectionRow('x-client-id (único)', true),
                  _protectionRow('fgRequestId (FingerprintJS)', true),
                  _protectionRow('visitorId (FingerprintJS)', true),
                  _protectionRow('Sec-Ch-Ua headers', true),
                  _protectionRow('Limpeza cookies/cache', true),
                  _protectionRow('User-Agent Chrome real', true),
                ],
              ),
            ),

            // Logs
            if (_auth.logs.isNotEmpty) ...[
              const SizedBox(height: 16),
              Text('LOG',
                  style: TextStyle(
                      color: Colors.white.withOpacity(0.3),
                      fontSize: 10,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1.5)),
              const SizedBox(height: 8),
              Container(
                constraints: const BoxConstraints(maxHeight: 300),
                child: ListView.builder(
                  shrinkWrap: true,
                  itemCount: _auth.logs.length,
                  itemBuilder: (ctx, i) => _buildLogEntry(_auth.logs[i]),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  // ══════════════════════════════════════════════════════════════════════════
  // RESETAR TUDO - Limpa cookies, cache, dados, gera novo dispositivo
  // ══════════════════════════════════════════════════════════════════════════
  Future<void> _resetTudo() async {
    setState(() => _isResetting = true);

    try {
      // 1. Limpar TODOS os cookies do WebView (incluindo httpOnly)
      final cookieManager = WebViewCookieManager();
      await cookieManager.clearCookies();
      debugPrint('[Reset] Cookies do WebView limpos');

      // 2. Limpar cache e dados do WebView Bridge
      if (_bridgeKey.currentState != null) {
        try {
          await _bridgeKey.currentState!.clearAllData();
        } catch (e) {
          debugPrint('[Reset] Erro ao limpar bridge: $e');
        }
      }

      // 3. Gerar novo dispositivo completamente diferente
      final newProfile = generateDeviceProfile();

      // 4. Resetar estado de autenticação
      setState(() {
        _auth = AuthService.withProfile(newProfile);
        _bridgeReady = false;
        _bridgeController = null;
        _currentView = 0;
        _stepStatus.updateAll((key, value) => 'pending');
      });

      debugPrint('[Reset] Novo dispositivo: ${newProfile.clientId}');
      debugPrint('[Reset] Novo fgRequestId: ${newProfile.fgRequestId}');
      debugPrint('[Reset] Novo visitorId: ${newProfile.visitorId}');

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Row(
              children: const [
                Icon(Icons.check_circle, color: Colors.white, size: 18),
                SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Tudo resetado! Novo dispositivo, cookies limpos, cache limpo.',
                    style: TextStyle(fontSize: 12),
                  ),
                ),
              ],
            ),
            backgroundColor: Colors.green.shade700,
            behavior: SnackBarBehavior.floating,
            duration: const Duration(seconds: 3),
          ),
        );
      }
    } catch (e) {
      debugPrint('[Reset] Erro: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Erro no reset: $e'),
            backgroundColor: Colors.red,
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
    } finally {
      setState(() => _isResetting = false);
    }
  }

  /// Abre a tela de configuração de dispositivo
  Future<void> _openDeviceConfig() async {
    final result = await Navigator.push<DeviceProfile>(
      context,
      MaterialPageRoute(
        builder: (_) => DeviceConfigScreen(currentProfile: _auth.profile),
      ),
    );
    if (result != null && mounted) {
      setState(() {
        _auth = AuthService.withProfile(result);
        _bridgeReady = false;
        _bridgeController = null;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Perfil de dispositivo atualizado!'),
          backgroundColor: Color(0xFF7C3AED),
          behavior: SnackBarBehavior.floating,
        ),
      );
    }
  }

  /// Gera um novo dispositivo aleatório sem limpar cookies
  void _regenerateDevice() {
    setState(() {
      _auth = AuthService();
      _bridgeReady = false;
      _bridgeController = null;
    });
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Novo dispositivo gerado! (cookies mantidos)'),
        backgroundColor: Colors.orangeAccent,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  Widget _profileRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 1),
      child: Row(
        children: [
          SizedBox(
            width: 75,
            child: Text(label,
                style: TextStyle(
                    color: Colors.white.withOpacity(0.3),
                    fontSize: 9,
                    fontFamily: 'monospace')),
          ),
          Expanded(
            child: Text(value,
                style: TextStyle(
                    color: Colors.white.withOpacity(0.6),
                    fontSize: 9,
                    fontFamily: 'monospace'),
                overflow: TextOverflow.ellipsis),
          ),
        ],
      ),
    );
  }

  Widget _protectionRow(String label, bool active) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 1),
      child: Row(
        children: [
          Icon(active ? Icons.check : Icons.close,
              size: 10,
              color: active ? Colors.greenAccent : Colors.redAccent),
          const SizedBox(width: 4),
          Text(label,
              style: TextStyle(
                  color: Colors.white.withOpacity(0.5),
                  fontSize: 9,
                  fontFamily: 'monospace')),
        ],
      ),
    );
  }

  Widget _buildStepRow(String label, String status) {
    IconData icon;
    Color color;
    switch (status) {
      case 'success':
        icon = Icons.check_circle;
        color = Colors.greenAccent;
        break;
      case 'loading':
        icon = Icons.hourglass_top;
        color = Colors.amber;
        break;
      case 'error':
        icon = Icons.error;
        color = Colors.redAccent;
        break;
      default:
        icon = Icons.radio_button_unchecked;
        color = Colors.white.withOpacity(0.2);
    }

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        children: [
          Icon(icon, size: 16, color: color),
          const SizedBox(width: 8),
          Expanded(
            child: Text(label,
                style: TextStyle(
                  color:
                      status == 'success' ? color : Colors.white.withOpacity(0.6),
                  fontSize: 12,
                  fontWeight:
                      status == 'success' ? FontWeight.bold : FontWeight.normal,
                )),
          ),
        ],
      ),
    );
  }

  Widget _buildLogEntry(AuthLog log) {
    Color bgColor;
    Color iconColor;
    IconData icon;
    switch (log.status) {
      case 'success':
        bgColor = Colors.green.withOpacity(0.08);
        iconColor = Colors.greenAccent;
        icon = Icons.check_circle;
        break;
      case 'error':
        bgColor = Colors.red.withOpacity(0.08);
        iconColor = Colors.redAccent;
        icon = Icons.error;
        break;
      case 'warning':
        bgColor = Colors.amber.withOpacity(0.08);
        iconColor = Colors.amber;
        icon = Icons.warning;
        break;
      default:
        bgColor = Colors.blue.withOpacity(0.05);
        iconColor = Colors.lightBlueAccent;
        icon = Icons.info;
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 4),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
          color: bgColor, borderRadius: BorderRadius.circular(8)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Icon(icon, size: 12, color: iconColor),
            const SizedBox(width: 6),
            Expanded(
              child: Text('${log.step}: ${log.message}',
                  style: TextStyle(
                      color: Colors.white.withOpacity(0.7),
                      fontSize: 11,
                      fontFamily: 'monospace')),
            ),
          ]),
          if (log.details != null)
            Padding(
              padding: const EdgeInsets.only(top: 4, left: 18),
              child: Text(log.details.toString(),
                  style: TextStyle(
                      color: Colors.white.withOpacity(0.35),
                      fontSize: 9,
                      fontFamily: 'monospace'),
                  maxLines: 3,
                  overflow: TextOverflow.ellipsis),
            ),
        ],
      ),
    );
  }

  // ── Web Login Flow ────────────────────────────────────────────────────────
  Future<void> _startWebLogin() async {
    setState(() {
      _isLoading = true;
      _auth.logs.clear();
      _stepStatus.updateAll((key, value) => 'pending');
    });

    // *** LIMPEZA AUTOMÁTICA ANTES DO LOGIN ***
    _auth.logs.add(AuthLog(
      step: 'Cleanup',
      status: 'info',
      message: 'Limpando cookies e cache antes do login...',
    ));
    setState(() {});

    try {
      final cookieManager = WebViewCookieManager();
      await cookieManager.clearCookies();
      _auth.logs.add(AuthLog(
        step: 'Cleanup',
        status: 'success',
        message: 'Cookies limpos!',
      ));
    } catch (e) {
      _auth.logs.add(AuthLog(
        step: 'Cleanup',
        status: 'warning',
        message: 'Erro ao limpar cookies: $e',
      ));
    }
    setState(() {});

    // Step 1: Get OAuth2 Authorize URL (com DCR + fgRequestId!)
    setState(() => _stepStatus['OAuth2 Authorize'] = 'loading');
    final redirectUrl = await _auth.getOauth2AuthorizeUrl();

    if (redirectUrl == null) {
      setState(() {
        _stepStatus['OAuth2 Authorize'] = 'error';
        _isLoading = false;
      });
      return;
    }
    setState(() => _stepStatus['OAuth2 Authorize'] = 'success');

    // Step 2: Open WebView for Google Login
    setState(() => _stepStatus['Google Login'] = 'loading');

    if (!mounted) return;
    final result = await Navigator.push<Map<String, dynamic>>(
      context,
      MaterialPageRoute(
        builder: (_) => _ManusWebLoginView(
          redirectUrl: redirectUrl,
          userAgent: _auth.profile.userAgent,
        ),
      ),
    );

    if (result == null) {
      setState(() {
        _stepStatus['Google Login'] = 'error';
        _isLoading = false;
      });
      _auth.logs.add(AuthLog(
          step: 'Google Login',
          status: 'error',
          message: 'Login cancelado'));
      setState(() {});
      return;
    }

    setState(() => _stepStatus['Google Login'] = 'success');

    // Step 3: Process session data
    setState(() => _stepStatus['Session Cookie'] = 'loading');

    final cookies = result['cookies'] as Map<String, String>? ?? {};
    final token = result['token'] as String?;
    final finalUrl = result['finalUrl'] as String?;

    _auth.logs.add(AuthLog(
      step: 'Session',
      status: 'info',
      message: 'Dados recebidos do WebView',
      details: {
        'cookies_count': cookies.length,
        'cookie_names': cookies.keys.toList(),
        'has_token': token != null,
        'final_url': finalUrl,
      },
    ));

    if (token != null && token.isNotEmpty) {
      _auth.processSessionToken(token);
    }
    if (cookies.isNotEmpty) {
      _auth.processSessionCookies(cookies);
    }

    // Tentar extrair token da URL final
    if (!_auth.state.hasSession && finalUrl != null) {
      final uri = Uri.tryParse(finalUrl);
      if (uri != null) {
        if (uri.fragment.isNotEmpty) {
          final fragParams = Uri.splitQueryString(uri.fragment);
          for (final key in ['token', 'access_token', 'session', 'jwt']) {
            if (fragParams.containsKey(key)) {
              _auth.processSessionToken(fragParams[key]!);
              break;
            }
          }
        }
        for (final key in ['token', 'access_token', 'session', 'jwt']) {
          if (uri.queryParameters.containsKey(key)) {
            _auth.processSessionToken(uri.queryParameters[key]!);
            break;
          }
        }
      }
    }

    setState(() => _stepStatus['Session Cookie'] = 'success');
    _auth.logs.add(AuthLog(
      step: 'Session',
      status: 'success',
      message: 'Cookies processados.',
    ));

    // Step 4: Bridge (background, não bloqueia)
    setState(() => _stepStatus['WebView Bridge'] = 'loading');
    _bridgeKey.currentState?.activate().then((_) {}).catchError((_) {});
    setState(() => _stepStatus['WebView Bridge'] = 'success');
    _auth.logs.add(AuthLog(
      step: 'Bridge',
      status: 'success',
      message: 'Bridge iniciado em background.',
    ));

    // Step 5: Fetch User Info via HTTP direto
    setState(() => _stepStatus['User Info'] = 'loading');
    await _auth.runPostLoginFlow(
      onProgress: (step, status) {
        setState(() => _stepStatus[step] = status);
      },
    );

    setState(() => _isLoading = false);

    // Mudar para view de tokens
    if (_auth.state.hasUserInfo || _auth.state.hasSession) {
      setState(() => _currentView = 1);
    }
  }

  // ── Abrir Navegador Integrado ───────────────────────────────────────────────────────
  void _openBrowser() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => BrowserScreen(
          deviceProfile: _auth.profile,
          initialUrl: 'https://manus.im',
          cookies: _auth.state.cookies,
        ),
      ),
    );
  }

  // ── Tokens View ─────────────────────────────────────────────────────────────────
  Widget _buildTokensView() {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
          color: const Color(0xFF1A1A2E),
          child: Row(
            children: [
              IconButton(
                icon: const Icon(Icons.arrow_back, color: Colors.white),
                onPressed: () => setState(() => _currentView = 0),
              ),
              const Expanded(
                child: Text('Tokens & API',
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.bold)),
              ),
              // Botão Navegador na tela de tokens
              IconButton(
                icon: const Icon(Icons.public, color: Color(0xFF2563EB)),
                onPressed: _openBrowser,
                tooltip: 'Abrir Navegador',
              ),
              // Botão Resetar na tela de tokens
              IconButton(
                icon: const Icon(Icons.restart_alt, color: Colors.redAccent),
                onPressed: () async {
                  await _resetTudo();
                  setState(() => _currentView = 0);
                },
                tooltip: 'Resetar Tudo',
              ),
              IconButton(
                icon: const Icon(Icons.copy, color: Colors.white54),
                onPressed: _copyAllTokens,
                tooltip: 'Copiar',
              ),
            ],
          ),
        ),
        Expanded(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildUserCard(),
                const SizedBox(height: 16),
                _buildAuthFlowCard(),
                const SizedBox(height: 16),

                if (_auth.logs.isNotEmpty) ...[
                  Text('AUTH LOGS',
                      style: TextStyle(
                          color: Colors.white.withOpacity(0.3),
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1.5)),
                  const SizedBox(height: 8),
                  ...(_auth.logs.map(_buildLogEntry)),
                  const SizedBox(height: 16),
                ],

                Text('TOKENS',
                    style: TextStyle(
                        color: Colors.white.withOpacity(0.3),
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1.5)),
                const SizedBox(height: 8),
                ..._auth.state
                    .toTokenMap()
                    .entries
                    .map((e) => _buildTokenCard(e.key, e.value)),

                if (_auth.state.userInfo != null) ...[
                  const SizedBox(height: 16),
                  Text('USER INFO',
                      style: TextStyle(
                          color: Colors.white.withOpacity(0.3),
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1.5)),
                  const SizedBox(height: 8),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: const Color(0xFF1A1A2E),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: const Color(0xFF2A2A4A)),
                    ),
                    child: Text(
                      const JsonEncoder.withIndent('  ')
                          .convert(_auth.state.userInfo),
                      style: TextStyle(
                          color: Colors.white.withOpacity(0.6),
                          fontSize: 10,
                          fontFamily: 'monospace'),
                    ),
                  ),
                ],

                const SizedBox(height: 20),

                // ══════════════════════════════════════════════════════════
                // BOTÃO NAVEGADOR INTEGRADO
                // ══════════════════════════════════════════════════════════
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: () => _openBrowser(),
                    icon: const Icon(Icons.public, size: 20),
                    label: const Text('Abrir Navegador',
                        style: TextStyle(
                            fontSize: 14, fontWeight: FontWeight.bold)),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF2563EB),
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10)),
                    ),
                  ),
                ),
                const SizedBox(height: 10),

                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: _auth.state.hasSession
                        ? () => setState(() => _currentView = 2)
                        : null,
                    icon: const Icon(Icons.card_giftcard),
                    label: Text(_auth.state.hasSession
                        ? 'Adicionar Código de Convite'
                        : 'Faça login primeiro'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF7C3AED),
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10)),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildUserCard() {
    final isAuth = _auth.state.hasUserInfo;
    final isBlocked = _auth.state.isBlocked;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: isBlocked
              ? [const Color(0xFF5F1E1E), const Color(0xFF1A1A2E)]
              : isAuth
                  ? [const Color(0xFF1E3A5F), const Color(0xFF1A1A2E)]
                  : [const Color(0xFF3A1E1E), const Color(0xFF1A1A2E)],
        ),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: isBlocked
              ? Colors.red.withOpacity(0.5)
              : isAuth
                  ? Colors.blue.withOpacity(0.3)
                  : Colors.red.withOpacity(0.3),
        ),
      ),
      child: Row(
        children: [
          CircleAvatar(
            radius: 22,
            backgroundColor: const Color(0xFF7C3AED),
            child: Text(
              (_auth.state.googleName ??
                      _auth.state.displayName ??
                      '?')[0]
                  .toUpperCase(),
              style: const TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.bold),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  _auth.state.displayName ??
                      _auth.state.googleName ??
                      'Usuário',
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                      fontWeight: FontWeight.bold),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                Text(
                  _auth.state.googleEmail ?? '',
                  style: TextStyle(
                      color: Colors.white.withOpacity(0.5), fontSize: 12),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                if (isBlocked)
                  Text(
                    'BLOQUEADO: ${_auth.state.blockMessage ?? "403"}',
                    style: const TextStyle(
                        color: Colors.redAccent,
                        fontSize: 10,
                        fontWeight: FontWeight.bold),
                  ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: isBlocked
                  ? Colors.red.withOpacity(0.15)
                  : isAuth
                      ? Colors.green.withOpacity(0.15)
                      : Colors.amber.withOpacity(0.15),
              borderRadius: BorderRadius.circular(6),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                    isBlocked
                        ? Icons.block
                        : isAuth
                            ? Icons.check_circle
                            : Icons.warning,
                    size: 12,
                    color: isBlocked
                        ? Colors.redAccent
                        : isAuth
                            ? Colors.greenAccent
                            : Colors.amber),
                const SizedBox(width: 4),
                Text(
                    isBlocked
                        ? 'Ban'
                        : isAuth
                            ? 'Auth'
                            : 'Parcial',
                    style: TextStyle(
                        color: isBlocked
                            ? Colors.redAccent
                            : isAuth
                                ? Colors.greenAccent
                                : Colors.amber,
                        fontSize: 10,
                        fontWeight: FontWeight.bold)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAuthFlowCard() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFF1A1A2E),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFF2A2A4A)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('FLUXO DE AUTENTICAÇÃO',
              style: TextStyle(
                  color: Colors.white.withOpacity(0.3),
                  fontSize: 10,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1.5)),
          const SizedBox(height: 10),
          _buildStepRow('1. OAuth2 Authorize (com DCR)',
              _stepStatus['OAuth2 Authorize']!),
          _buildStepRow(
              '2. Google Login (WebView)', _stepStatus['Google Login']!),
          _buildStepRow('3. Session Cookie', _stepStatus['Session Cookie']!),
          _buildStepRow(
              '4. WebView Bridge (com DCR)', _stepStatus['WebView Bridge']!),
          _buildStepRow('5. User Info (via HTTP)', _stepStatus['User Info']!),
        ],
      ),
    );
  }

  Widget _buildTokenCard(String name, String value) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: const Color(0xFF1A1A2E),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: const Color(0xFF2A2A4A)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Expanded(
              child: Text(name,
                  style: const TextStyle(
                      color: Color(0xFF7C3AED),
                      fontSize: 11,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'monospace')),
            ),
            GestureDetector(
              onTap: () {
                Clipboard.setData(ClipboardData(text: value));
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                      content: Text('$name copiado!'),
                      duration: const Duration(seconds: 1)),
                );
              },
              child:
                  Icon(Icons.copy, size: 14, color: Colors.white.withOpacity(0.3)),
            ),
          ]),
          const SizedBox(height: 4),
          Text(
            value.length > 100 ? '${value.substring(0, 100)}...' : value,
            style: TextStyle(
                color: Colors.white.withOpacity(0.5),
                fontSize: 10,
                fontFamily: 'monospace'),
            maxLines: 3,
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }

  void _copyAllTokens() {
    final tokens = _auth.state.toTokenMap();
    final text =
        tokens.entries.map((e) => '${e.key}: ${e.value}').join('\n\n');
    Clipboard.setData(ClipboardData(text: text));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
          content: Text('Todos os tokens copiados!'),
          duration: Duration(seconds: 1)),
    );
  }

  // ── Invite Code View ─────────────────────────────────────────────────────────
  Widget _buildExplorerView() {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
          color: const Color(0xFF1A1A2E),
          child: Row(
            children: [
              IconButton(
                icon: const Icon(Icons.arrow_back, color: Colors.white),
                onPressed: () => setState(() => _currentView = 1),
              ),
              const Expanded(
                child: Text('Código de Convite',
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.bold)),
              ),
            ],
          ),
        ),
        Expanded(
          child: _InviteCodeWidget(auth: _auth),
        ),
      ],
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// Invite Code Widget - Adicionar código de convite à conta
// ═══════════════════════════════════════════════════════════════════════════════
class _InviteCodeWidget extends StatefulWidget {
  final AuthService auth;
  const _InviteCodeWidget({required this.auth});

  @override
  State<_InviteCodeWidget> createState() => _InviteCodeWidgetState();
}

class _InviteCodeWidgetState extends State<_InviteCodeWidget> {
  final TextEditingController _codeCtrl = TextEditingController();
  bool _isLoading = false;
  String? _resultMessage;
  bool _resultSuccess = false;
  List<Map<String, dynamic>> _history = [];

  @override
  void dispose() {
    _codeCtrl.dispose();
    super.dispose();
  }

  Future<void> _submitInviteCode() async {
    final code = _codeCtrl.text.trim();
    if (code.isEmpty) {
      setState(() {
        _resultMessage = 'Digite um código de convite';
        _resultSuccess = false;
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _resultMessage = null;
    });

    try {
      // Chamar a API via HTTP direto (não via Bridge)
      final result = await widget.auth.callConnectDirect(
        'user.v1.UserService/CheckInvitationCode',
        body: {'code': code},
      );

      final isError = result['error'] == true;
      final isBlocked = result['blocked'] == true;

      _history.insert(0, {
        'code': code,
        'success': !isError,
        'response': result,
        'timestamp': DateTime.now(),
      });

      if (isBlocked) {
        setState(() {
          _resultMessage = 'CONTA BLOQUEADA! Erro 403.';
          _resultSuccess = false;
        });
      } else if (isError) {
        final msg = result['message'] ?? 'Erro desconhecido';
        setState(() {
          _resultMessage = 'Erro: $msg';
          _resultSuccess = false;
        });
      } else {
        setState(() {
          _resultMessage = 'Código aplicado com sucesso!';
          _resultSuccess = true;
          _codeCtrl.clear();
        });
      }
    } catch (e) {
      _history.insert(0, {
        'code': code,
        'success': false,
        'response': {'error': true, 'message': e.toString()},
        'timestamp': DateTime.now(),
      });
      setState(() {
        _resultMessage = 'Erro: $e';
        _resultSuccess = false;
      });
    }

    setState(() => _isLoading = false);
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Ícone e título
          Center(
            child: Column(
              children: [
                Container(
                  width: 64,
                  height: 64,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFF7C3AED), Color(0xFF2563EB)],
                    ),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: const Icon(Icons.card_giftcard, color: Colors.white, size: 32),
                ),
                const SizedBox(height: 12),
                const Text(
                  'Adicionar Código de Convite',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  'Cole o código de convite abaixo para adicionar à sua conta',
                  style: TextStyle(color: Colors.white.withOpacity(0.4), fontSize: 13),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),

          const SizedBox(height: 28),

          // Campo de código
          Container(
            decoration: BoxDecoration(
              color: const Color(0xFF1A1A2E),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: const Color(0xFF2A2A4A)),
            ),
            child: TextField(
              controller: _codeCtrl,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 16,
                fontFamily: 'monospace',
                letterSpacing: 1.5,
              ),
              textAlign: TextAlign.center,
              decoration: InputDecoration(
                hintText: 'XXXXXXXX',
                hintStyle: TextStyle(
                  color: Colors.white.withOpacity(0.15),
                  fontSize: 16,
                  fontFamily: 'monospace',
                  letterSpacing: 3,
                ),
                border: InputBorder.none,
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 18),
                prefixIcon: Icon(Icons.vpn_key, color: Colors.white.withOpacity(0.2)),
                suffixIcon: _codeCtrl.text.isNotEmpty
                    ? IconButton(
                        icon: Icon(Icons.clear, color: Colors.white.withOpacity(0.3)),
                        onPressed: () => setState(() => _codeCtrl.clear()),
                      )
                    : null,
              ),
              onChanged: (_) => setState(() {}),
              textCapitalization: TextCapitalization.characters,
            ),
          ),

          const SizedBox(height: 16),

          // Botão confirmar
          SizedBox(
            width: double.infinity,
            height: 52,
            child: ElevatedButton.icon(
              onPressed: (_isLoading || _codeCtrl.text.trim().isEmpty) ? null : _submitInviteCode,
              icon: _isLoading
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                  : const Icon(Icons.check_circle),
              label: Text(
                _isLoading ? 'Enviando...' : 'Confirmar Código',
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF7C3AED),
                foregroundColor: Colors.white,
                disabledBackgroundColor: const Color(0xFF7C3AED).withOpacity(0.3),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                elevation: 0,
              ),
            ),
          ),

          // Resultado
          if (_resultMessage != null) ...[
            const SizedBox(height: 16),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: _resultSuccess
                    ? Colors.green.withOpacity(0.08)
                    : Colors.red.withOpacity(0.08),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                  color: _resultSuccess
                      ? Colors.green.withOpacity(0.3)
                      : Colors.red.withOpacity(0.3),
                ),
              ),
              child: Row(
                children: [
                  Icon(
                    _resultSuccess ? Icons.check_circle : Icons.error,
                    size: 18,
                    color: _resultSuccess ? Colors.greenAccent : Colors.redAccent,
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      _resultMessage!,
                      style: TextStyle(
                        color: _resultSuccess ? Colors.greenAccent : Colors.redAccent,
                        fontSize: 13,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],

          // Histórico
          if (_history.isNotEmpty) ...[
            const SizedBox(height: 24),
            Text('HISTÓRICO',
                style: TextStyle(
                    color: Colors.white.withOpacity(0.3),
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1.5)),
            const SizedBox(height: 8),
            ..._history.map((h) {
              final isOk = h['success'] == true;
              final ts = h['timestamp'] as DateTime;
              final resp = h['response'] as Map<String, dynamic>;
              return Container(
                margin: const EdgeInsets.only(bottom: 8),
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: isOk
                      ? Colors.green.withOpacity(0.06)
                      : Colors.red.withOpacity(0.06),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                    color: isOk
                        ? Colors.green.withOpacity(0.2)
                        : Colors.red.withOpacity(0.2),
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(isOk ? Icons.check_circle : Icons.error,
                            size: 12,
                            color: isOk ? Colors.greenAccent : Colors.redAccent),
                        const SizedBox(width: 6),
                        Text(h['code'] as String,
                            style: const TextStyle(
                                color: Colors.white,
                                fontSize: 13,
                                fontWeight: FontWeight.bold,
                                fontFamily: 'monospace')),
                        const Spacer(),
                        Text(
                            '${ts.hour}:${ts.minute.toString().padLeft(2, '0')}:${ts.second.toString().padLeft(2, '0')}',
                            style: TextStyle(
                                color: Colors.white.withOpacity(0.2), fontSize: 9)),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      const JsonEncoder.withIndent('  ').convert(resp),
                      style: TextStyle(
                          color: Colors.white.withOpacity(0.4),
                          fontSize: 9,
                          fontFamily: 'monospace'),
                      maxLines: 5,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              );
            }),
          ],
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// Manus Web Login WebView
// ═══════════════════════════════════════════════════════════════════════════════
class _ManusWebLoginView extends StatefulWidget {
  final String redirectUrl;
  final String userAgent;
  const _ManusWebLoginView(
      {required this.redirectUrl, required this.userAgent});

  @override
  State<_ManusWebLoginView> createState() => _ManusWebLoginViewState();
}

class _ManusWebLoginViewState extends State<_ManusWebLoginView> {
  late final WebViewController _controller;
  bool _loading = true;
  bool _completed = false;
  String _statusText = 'Carregando...';

  Map<String, String> _collectedCookies = {};
  String? _collectedToken;
  String? _collectedUrl;

  @override
  void initState() {
    super.initState();

    late final PlatformWebViewControllerCreationParams params;
    if (Platform.isAndroid) {
      params = AndroidWebViewControllerCreationParams();
    } else {
      params = const PlatformWebViewControllerCreationParams();
    }

    _controller = WebViewController.fromPlatformCreationParams(params)
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setUserAgent(widget.userAgent)
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageStarted: (url) {
            setState(() {
              _loading = true;
              _statusText = 'Carregando...';
            });
            debugPrint('[WebView] Page started: $url');
            _checkForCompletion(url);
          },
          onPageFinished: (url) {
            setState(() => _loading = false);
            debugPrint('[WebView] Page finished: $url');
            _checkForCompletion(url);
          },
          onNavigationRequest: (req) {
            debugPrint('[WebView] Navigation: ${req.url}');
            _checkForCompletion(req.url);
            return NavigationDecision.navigate;
          },
          onWebResourceError: (error) {
            debugPrint('[WebView] Error: ${error.description}');
          },
        ),
      );

    if (Platform.isAndroid) {
      final androidController =
          _controller.platform as AndroidWebViewController;
      AndroidWebViewController.enableDebugging(true);
      androidController.setMediaPlaybackRequiresUserGesture(false);
    }

    _controller.addJavaScriptChannel(
      'FlutterAuth',
      onMessageReceived: (message) {
        debugPrint('[WebView] JS: ${message.message}');
        _processJsMessage(message.message);
      },
    );

    _controller.loadRequest(Uri.parse(widget.redirectUrl));
  }

  void _checkForCompletion(String url) {
    if (_completed) return;

    if (url.contains('api.manus.im/api/oauth2_callback')) {
      setState(() => _statusText = 'Processando autenticação...');
    }

    if (url.contains('manus.im') &&
        !url.contains('accounts.google.com') &&
        !url.contains('oauth2_callback') &&
        !url.contains('oauth2Authorize')) {
      setState(() => _statusText = 'Login bem-sucedido! Capturando sessão...');
      Future.delayed(const Duration(milliseconds: 1500), () {
        if (!_completed && mounted) {
          _extractAndReturn();
        }
      });
    }
  }

  Future<void> _extractAndReturn() async {
    if (_completed) return;
    _completed = true;

    String? currentUrl;
    try {
      currentUrl = await _controller.currentUrl();
    } catch (_) {}

    try {
      await _controller.runJavaScript('''
        (function() {
          var data = {
            cookies: document.cookie,
            url: window.location.href,
            localStorage: {},
            sessionStorage: {}
          };
          try {
            for (var i = 0; i < localStorage.length; i++) {
              var key = localStorage.key(i);
              if (key.toLowerCase().includes('token') || 
                  key.toLowerCase().includes('auth') || 
                  key.toLowerCase().includes('session') ||
                  key.toLowerCase().includes('user')) {
                data.localStorage[key] = localStorage.getItem(key);
              }
            }
          } catch(e) {}
          try {
            for (var i = 0; i < sessionStorage.length; i++) {
              var key = sessionStorage.key(i);
              if (key.toLowerCase().includes('token') || 
                  key.toLowerCase().includes('auth') || 
                  key.toLowerCase().includes('session') ||
                  key.toLowerCase().includes('user')) {
                data.sessionStorage[key] = sessionStorage.getItem(key);
              }
            }
          } catch(e) {}
          FlutterAuth.postMessage(JSON.stringify(data));
        })();
      ''');
      await Future.delayed(const Duration(milliseconds: 800));
    } catch (e) {
      debugPrint('[WebView] Extract error (ignorado): $e');
    }

    if (mounted) {
      Navigator.pop(context, {
        'cookies': _collectedCookies,
        'token': _collectedToken,
        'finalUrl': _collectedUrl ?? currentUrl ?? '',
      });
    }
  }

  void _processJsMessage(String message) {
    try {
      final data = jsonDecode(message);
      final cookies = <String, String>{};

      final cookieStr = data['cookies'] as String? ?? '';
      _parseCookieString(cookieStr, cookies);

      final localStorage = data['localStorage'] as Map<String, dynamic>? ?? {};
      final sessionStorage =
          data['sessionStorage'] as Map<String, dynamic>? ?? {};

      String? token;
      for (final storage in [localStorage, sessionStorage]) {
        for (final entry in storage.entries) {
          if (entry.value is String && (entry.value as String).length > 20) {
            final key = entry.key.toLowerCase();
            if (key.contains('token') ||
                key.contains('auth') ||
                key.contains('jwt')) {
              token = entry.value as String;
              break;
            }
          }
        }
      }

      _collectedCookies = cookies;
      _collectedToken = token;
      _collectedUrl = data['url'] as String?;
    } catch (e) {
      debugPrint('[WebView] Parse error: $e');
    }
  }

  void _parseCookieString(String cookieStr, Map<String, String> cookies) {
    if (cookieStr.isEmpty) return;
    for (final part in cookieStr.split(';')) {
      final trimmed = part.trim();
      final eqIdx = trimmed.indexOf('=');
      if (eqIdx > 0) {
        final key = trimmed.substring(0, eqIdx).trim();
        final value = trimmed.substring(eqIdx + 1).trim();
        if (key.isNotEmpty && value.isNotEmpty) {
          cookies[key] = value;
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Login com Google'),
        backgroundColor: const Color(0xFF1A1A2E),
        leading: IconButton(
          icon: const Icon(Icons.close),
          onPressed: () => Navigator.pop(context, null),
        ),
        actions: [
          if (_loading)
            const Padding(
              padding: EdgeInsets.all(16),
              child: SizedBox(
                width: 16,
                height: 16,
                child: CircularProgressIndicator(
                    strokeWidth: 2, color: Color(0xFF7C3AED)),
              ),
            ),
        ],
      ),
      body: Column(
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            color: const Color(0xFF1A1A2E),
            child: Text(_statusText,
                style: TextStyle(
                    color: Colors.white.withOpacity(0.5), fontSize: 11)),
          ),
          Expanded(child: WebViewWidget(controller: _controller)),
        ],
      ),
    );
  }
}

// ── Helper Classes ────────────────────────────────────────────────────────────

class _GoogleIcon extends StatelessWidget {
  const _GoogleIcon();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 24,
      height: 24,
      decoration: BoxDecoration(
          color: Colors.white, borderRadius: BorderRadius.circular(4)),
      padding: const EdgeInsets.all(3),
      child: const Text('G',
          textAlign: TextAlign.center,
          style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.bold,
              color: Color(0xFF4285F4))),
    );
  }
}
