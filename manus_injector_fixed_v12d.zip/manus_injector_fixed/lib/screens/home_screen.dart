import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../models/fake_device.dart';
import '../services/root_service.dart';
import '../services/profile_service.dart';
import '../services/injection_service.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with SingleTickerProviderStateMixin {
  bool _hasRoot = false;
  bool _manusInstalled = false;
  bool _hookActive = false;
  bool _checking = true;
  bool _injecting = false;
  String _deviceArch = '?';

  FakeDevice? _currentDevice;
  FakeDevice? _activeProfile;
  List<FakeDevice> _savedProfiles = [];
  Map<String, String> _realDeviceInfo = {};
  Map<String, String> _hookStatus = {};
  final List<String> _logs = [];

  late AnimationController _pulseController;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);
    // Delay check to ensure context is ready
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _checkSystem();
    });
  }

  @override
  void dispose() {
    _pulseController.dispose();
    super.dispose();
  }

  String _timestamp() {
    final now = DateTime.now();
    return '${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}:${now.second.toString().padLeft(2, '0')}';
  }

  void _addLog(String msg) {
    if (mounted) {
      setState(() => _logs.add('[${_timestamp()}] $msg'));
    }
  }

  Future<void> _checkSystem() async {
    if (!mounted) return;
    setState(() => _checking = true);

    try {
      bool hasRoot = false;
      bool manusInstalled = false;
      Map<String, String> deviceInfo = {};
      List<FakeDevice> profiles = [];
      FakeDevice? activeProfile;
      String arch = 'x86_64';
      bool hookActive = false;
      Map<String, String> hookStatus = {};

      try { hasRoot = await RootService.checkRoot(); } catch (_) {}
      try { manusInstalled = await RootService.isManusInstalled(); } catch (_) {}
      try { deviceInfo = await RootService.getCurrentDeviceInfo(); } catch (_) {}
      try { profiles = await ProfileService.loadProfiles(); } catch (_) {}
      try { activeProfile = await ProfileService.getActiveProfile(); } catch (_) {}
      try { arch = await InjectionService.getDeviceArch(); } catch (_) {}
      try { hookActive = await InjectionService.isHookActive(); } catch (_) {}
      try { hookStatus = await InjectionService.readStatus(); } catch (_) {}

      if (mounted) {
        setState(() {
          _hasRoot = hasRoot;
          _manusInstalled = manusInstalled;
          _realDeviceInfo = deviceInfo;
          _savedProfiles = profiles;
          _activeProfile = activeProfile;
          _deviceArch = arch;
          _hookActive = hookActive;
          _hookStatus = hookStatus;
          _checking = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() => _checking = false);
        _addLog('[ERRO] Falha ao verificar sistema: $e');
      }
    }
  }

  void _generateNewDevice() {
    try {
      final device = DeviceGenerator.generate();
      setState(() => _currentDevice = device);
      _addLog('Novo dispositivo gerado: ${device.brand} ${device.model}');
    } catch (e) {
      _addLog('[ERRO] Falha ao gerar dispositivo: $e');
    }
  }

  Future<void> _installBinaries() async {
    setState(() {
      _injecting = true;
      _logs.clear();
    });
    _addLog('Instalando binarios nativos...');

    try {
      final logs = await InjectionService.installBinaries();
      for (final log in logs) {
        if (mounted) {
          setState(() => _logs.add(log));
        }
        await Future.delayed(const Duration(milliseconds: 50));
      }
    } catch (e) {
      _addLog('[ERRO] Falha na instalacao: $e');
    }

    if (mounted) setState(() => _injecting = false);
  }

  Future<void> _injectHook() async {
    if (_currentDevice == null) return;

    setState(() {
      _injecting = true;
      _logs.clear();
    });

    try {
      final logs = await InjectionService.fullInject(_currentDevice!);
      for (final log in logs) {
        if (mounted) {
          setState(() => _logs.add(log));
        }
        await Future.delayed(const Duration(milliseconds: 80));
      }

      try { await ProfileService.setActiveProfile(_currentDevice!); } catch (_) {}

      // Refresh status
      bool hookActive = false;
      Map<String, String> hookStatus = {};
      Map<String, String> newInfo = {};
      try { hookActive = await InjectionService.isHookActive(); } catch (_) {}
      try { hookStatus = await InjectionService.readStatus(); } catch (_) {}
      try { newInfo = await RootService.getCurrentDeviceInfo(); } catch (_) {}

      if (mounted) {
        setState(() {
          _hookActive = hookActive;
          _hookStatus = hookStatus;
          _activeProfile = _currentDevice;
          _realDeviceInfo = newInfo;
        });
      }
    } catch (e) {
      _addLog('[ERRO] Falha na injecao: $e');
    }

    if (mounted) setState(() => _injecting = false);
  }

  Future<void> _quickInject() async {
    if (_currentDevice == null) return;

    setState(() {
      _injecting = true;
      _logs.clear();
    });

    try {
      _addLog('Atualizando config do spoof...');
      final ok = await InjectionService.writeConfig(_currentDevice!);
      _addLog(ok ? '[OK] Config atualizada (hook recarrega em 5s)' : '[ERRO] Falha ao escrever config');
      try { await ProfileService.setActiveProfile(_currentDevice!); } catch (_) {}
      if (mounted) setState(() => _activeProfile = _currentDevice);
    } catch (e) {
      _addLog('[ERRO] $e');
    }

    if (mounted) setState(() => _injecting = false);
  }

  Future<void> _saveCurrentProfile() async {
    if (_currentDevice == null) return;

    final nameController = TextEditingController(text: _currentDevice!.name);

    final name = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF111827),
        title: const Text('Salvar Perfil', style: TextStyle(fontFamily: 'monospace', color: Color(0xFF00E5FF))),
        content: TextField(
          controller: nameController,
          style: const TextStyle(fontFamily: 'monospace', color: Colors.white),
          decoration: InputDecoration(
            labelText: 'Nome do perfil',
            labelStyle: const TextStyle(color: Color(0xFF94A3B8)),
            enabledBorder: OutlineInputBorder(
              borderSide: const BorderSide(color: Color(0xFF1E293B)),
              borderRadius: BorderRadius.circular(8),
            ),
            focusedBorder: OutlineInputBorder(
              borderSide: const BorderSide(color: Color(0xFF00E5FF)),
              borderRadius: BorderRadius.circular(8),
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancelar', style: TextStyle(color: Color(0xFF94A3B8))),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, nameController.text),
            child: const Text('Salvar'),
          ),
        ],
      ),
    );

    if (name != null && name.isNotEmpty) {
      try {
        final device = FakeDevice(
          name: name,
          brand: _currentDevice!.brand, manufacturer: _currentDevice!.manufacturer,
          model: _currentDevice!.model, device: _currentDevice!.device,
          product: _currentDevice!.product, hardware: _currentDevice!.hardware,
          board: _currentDevice!.board, buildId: _currentDevice!.buildId,
          buildFingerprint: _currentDevice!.buildFingerprint, buildDisplay: _currentDevice!.buildDisplay,
          buildTags: _currentDevice!.buildTags, buildType: _currentDevice!.buildType,
          host: _currentDevice!.host, serial: _currentDevice!.serial,
          androidId: _currentDevice!.androidId, advertisingId: _currentDevice!.advertisingId,
          imei: _currentDevice!.imei, simSerial: _currentDevice!.simSerial,
          subscriberId: _currentDevice!.subscriberId, macAddress: _currentDevice!.macAddress,
          bluetoothMac: _currentDevice!.bluetoothMac, screenWidth: _currentDevice!.screenWidth,
          screenHeight: _currentDevice!.screenHeight, screenDensity: _currentDevice!.screenDensity,
          sdkInt: _currentDevice!.sdkInt, androidVersion: _currentDevice!.androidVersion,
        );
        await ProfileService.saveProfile(device);
        if (mounted) {
          setState(() {
            _savedProfiles = [..._savedProfiles.where((p) => p.name != name), device];
          });
        }
        _addLog('Perfil "$name" salvo!');
      } catch (e) {
        _addLog('[ERRO] Falha ao salvar perfil: $e');
      }
    }
  }

  void _loadProfile(FakeDevice profile) {
    setState(() => _currentDevice = profile);
    _addLog('Perfil "${profile.name}" carregado');
  }

  Future<void> _deleteProfile(FakeDevice profile) async {
    try {
      await ProfileService.deleteProfile(profile.name);
      if (mounted) {
        setState(() => _savedProfiles.removeWhere((p) => p.name == profile.name));
      }
      _addLog('Perfil "${profile.name}" deletado');
    } catch (e) {
      _addLog('[ERRO] Falha ao deletar: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('MANUS MOD'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh, color: Color(0xFF00E5FF)),
            onPressed: _checkSystem,
          ),
        ],
      ),
      body: _checking
          ? const Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  CircularProgressIndicator(color: Color(0xFF00E5FF)),
                  SizedBox(height: 16),
                  Text('Verificando sistema...', style: TextStyle(fontFamily: 'monospace', color: Color(0xFF94A3B8))),
                ],
              ),
            )
          : SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  _buildStatusCard(),
                  const SizedBox(height: 16),
                  _buildDeviceInfoCard(),
                  const SizedBox(height: 16),
                  _buildGeneratedDeviceCard(),
                  const SizedBox(height: 16),
                  _buildActionButtons(),
                  const SizedBox(height: 16),
                  _buildProfilesCard(),
                  const SizedBox(height: 16),
                  _buildLogCard(),
                  const SizedBox(height: 32),
                ],
              ),
            ),
    );
  }

  Widget _buildStatusCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                AnimatedBuilder(
                  animation: _pulseController,
                  builder: (_, __) => Container(
                    width: 10, height: 10,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _hookActive
                          ? Color.lerp(const Color(0xFF00E5FF), const Color(0xFF00BFA5), _pulseController.value)
                          : _hasRoot ? const Color(0xFFFFD600) : const Color(0xFFFF5252),
                      boxShadow: _hookActive
                          ? [BoxShadow(color: const Color(0xFF00E5FF).withValues(alpha: 0.5), blurRadius: 8)]
                          : [],
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                const Text('STATUS', style: TextStyle(fontFamily: 'monospace', fontSize: 14, fontWeight: FontWeight.bold, color: Color(0xFF00E5FF), letterSpacing: 2)),
              ],
            ),
            const SizedBox(height: 12),
            _statusRow('Root', _hasRoot),
            _statusRow('Manus instalado', _manusInstalled),
            _statusRow('Arquitetura', true, value: _deviceArch),
            _statusRow('Hook injetado', _hookActive),
            if (_hookActive && _hookStatus.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: const Color(0xFF002200),
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(color: const Color(0xFF00E676).withValues(alpha: 0.3)),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Spoofing: ${_hookStatus['brand'] ?? '?'} ${_hookStatus['model'] ?? '?'}',
                          style: const TextStyle(fontFamily: 'monospace', fontSize: 11, color: Color(0xFF00E676))),
                      Text('Android ID: ${_hookStatus['android_id'] ?? '?'}',
                          style: const TextStyle(fontFamily: 'monospace', fontSize: 11, color: Color(0xFF00E676))),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _statusRow(String label, bool ok, {String? value}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        children: [
          Icon(ok ? Icons.check_circle : Icons.cancel, size: 16, color: ok ? const Color(0xFF00E676) : const Color(0xFFFF5252)),
          const SizedBox(width: 8),
          Text(label, style: const TextStyle(fontFamily: 'monospace', fontSize: 13, color: Color(0xFFCBD5E1))),
          const Spacer(),
          Text(value ?? (ok ? 'OK' : 'N/A'), style: TextStyle(fontFamily: 'monospace', fontSize: 12, color: ok ? const Color(0xFF00E676) : const Color(0xFFFF5252))),
        ],
      ),
    );
  }

  Widget _buildDeviceInfoCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Row(
              children: [
                Icon(Icons.smartphone, size: 16, color: Color(0xFFFF9800)),
                SizedBox(width: 8),
                Text('DISPOSITIVO REAL', style: TextStyle(fontFamily: 'monospace', fontSize: 14, fontWeight: FontWeight.bold, color: Color(0xFFFF9800), letterSpacing: 2)),
              ],
            ),
            const SizedBox(height: 12),
            if (_realDeviceInfo.isEmpty)
              const Text('Sem dados (root necessario)', style: TextStyle(fontFamily: 'monospace', fontSize: 12, color: Color(0xFF64748B)))
            else
              ..._realDeviceInfo.entries.map((e) => _infoRow(e.key, e.value)),
          ],
        ),
      ),
    );
  }

  Widget _buildGeneratedDeviceCard() {
    if (_currentDevice == null) {
      return Card(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            children: [
              const Icon(Icons.shuffle, size: 48, color: Color(0xFF1E293B)),
              const SizedBox(height: 12),
              const Text('Nenhum dispositivo gerado', style: TextStyle(fontFamily: 'monospace', fontSize: 14, color: Color(0xFF64748B))),
              const SizedBox(height: 16),
              ElevatedButton.icon(
                onPressed: _generateNewDevice,
                icon: const Icon(Icons.casino, size: 18),
                label: const Text('GERAR DISPOSITIVO'),
              ),
            ],
          ),
        ),
      );
    }

    final d = _currentDevice!;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.devices, size: 16, color: Color(0xFF00E5FF)),
                const SizedBox(width: 8),
                const Expanded(
                  child: Text('DISPOSITIVO FALSO', style: TextStyle(fontFamily: 'monospace', fontSize: 14, fontWeight: FontWeight.bold, color: Color(0xFF00E5FF), letterSpacing: 2)),
                ),
                IconButton(icon: const Icon(Icons.casino, size: 20, color: Color(0xFF7C4DFF)), onPressed: _generateNewDevice, tooltip: 'Gerar novo', padding: EdgeInsets.zero, constraints: const BoxConstraints(minWidth: 36, minHeight: 36)),
                IconButton(icon: const Icon(Icons.save, size: 20, color: Color(0xFF00E676)), onPressed: _saveCurrentProfile, tooltip: 'Salvar perfil', padding: EdgeInsets.zero, constraints: const BoxConstraints(minWidth: 36, minHeight: 36)),
                IconButton(
                  icon: const Icon(Icons.copy, size: 20, color: Color(0xFF94A3B8)),
                  onPressed: () {
                    try {
                      final text = d.toJson().entries.map((e) => '${e.key}: ${e.value}').join('\n');
                      Clipboard.setData(ClipboardData(text: text));
                      if (mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Copiado!'), backgroundColor: Color(0xFF00E5FF)));
                      }
                    } catch (_) {}
                  },
                  tooltip: 'Copiar dados',
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(minWidth: 36, minHeight: 36),
                ),
              ],
            ),
            const SizedBox(height: 12),
            _infoRow('Brand', d.brand),
            _infoRow('Model', d.model),
            _infoRow('Device', d.device),
            _infoRow('Android ID', d.androidId),
            _infoRow('IMEI', d.imei),
            _infoRow('MAC', d.macAddress),
            _infoRow('Serial', d.serial),
            _infoRow('SDK', '${d.sdkInt} (Android ${d.androidVersion})'),
            const SizedBox(height: 8),
            const Text('Fingerprint:', style: TextStyle(fontFamily: 'monospace', fontSize: 11, color: Color(0xFF94A3B8))),
            const SizedBox(height: 4),
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(color: const Color(0xFF0A0E17), borderRadius: BorderRadius.circular(6), border: Border.all(color: const Color(0xFF1E293B))),
              child: Text(d.buildFingerprint, style: const TextStyle(fontFamily: 'monospace', fontSize: 10, color: Color(0xFF00E676))),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildActionButtons() {
    final hasDevice = _currentDevice != null;
    final canInject = hasDevice && _hasRoot && !_injecting;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        if (!hasDevice)
          ElevatedButton.icon(
            onPressed: _generateNewDevice,
            icon: const Icon(Icons.casino, size: 18),
            label: const Text('GERAR DISPOSITIVO'),
          ),
        if (hasDevice) ...[
          // Botao principal: Full Inject (limpa dados + injeta)
          ElevatedButton.icon(
            onPressed: canInject ? _injectHook : null,
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFFFF1744),
              foregroundColor: Colors.white,
              disabledBackgroundColor: const Color(0xFF37474F),
              padding: const EdgeInsets.symmetric(vertical: 16),
            ),
            icon: _injecting
                ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                : const Icon(Icons.flash_on, size: 20),
            label: Text(_injecting ? 'INJETANDO...' : 'INJETAR NO MANUS', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          ),
          const SizedBox(height: 10),
          // Quick inject (so atualiza config se hook ja ativo)
          if (_hookActive)
            OutlinedButton.icon(
              onPressed: canInject ? _quickInject : null,
              style: OutlinedButton.styleFrom(
                side: const BorderSide(color: Color(0xFF7C4DFF), width: 1.5),
                foregroundColor: const Color(0xFF7C4DFF),
              ),
              icon: const Icon(Icons.update, size: 18),
              label: const Text('ATUALIZAR SPOOF (SEM REINICIAR)'),
            ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _generateNewDevice,
                  icon: const Icon(Icons.casino, size: 18),
                  label: const Text('GERAR OUTRO'),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _hasRoot ? _installBinaries : null,
                  style: OutlinedButton.styleFrom(
                    side: const BorderSide(color: Color(0xFFFFD600), width: 1.5),
                    foregroundColor: const Color(0xFFFFD600),
                  ),
                  icon: const Icon(Icons.download, size: 18),
                  label: const Text('INSTALAR'),
                ),
              ),
            ],
          ),
        ],
        if (!_hasRoot)
          Padding(
            padding: const EdgeInsets.only(top: 12),
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFF1A0000),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: const Color(0xFFFF5252).withValues(alpha: 0.3)),
              ),
              child: const Row(
                children: [
                  Icon(Icons.warning, size: 16, color: Color(0xFFFF5252)),
                  SizedBox(width: 8),
                  Expanded(child: Text('Root nao detectado! Ative root nas configuracoes do LDPlayer.', style: TextStyle(fontFamily: 'monospace', fontSize: 11, color: Color(0xFFFF8A80)))),
                ],
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildProfilesCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Row(
              children: [
                Icon(Icons.folder, size: 16, color: Color(0xFFFFD600)),
                SizedBox(width: 8),
                Text('PERFIS SALVOS', style: TextStyle(fontFamily: 'monospace', fontSize: 14, fontWeight: FontWeight.bold, color: Color(0xFFFFD600), letterSpacing: 2)),
              ],
            ),
            const SizedBox(height: 12),
            if (_savedProfiles.isEmpty)
              const Center(child: Padding(padding: EdgeInsets.all(16), child: Text('Nenhum perfil salvo', style: TextStyle(fontFamily: 'monospace', fontSize: 12, color: Color(0xFF64748B)))))
            else
              ..._savedProfiles.map((profile) => Container(
                margin: const EdgeInsets.only(bottom: 8),
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                decoration: BoxDecoration(
                  color: const Color(0xFF0A0E17),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: _activeProfile?.name == profile.name ? const Color(0xFF00E5FF).withValues(alpha: 0.5) : const Color(0xFF1E293B)),
                ),
                child: Row(
                  children: [
                    Icon(Icons.phone_android, size: 16, color: _activeProfile?.name == profile.name ? const Color(0xFF00E5FF) : const Color(0xFF64748B)),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(profile.name, style: const TextStyle(fontFamily: 'monospace', fontSize: 13, color: Color(0xFFE2E8F0), fontWeight: FontWeight.bold)),
                          Text('${profile.brand} ${profile.model} | ${profile.androidId.length >= 8 ? profile.androidId.substring(0, 8) : profile.androidId}...', style: const TextStyle(fontFamily: 'monospace', fontSize: 11, color: Color(0xFF64748B))),
                        ],
                      ),
                    ),
                    IconButton(icon: const Icon(Icons.download, size: 18, color: Color(0xFF00E5FF)), onPressed: () => _loadProfile(profile), tooltip: 'Carregar', padding: EdgeInsets.zero, constraints: const BoxConstraints(minWidth: 36, minHeight: 36)),
                    IconButton(icon: const Icon(Icons.delete_outline, size: 18, color: Color(0xFFFF5252)), onPressed: () => _deleteProfile(profile), tooltip: 'Deletar', padding: EdgeInsets.zero, constraints: const BoxConstraints(minWidth: 36, minHeight: 36)),
                  ],
                ),
              )),
          ],
        ),
      ),
    );
  }

  Widget _buildLogCard() {
    if (_logs.isEmpty) return const SizedBox.shrink();

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.terminal, size: 16, color: Color(0xFF00E676)),
                const SizedBox(width: 8),
                const Text('LOG', style: TextStyle(fontFamily: 'monospace', fontSize: 14, fontWeight: FontWeight.bold, color: Color(0xFF00E676), letterSpacing: 2)),
                const Spacer(),
                IconButton(icon: const Icon(Icons.clear_all, size: 18, color: Color(0xFF64748B)), onPressed: () => setState(() => _logs.clear()), tooltip: 'Limpar'),
              ],
            ),
            const SizedBox(height: 8),
            Container(
              constraints: const BoxConstraints(maxHeight: 300),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: const Color(0xFF0A0E17), borderRadius: BorderRadius.circular(8), border: Border.all(color: const Color(0xFF1E293B))),
              child: SingleChildScrollView(
                reverse: true,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: _logs.map((log) {
                    Color color = const Color(0xFFCBD5E1);
                    if (log.contains('[OK]')) color = const Color(0xFF00E676);
                    if (log.contains('[ERRO]')) color = const Color(0xFFFF5252);
                    if (log.contains('[INFO]')) color = const Color(0xFFFFD600);
                    if (log.contains('===')) color = const Color(0xFF00E5FF);
                    if (log.contains('INJECTOR')) color = const Color(0xFF7C4DFF);
                    return Padding(
                      padding: const EdgeInsets.symmetric(vertical: 1),
                      child: Text(log, style: TextStyle(fontFamily: 'monospace', fontSize: 11, color: color)),
                    );
                  }).toList(),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _infoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(width: 100, child: Text(label, style: const TextStyle(fontFamily: 'monospace', fontSize: 12, color: Color(0xFF64748B)))),
          Expanded(child: Text(value, style: const TextStyle(fontFamily: 'monospace', fontSize: 12, color: Color(0xFFE2E8F0)))),
        ],
      ),
    );
  }
}
