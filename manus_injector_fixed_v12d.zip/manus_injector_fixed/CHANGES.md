# Mudanças Realizadas - v12d Fixed

## Problema Identificado

O header `x-client-dcr` (Device Change Record) estava sendo enviado em apenas **1 de 35 requisições** (CheckInvitationCode). Todas as outras requisições só tinham `x-client-id`.

## Solução Implementada

### 1. **anti_detect.dart** - Linha 240

**Antes:**
```dart
bool includeDCR = false,
```

**Depois:**
```dart
bool includeDCR = true,
```

**Impacto:** Agora o `x-client-dcr` é incluído **por padrão** em todas as chamadas HTTP diretas via `generateHeaders()`.

---

### 2. **webview_api_bridge.dart** - Linhas 163-191

**Antes:**
```javascript
headers: {
  'Content-Type': 'application/json',
  'Connect-Protocol-Version': '1',
  'x-client-type': 'web',
  'x-client-id': '${profile.clientId}',
  'x-client-locale': '${profile.locale}',
  'x-client-timezone': '${profile.timezone}',
  'x-client-timezone-offset': '${profile.timezoneOffset}',
  'x-client-dcr': '$dcr',
},
```

**Depois:**
```javascript
headers: {
  'Content-Type': 'application/json',
  'Connect-Protocol-Version': '1',
  'x-client-type': 'web',
  'x-client-id': '${profile.clientId}',
  'x-client-locale': '${profile.locale}',
  'x-client-timezone': '${profile.timezone}',
  'x-client-timezone-offset': '${profile.timezoneOffset}',
  'x-client-dcr': '$dcr',
  'User-Agent': '${profile.userAgent.replaceAll("'", "\\'")}',
  'Accept': '*/*',
  'Accept-Language': '${profile.languages.join(",").replaceAll("'", "\\'")}',
  'Origin': 'https://manus.im',
  'Referer': 'https://manus.im/',
  'Sec-Fetch-Dest': 'empty',
  'Sec-Fetch-Mode': 'cors',
  'Sec-Fetch-Site': 'same-site',
  'Sec-Ch-Ua': '${profile.secChUa.replaceAll("'", "\\'")}',
  'Sec-Ch-Ua-Mobile': '?0',
  'Sec-Ch-Ua-Platform': '${profile.platform.replaceAll("'", "\\'")}',
},
```

**Impacto:** 
- Agora o WebView Bridge envia **TODOS os headers importantes** em cada requisição
- Inclui User-Agent, Accept, Origin, Referer, Sec-* headers
- Esses headers já estavam sendo gerados mas não eram enviados no fetch()

---

## Resultado

✅ **Antes:** 1 requisição com x-client-dcr + x-client-id
✅ **Depois:** TODAS as requisições com x-client-dcr + x-client-id + headers completos

## Como Usar

1. Substitua os arquivos:
   - `lib/anti_detect.dart`
   - `lib/webview_api_bridge.dart`

2. Recompile o projeto Flutter:
   ```bash
   flutter pub get
   flutter run
   ```

## Verificação

Para verificar se está funcionando, capture um HAR e procure por:
- Todas as requisições POST devem ter `x-client-dcr`
- O `x-client-id` dentro do DCR deve bater com o header `x-client-id`
- Todos os headers Sec-* devem estar presentes

---

**Versão:** v12d Fixed
**Data:** 2026-05-11
