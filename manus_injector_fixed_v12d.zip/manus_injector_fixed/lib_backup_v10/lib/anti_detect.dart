import 'dart:convert';
import 'dart:math';

/// Módulo Anti-Detecção v11
/// Gera fingerprints realistas e o header x-client-dcr
/// que o site manus.im envia em cada requisição.
///
/// O DCR (Device Change Record) é:
/// 1. Um JSON com dados do dispositivo
/// 2. Codificado em base64
/// 3. Cifrado com César (shift +3) nos caracteres alfanuméricos

// ─── Chrome User Agents ─────────────────────────────────────────────────────

const _chromeUserAgents = [
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36',
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36',
  'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
];

// ─── Screen Resolutions ─────────────────────────────────────────────────────

const _screenSizes = [
  {'width': 1920, 'height': 1080},
  {'width': 2560, 'height': 1440},
  {'width': 1366, 'height': 768},
  {'width': 1536, 'height': 864},
  {'width': 1440, 'height': 900},
];

const _viewportSizes = [
  {'width': 1920, 'height': 969},
  {'width': 1903, 'height': 969},
  {'width': 1536, 'height': 754},
  {'width': 1366, 'height': 657},
  {'width': 1440, 'height': 789},
];

// ─── Locales ────────────────────────────────────────────────────────────────

const _localeConfigs = [
  {
    'locale': 'pt-BR',
    'languages': ['pt-BR', 'pt', 'en-US', 'en'],
    'timezone': 'America/Sao_Paulo',
    'offset': 180,
  },
  {
    'locale': 'en-US',
    'languages': ['en-US', 'en'],
    'timezone': 'America/New_York',
    'offset': 300,
  },
  {
    'locale': 'en-US',
    'languages': ['en-US', 'en'],
    'timezone': 'America/Los_Angeles',
    'offset': 480,
  },
];

// ─── Helpers ────────────────────────────────────────────────────────────────

final _rng = Random.secure();

T _pick<T>(List<T> list) => list[_rng.nextInt(list.length)];

/// Gera um clientId estilo nanoid(22) - mesmo formato que o site usa
String generateClientId() {
  const charset =
      'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  return List.generate(22, (_) => charset[_rng.nextInt(charset.length)]).join();
}

/// Cifra de César (shift +3) em string base64
/// Exatamente como o site manus.im faz
String caesarEncodeBase64(String b64) {
  final buf = StringBuffer();
  for (int i = 0; i < b64.length; i++) {
    final c = b64.codeUnitAt(i);
    if (c >= 65 && c <= 90) {
      // A-Z
      buf.writeCharCode(((c - 65 + 3) % 26) + 65);
    } else if (c >= 97 && c <= 122) {
      // a-z
      buf.writeCharCode(((c - 97 + 3) % 26) + 97);
    } else if (c >= 48 && c <= 57) {
      // 0-9
      buf.writeCharCode(((c - 48 + 3) % 10) + 48);
    } else {
      buf.write(b64[i]); // +, /, = ficam iguais
    }
  }
  return buf.toString();
}

// ─── Device Profile ─────────────────────────────────────────────────────────

class DeviceProfile {
  final String clientId;
  final String userAgent;
  final String locale;
  final List<String> languages;
  final String timezone;
  final int timezoneOffset;
  final Map<String, int> screen;
  final Map<String, int> viewport;

  DeviceProfile({
    required this.clientId,
    required this.userAgent,
    required this.locale,
    required this.languages,
    required this.timezone,
    required this.timezoneOffset,
    required this.screen,
    required this.viewport,
  });

  /// Gera o valor do header x-client-dcr
  String generateDCR() {
    final data = jsonEncode({
      'ua': userAgent,
      'locale': locale,
      'languages': languages,
      'timezone': timezone,
      'fgRequestId': '', // Vazio - não temos FingerprintJS Pro
      'clientId': clientId,
      'screen': screen,
      'viewport': viewport,
      'timestamp': DateTime.now().millisecondsSinceEpoch,
      'timezoneOffset': timezoneOffset,
    });

    final b64 = base64Encode(utf8.encode(data));
    return caesarEncodeBase64(b64);
  }

  /// Gera todos os headers necessários para requisições ao api.manus.im
  Map<String, String> generateHeaders({
    String? authToken,
    bool includeDCR = false,
  }) {
    final headers = <String, String>{
      'Content-Type': 'application/json',
      'Connect-Protocol-Version': '1',
      'x-client-type': 'web',
      'x-client-id': clientId,
      'x-client-locale': locale,
      'x-client-timezone': timezone,
      'x-client-timezone-offset': timezoneOffset.toString(),
      'User-Agent': userAgent,
      'Accept': '*/*',
      'Accept-Language': languages.join(','),
      'Origin': 'https://manus.im',
      'Referer': 'https://manus.im/',
      'Sec-Fetch-Dest': 'empty',
      'Sec-Fetch-Mode': 'cors',
      'Sec-Fetch-Site': 'same-site',
      'Sec-Ch-Ua': '"Chromium";v="131", "Not_A Brand";v="24"',
      'Sec-Ch-Ua-Mobile': '?0',
      'Sec-Ch-Ua-Platform': '"Windows"',
    };

    if (authToken != null) {
      headers['Authorization'] = 'Bearer $authToken';
    }

    if (includeDCR) {
      headers['x-client-dcr'] = generateDCR();
    }

    return headers;
  }

  /// Gera o JavaScript que configura os headers no fetch() do WebView Bridge
  String generateJsHeaders() {
    return '''
      'Content-Type': 'application/json',
      'Connect-Protocol-Version': '1',
      'x-client-type': 'web',
      'x-client-id': '$clientId',
      'x-client-locale': '$locale',
      'x-client-timezone': '$timezone',
      'x-client-timezone-offset': '$timezoneOffset',
      'x-client-dcr': '${generateDCR()}',
      'Sec-Ch-Ua': '"Chromium";v="131", "Not_A Brand";v="24"',
      'Sec-Ch-Ua-Mobile': '?0',
      'Sec-Ch-Ua-Platform': '"Windows"',
      'Sec-Fetch-Dest': 'empty',
      'Sec-Fetch-Mode': 'cors',
      'Sec-Fetch-Site': 'same-site',
    ''';
  }

  Map<String, dynamic> toJson() => {
        'clientId': clientId,
        'userAgent': userAgent,
        'locale': locale,
        'languages': languages,
        'timezone': timezone,
        'timezoneOffset': timezoneOffset,
        'screen': screen,
        'viewport': viewport,
      };
}

/// Gera um perfil de dispositivo realista
DeviceProfile generateDeviceProfile() {
  final localeConfig = _pick(_localeConfigs);
  return DeviceProfile(
    clientId: generateClientId(),
    userAgent: _pick(_chromeUserAgents),
    locale: localeConfig['locale'] as String,
    languages: List<String>.from(localeConfig['languages'] as List),
    timezone: localeConfig['timezone'] as String,
    timezoneOffset: localeConfig['offset'] as int,
    screen: Map<String, int>.from(_pick(_screenSizes)),
    viewport: Map<String, int>.from(_pick(_viewportSizes)),
  );
}
