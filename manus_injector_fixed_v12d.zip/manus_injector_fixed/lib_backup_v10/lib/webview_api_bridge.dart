import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:webview_flutter_android/webview_flutter_android.dart';
import 'anti_detect.dart';

/// WebView API Bridge v11 - Anti-Ban Edition
///
/// Usa um WebView REAL para fazer chamadas API via JavaScript fetch().
/// Agora inclui:
/// 1. Header x-client-dcr (Device Change Record) com fingerprint cifrado
/// 2. Todos os headers Sec-Ch-Ua, Sec-Fetch-* idênticos ao Chrome
/// 3. DeviceProfile consistente entre todas as chamadas
/// 4. TLS fingerprint do Chromium (WebView engine)
/// 5. Cookies httpOnly enviados automaticamente
class WebViewApiBridge extends StatefulWidget {
  final void Function(WebViewApiBridgeController controller)? onReady;
  final DeviceProfile? deviceProfile;

  const WebViewApiBridge({super.key, this.onReady, this.deviceProfile});

  @override
  State<WebViewApiBridge> createState() => WebViewApiBridgeState();
}

class WebViewApiBridgeState extends State<WebViewApiBridge> {
  late final WebViewController _controller;
  final Map<int, Completer<String>> _pendingCalls = {};
  int _callId = 0;
  bool _ready = false;
  bool _initialized = false;

  late final DeviceProfile profile;
  late final WebViewApiBridgeController bridgeController;

  static const String _apiBase = 'https://api.manus.im';

  @override
  void initState() {
    super.initState();
    profile = widget.deviceProfile ?? generateDeviceProfile();
    bridgeController = WebViewApiBridgeController(this);
    _initWebView();
  }

  void _initWebView() {
    late final PlatformWebViewControllerCreationParams params;
    if (Platform.isAndroid) {
      params = AndroidWebViewControllerCreationParams();
    } else {
      params = const PlatformWebViewControllerCreationParams();
    }

    _controller = WebViewController.fromPlatformCreationParams(params)
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setUserAgent(profile.userAgent);

    if (Platform.isAndroid) {
      // ignore: unused_local_variable
      final androidController =
          _controller.platform as AndroidWebViewController;
      AndroidWebViewController.enableDebugging(true);
    }

    // Canal JS para receber respostas do fetch
    _controller.addJavaScriptChannel(
      'ApiBridge',
      onMessageReceived: (message) {
        _handleResponse(message.message);
      },
    );

    _initialized = true;
  }

  /// Ativa o bridge após login bem-sucedido
  /// Navega para uma página no domínio api.manus.im para herdar cookies
  Future<void> activate() async {
    if (!_initialized) return;

    debugPrint('[Bridge] Ativando - navegando para api.manus.im...');

    _controller.setNavigationDelegate(
      NavigationDelegate(
        onPageFinished: (url) {
          debugPrint('[Bridge] Página carregada: $url');
          if (url.contains('api.manus.im') && !_ready) {
            _ready = true;
            debugPrint(
                '[Bridge] PRONTO! Chamadas API via WebView ativadas com DCR.');
            widget.onReady?.call(bridgeController);
          }
        },
      ),
    );

    // Carregar uma página no domínio da API para herdar cookies
    await _controller.loadRequest(
      Uri.parse(
          '$_apiBase/user.v1.UserPublicService/GetGlobalSettings'),
      method: LoadRequestMethod.post,
      headers: {
        'Content-Type': 'application/json',
        'Connect-Protocol-Version': '1',
      },
      body: utf8.encode('{}'),
    );
  }

  bool get isReady => _ready;

  /// Faz uma chamada API via fetch() no WebView
  /// Inclui TODOS os headers anti-ban (DCR, Sec-Ch-Ua, etc.)
  Future<Map<String, dynamic>> callApi(
    String path, {
    Map<String, dynamic>? body,
  }) async {
    if (!_ready) {
      return {
        'error': true,
        'message': 'Bridge não está pronto. Ative após o login.'
      };
    }

    final id = ++_callId;
    final completer = Completer<String>();
    _pendingCalls[id] = completer;

    final jsonBody = jsonEncode(body ?? {});
    // Escapar para uso seguro dentro de template literal JS
    final escapedBody = jsonBody
        .replaceAll('\\', '\\\\')
        .replaceAll("'", "\\'")
        .replaceAll('\n', '\\n')
        .replaceAll('\r', '\\r');

    // Gerar DCR fresco para cada chamada (timestamp diferente)
    final dcr = profile.generateDCR();

    final js = '''
    (async function() {
      try {
        const resp = await fetch('$_apiBase/$path', {
          method: 'POST',
          credentials: 'include',
          headers: {
            'Content-Type': 'application/json',
            'Connect-Protocol-Version': '1',
            'x-client-type': 'web',
            'x-client-id': '${profile.clientId}',
            'x-client-locale': '${profile.locale}',
            'x-client-timezone': '${profile.timezone}',
            'x-client-timezone-offset': '${profile.timezoneOffset}',
            'x-client-dcr': '$dcr',
          },
          body: '$escapedBody',
        });
        
        const text = await resp.text();
        const status = resp.status;
        
        const headers = {};
        resp.headers.forEach(function(value, key) {
          headers[key] = value;
        });
        
        ApiBridge.postMessage(JSON.stringify({
          id: $id,
          status: status,
          body: text,
          headers: headers,
        }));
      } catch(e) {
        ApiBridge.postMessage(JSON.stringify({
          id: $id,
          error: true,
          message: e.toString(),
        }));
      }
    })();
    ''';

    try {
      await _controller.runJavaScript(js);
    } catch (e) {
      _pendingCalls.remove(id);
      return {'error': true, 'message': 'Erro ao executar JS: $e'};
    }

    // Aguardar resposta com timeout
    try {
      final responseStr = await completer.future.timeout(
        const Duration(seconds: 15),
        onTimeout: () {
          _pendingCalls.remove(id);
          return jsonEncode({'error': true, 'message': 'Timeout (15s)'});
        },
      );

      final response = jsonDecode(responseStr) as Map<String, dynamic>;

      if (response['error'] == true) {
        return response;
      }

      final status = response['status'] as int? ?? 0;
      final bodyStr = response['body'] as String? ?? '';
      final headers = response['headers'] as Map<String, dynamic>? ?? {};

      if (status == 200) {
        try {
          final data = jsonDecode(bodyStr);
          return data is Map<String, dynamic> ? data : {'data': data};
        } catch (_) {
          return {'raw_body': bodyStr};
        }
      }

      // Verificar bloqueio
      if (status == 403) {
        final bodyLower = bodyStr.toLowerCase();
        if (bodyLower.contains('blocked') ||
            bodyLower.contains('user_is_blocked')) {
          return {
            'error': true,
            'blocked': true,
            'status': status,
            'message': bodyStr,
            'response_headers': headers,
          };
        }
      }

      return {
        'error': true,
        'status': status,
        'message': bodyStr,
        'response_headers': headers,
      };
    } catch (e) {
      _pendingCalls.remove(id);
      return {'error': true, 'message': 'Erro: $e'};
    }
  }

  /// Processa resposta recebida do JavaScript
  void _handleResponse(String message) {
    try {
      final data = jsonDecode(message);
      final id = data['id'] as int?;
      if (id != null && _pendingCalls.containsKey(id)) {
        _pendingCalls.remove(id)?.complete(message);
      }
    } catch (e) {
      debugPrint('[Bridge] Erro ao processar resposta: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    if (!_initialized) return const SizedBox.shrink();

    // WebView invisível (1x1 pixel, fora da tela visível)
    return SizedBox(
      width: 1,
      height: 1,
      child: Opacity(
        opacity: 0,
        child: WebViewWidget(controller: _controller),
      ),
    );
  }
}

/// Controller exposto para uso externo
class WebViewApiBridgeController {
  final WebViewApiBridgeState _state;

  WebViewApiBridgeController(this._state);

  String get clientId => _state.profile.clientId;
  DeviceProfile get profile => _state.profile;
  bool get isReady => _state.isReady;

  Future<void> activate() => _state.activate();

  Future<Map<String, dynamic>> callApi(String path,
          {Map<String, dynamic>? body}) =>
      _state.callApi(path, body: body);

  // ═══════════════════════════════════════════════════════════════════════════
  // High-level API Methods
  // ═══════════════════════════════════════════════════════════════════════════

  Future<Map<String, dynamic>> getUserInfo() =>
      callApi('user.v1.UserService/UserInfo');

  Future<Map<String, dynamic>> getAvailableCredits() =>
      callApi('user.v1.UserService/GetAvailableCredits');

  Future<Map<String, dynamic>> getUserClientConfig() => callApi(
      'user.v1.UserService/GetUserClientConfig',
      body: {'configKeys': ['USER_CLIENT_CONFIG_KEY_RECV_MARKETING_EMAIL']});

  Future<Map<String, dynamic>> getUserExperimentVars() =>
      callApi('user.v1.UserService/GetUserExperimentVars');

  Future<Map<String, dynamic>> listSessions() =>
      callApi('session.v1.SessionService/ListSessions', body: {'limit': 35});

  Future<Map<String, dynamic>> listSkills() =>
      callApi('skill.v1.SkillService/ListSkills');

  Future<Map<String, dynamic>> listTeam() =>
      callApi('team.v1.TeamService/ListTeam', body: {'page': 1, 'pageSize': 999});

  Future<Map<String, dynamic>> getNotifications() =>
      callApi('notifier.v1.NotificationService/GetNotificationListV2',
          body: {'limit': 10});

  Future<Map<String, dynamic>> checkRegion() =>
      callApi('user.v1.UserPublicService/CheckRegion');

  Future<Map<String, dynamic>> getGlobalSettings() =>
      callApi('user.v1.UserPublicService/GetGlobalSettings');

  Future<Map<String, dynamic>> getExchangeInfo() =>
      callApi('user.v1.UserPublicService/GetExchangeInfo');

  Future<Map<String, dynamic>> listProjects() =>
      callApi('session.v1.ProjectService/ListProjects', body: {'limit': 9999});

  Future<Map<String, dynamic>> listConnectors() =>
      callApi('connectors.v1.ConnectorsService/ListConnectors',
          body: {'limit': 150});

  Future<Map<String, dynamic>> getPersonalInvitationCodes() =>
      callApi('user.v1.UserService/GetPersonalInvitationCodes');

  Future<Map<String, dynamic>> getAgentEmail() =>
      callApi('user.v1.UserService/GetAgentEmail');
}
