import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:webview_flutter_android/webview_flutter_android.dart';
import 'anti_detect.dart';
import 'auth_service.dart';
import 'webview_api_bridge.dart';

// ═══════════════════════════════════════════════════════════════════════════════
// Login Screen v11 - Anti-Ban Edition
// Todas as chamadas API via WebView Bridge com DCR + fingerprint realista
// ═══════════════════════════════════════════════════════════════════════════════
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final AuthService _auth = AuthService();
  WebViewApiBridgeController? _bridgeController;
  final GlobalKey<WebViewApiBridgeState> _bridgeKey = GlobalKey();
  bool _isLoading = false;
  bool _bridgeReady = false;
  int _currentView = 0; // 0=login, 1=tokens, 2=explorer

  final Map<String, String> _stepStatus = {
    'OAuth2 Authorize': 'pending',
    'Google Login': 'pending',
    'Session Cookie': 'pending',
    'WebView Bridge': 'pending',
    'User Info': 'pending',
  };

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D0D1A),
      body: SafeArea(
        child: Stack(
          children: [
            // WebView Bridge invisível - usa o MESMO DeviceProfile do AuthService
            Positioned(
              left: -10,
              top: -10,
              child: WebViewApiBridge(
                key: _bridgeKey,
                deviceProfile: _auth.profile, // Compartilha o perfil!
                onReady: (controller) {
                  debugPrint('[Screen] Bridge pronto com DCR!');
                  setState(() {
                    _bridgeController = controller;
                    _bridgeReady = true;
                    _auth.setBridge(controller);
                  });
                },
              ),
            ),

            // Conteúdo principal
            _currentView == 0
                ? _buildLoginView()
                : _currentView == 1
                    ? _buildTokensView()
                    : _buildExplorerView(),
          ],
        ),
      ),
    );
  }

  // ── Login View ──────────────────────────────────────────────────────────────
  Widget _buildLoginView() {
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Logo
            Container(
              width: 80,
              height: 80,
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF7C3AED), Color(0xFF2563EB)],
                ),
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFF7C3AED).withOpacity(0.4),
                    blurRadius: 20,
                    offset: const Offset(0, 8),
                  ),
                ],
              ),
              child: const Icon(Icons.shield, color: Colors.white, size: 40),
            ),
            const SizedBox(height: 20),
            const Text(
              'Manus Login',
              style: TextStyle(
                color: Colors.white,
                fontSize: 28,
                fontWeight: FontWeight.bold,
                letterSpacing: -0.5,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              'v11 - Anti-Ban (DCR + Fingerprint)',
              style:
                  TextStyle(color: Colors.white.withOpacity(0.4), fontSize: 13),
            ),
            const SizedBox(height: 32),

            // Device Profile Info
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.blue.withOpacity(0.08),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.blue.withOpacity(0.2)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(Icons.fingerprint,
                          size: 14,
                          color: Colors.lightBlueAccent.withOpacity(0.7)),
                      const SizedBox(width: 6),
                      Text('DEVICE PROFILE',
                          style: TextStyle(
                              color: Colors.lightBlueAccent.withOpacity(0.7),
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 1)),
                    ],
                  ),
                  const SizedBox(height: 6),
                  _profileRow('Client ID', _auth.profile.clientId),
                  _profileRow('Locale', _auth.profile.locale),
                  _profileRow('Timezone', _auth.profile.timezone),
                  _profileRow('UA',
                      '...${_auth.profile.userAgent.substring(_auth.profile.userAgent.length - 40)}'),
                ],
              ),
            ),

            const SizedBox(height: 20),

            // Login Button
            SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton(
                onPressed: _isLoading ? null : _startWebLogin,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.white,
                  foregroundColor: Colors.black87,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12)),
                  elevation: 0,
                ),
                child: _isLoading
                    ? const SizedBox(
                        width: 20,
                        height: 20,
                        child:
                            CircularProgressIndicator(strokeWidth: 2))
                    : const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          _GoogleIcon(),
                          SizedBox(width: 10),
                          Text('Entrar com Google',
                              style: TextStyle(
                                  fontSize: 15, fontWeight: FontWeight.w600)),
                        ],
                      ),
              ),
            ),

            const SizedBox(height: 24),

            // Auth flow status
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: const Color(0xFF1A1A2E),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: const Color(0xFF2A2A4A)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('FLUXO DE AUTENTICAÇÃO',
                      style: TextStyle(
                          color: Colors.white.withOpacity(0.3),
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1.5)),
                  const SizedBox(height: 10),
                  _buildStepRow(
                      '1. OAuth2 Authorize (com DCR)',
                      _stepStatus['OAuth2 Authorize']!),
                  _buildStepRow('2. Google Login (WebView)',
                      _stepStatus['Google Login']!),
                  _buildStepRow(
                      '3. Session Cookie', _stepStatus['Session Cookie']!),
                  _buildStepRow(
                      '4. WebView Bridge (com DCR)',
                      _stepStatus['WebView Bridge']!),
                  _buildStepRow('5. User Info (via Bridge)',
                      _stepStatus['User Info']!),
                ],
              ),
            ),

            // Anti-ban info
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.green.withOpacity(0.08),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.green.withOpacity(0.2)),
              ),
              child: Row(
                children: [
                  Icon(Icons.shield,
                      size: 16,
                      color: Colors.greenAccent.withOpacity(0.7)),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'v11: x-client-dcr (César cipher)\n'
                      'TLS Chrome + cookies httpOnly + fingerprint realista',
                      style: TextStyle(
                          color: Colors.greenAccent.withOpacity(0.7),
                          fontSize: 10),
                    ),
                  ),
                ],
              ),
            ),

            // Auth logs
            if (_auth.logs.isNotEmpty) ...[
              const SizedBox(height: 16),
              Container(
                constraints: const BoxConstraints(maxHeight: 300),
                child: ListView.builder(
                  shrinkWrap: true,
                  itemCount: _auth.logs.length,
                  itemBuilder: (ctx, i) => _buildLogEntry(_auth.logs[i]),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _profileRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 1),
      child: Row(
        children: [
          SizedBox(
            width: 70,
            child: Text(label,
                style: TextStyle(
                    color: Colors.white.withOpacity(0.3),
                    fontSize: 9,
                    fontFamily: 'monospace')),
          ),
          Expanded(
            child: Text(value,
                style: TextStyle(
                    color: Colors.white.withOpacity(0.6),
                    fontSize: 9,
                    fontFamily: 'monospace'),
                overflow: TextOverflow.ellipsis),
          ),
        ],
      ),
    );
  }

  Widget _buildStepRow(String label, String status) {
    IconData icon;
    Color color;
    switch (status) {
      case 'success':
        icon = Icons.check_circle;
        color = Colors.greenAccent;
        break;
      case 'loading':
        icon = Icons.hourglass_top;
        color = Colors.amber;
        break;
      case 'error':
        icon = Icons.error;
        color = Colors.redAccent;
        break;
      default:
        icon = Icons.radio_button_unchecked;
        color = Colors.white.withOpacity(0.2);
    }

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        children: [
          Icon(icon, size: 16, color: color),
          const SizedBox(width: 8),
          Expanded(
            child: Text(label,
                style: TextStyle(
                  color:
                      status == 'success' ? color : Colors.white.withOpacity(0.6),
                  fontSize: 12,
                  fontWeight:
                      status == 'success' ? FontWeight.bold : FontWeight.normal,
                )),
          ),
        ],
      ),
    );
  }

  Widget _buildLogEntry(AuthLog log) {
    Color bgColor;
    Color iconColor;
    IconData icon;
    switch (log.status) {
      case 'success':
        bgColor = Colors.green.withOpacity(0.08);
        iconColor = Colors.greenAccent;
        icon = Icons.check_circle;
        break;
      case 'error':
        bgColor = Colors.red.withOpacity(0.08);
        iconColor = Colors.redAccent;
        icon = Icons.error;
        break;
      case 'warning':
        bgColor = Colors.amber.withOpacity(0.08);
        iconColor = Colors.amber;
        icon = Icons.warning;
        break;
      default:
        bgColor = Colors.blue.withOpacity(0.05);
        iconColor = Colors.lightBlueAccent;
        icon = Icons.info;
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 4),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
          color: bgColor, borderRadius: BorderRadius.circular(8)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Icon(icon, size: 12, color: iconColor),
            const SizedBox(width: 6),
            Expanded(
              child: Text('${log.step}: ${log.message}',
                  style: TextStyle(
                      color: Colors.white.withOpacity(0.7),
                      fontSize: 11,
                      fontFamily: 'monospace')),
            ),
          ]),
          if (log.details != null)
            Padding(
              padding: const EdgeInsets.only(top: 4, left: 18),
              child: Text(log.details.toString(),
                  style: TextStyle(
                      color: Colors.white.withOpacity(0.35),
                      fontSize: 9,
                      fontFamily: 'monospace'),
                  maxLines: 3,
                  overflow: TextOverflow.ellipsis),
            ),
        ],
      ),
    );
  }

  // ── Web Login Flow v11 ─────────────────────────────────────────────────────
  Future<void> _startWebLogin() async {
    setState(() {
      _isLoading = true;
      _auth.logs.clear();
      _stepStatus.updateAll((key, value) => 'pending');
    });

    // Step 1: Get OAuth2 Authorize URL (com DCR!)
    setState(() => _stepStatus['OAuth2 Authorize'] = 'loading');
    final redirectUrl = await _auth.getOauth2AuthorizeUrl();

    if (redirectUrl == null) {
      setState(() {
        _stepStatus['OAuth2 Authorize'] = 'error';
        _isLoading = false;
      });
      return;
    }
    setState(() => _stepStatus['OAuth2 Authorize'] = 'success');

    // Step 2: Open WebView for Google Login
    setState(() => _stepStatus['Google Login'] = 'loading');

    if (!mounted) return;
    final result = await Navigator.push<Map<String, dynamic>>(
      context,
      MaterialPageRoute(
        builder: (_) => _ManusWebLoginView(
          redirectUrl: redirectUrl,
          userAgent: _auth.profile.userAgent, // Mesmo UA!
        ),
      ),
    );

    if (result == null) {
      setState(() {
        _stepStatus['Google Login'] = 'error';
        _isLoading = false;
      });
      _auth.logs.add(AuthLog(
          step: 'Google Login',
          status: 'error',
          message: 'Login cancelado'));
      setState(() {});
      return;
    }

    setState(() => _stepStatus['Google Login'] = 'success');

    // Step 3: Process session data
    setState(() => _stepStatus['Session Cookie'] = 'loading');

    final cookies = result['cookies'] as Map<String, String>? ?? {};
    final token = result['token'] as String?;
    final finalUrl = result['finalUrl'] as String?;

    _auth.logs.add(AuthLog(
      step: 'Session',
      status: 'info',
      message: 'Dados recebidos do WebView',
      details: {
        'cookies_count': cookies.length,
        'cookie_names': cookies.keys.toList(),
        'has_token': token != null,
        'final_url': finalUrl,
      },
    ));

    if (token != null && token.isNotEmpty) {
      _auth.processSessionToken(token);
    }
    if (cookies.isNotEmpty) {
      _auth.processSessionCookies(cookies);
    }

    // Tentar extrair token da URL final
    if (!_auth.state.hasSession && finalUrl != null) {
      final uri = Uri.tryParse(finalUrl);
      if (uri != null) {
        if (uri.fragment.isNotEmpty) {
          final fragParams = Uri.splitQueryString(uri.fragment);
          for (final key in ['token', 'access_token', 'session', 'jwt']) {
            if (fragParams.containsKey(key)) {
              _auth.processSessionToken(fragParams[key]!);
              break;
            }
          }
        }
        for (final key in ['token', 'access_token', 'session', 'jwt']) {
          if (uri.queryParameters.containsKey(key)) {
            _auth.processSessionToken(uri.queryParameters[key]!);
            break;
          }
        }
      }
    }

    // Mesmo sem cookie visível, o WebView bridge terá os cookies httpOnly
    setState(() => _stepStatus['Session Cookie'] = 'success');
    _auth.logs.add(AuthLog(
      step: 'Session',
      status: 'success',
      message:
          'Cookies processados. httpOnly cookies serão usados pelo WebView Bridge.',
    ));

    // Step 4: Ativar WebView Bridge (com DCR)
    setState(() => _stepStatus['WebView Bridge'] = 'loading');
    _auth.logs.add(AuthLog(
      step: 'Bridge',
      status: 'info',
      message:
          'Ativando WebView Bridge com DCR (navegando para api.manus.im)...',
    ));

    await _bridgeKey.currentState?.activate();

    // Aguardar o bridge ficar pronto (máximo 10 segundos)
    int waitCount = 0;
    while (!_bridgeReady && waitCount < 20) {
      await Future.delayed(const Duration(milliseconds: 500));
      waitCount++;
    }

    if (_bridgeReady) {
      setState(() => _stepStatus['WebView Bridge'] = 'success');
      _auth.logs.add(AuthLog(
        step: 'Bridge',
        status: 'success',
        message:
            'WebView Bridge ativo! DCR + TLS Chrome + cookies httpOnly.',
      ));
    } else {
      setState(() => _stepStatus['WebView Bridge'] = 'error');
      _auth.logs.add(AuthLog(
        step: 'Bridge',
        status: 'error',
        message: 'Timeout ao ativar WebView Bridge',
      ));
    }

    // Step 5: Fetch User Info via Bridge
    if (_bridgeReady) {
      setState(() => _stepStatus['User Info'] = 'loading');
      await _auth.runPostLoginFlow(
        onProgress: (step, status) {
          setState(() => _stepStatus[step] = status);
        },
      );
    }

    setState(() => _isLoading = false);

    // Mudar para view de tokens
    if (_auth.state.hasUserInfo || _auth.state.hasSession) {
      setState(() => _currentView = 1);
    }
  }

  // ── Tokens View ─────────────────────────────────────────────────────────────
  Widget _buildTokensView() {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
          color: const Color(0xFF1A1A2E),
          child: Row(
            children: [
              IconButton(
                icon: const Icon(Icons.arrow_back, color: Colors.white),
                onPressed: () => setState(() => _currentView = 0),
              ),
              const Expanded(
                child: Text('Tokens & API',
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.bold)),
              ),
              IconButton(
                icon: const Icon(Icons.copy, color: Colors.white54),
                onPressed: _copyAllTokens,
                tooltip: 'Copiar',
              ),
            ],
          ),
        ),
        Expanded(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildUserCard(),
                const SizedBox(height: 16),
                _buildAuthFlowCard(),
                const SizedBox(height: 16),

                if (_auth.logs.isNotEmpty) ...[
                  Text('AUTH LOGS',
                      style: TextStyle(
                          color: Colors.white.withOpacity(0.3),
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1.5)),
                  const SizedBox(height: 8),
                  ...(_auth.logs.map(_buildLogEntry)),
                  const SizedBox(height: 16),
                ],

                Text('TOKENS',
                    style: TextStyle(
                        color: Colors.white.withOpacity(0.3),
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1.5)),
                const SizedBox(height: 8),
                ..._auth.state
                    .toTokenMap()
                    .entries
                    .map((e) => _buildTokenCard(e.key, e.value)),

                if (_auth.state.userInfo != null) ...[
                  const SizedBox(height: 16),
                  Text('USER INFO',
                      style: TextStyle(
                          color: Colors.white.withOpacity(0.3),
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1.5)),
                  const SizedBox(height: 8),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: const Color(0xFF1A1A2E),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: const Color(0xFF2A2A4A)),
                    ),
                    child: Text(
                      const JsonEncoder.withIndent('  ')
                          .convert(_auth.state.userInfo),
                      style: TextStyle(
                          color: Colors.white.withOpacity(0.6),
                          fontSize: 10,
                          fontFamily: 'monospace'),
                    ),
                  ),
                ],

                const SizedBox(height: 20),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: _bridgeReady
                        ? () => setState(() => _currentView = 2)
                        : null,
                    icon: const Icon(Icons.explore),
                    label: Text(_bridgeReady
                        ? 'API Explorer (via Bridge + DCR)'
                        : 'Bridge não pronto'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF7C3AED),
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10)),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildUserCard() {
    final isAuth = _auth.state.hasUserInfo;
    final isBlocked = _auth.state.isBlocked;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: isBlocked
              ? [const Color(0xFF5F1E1E), const Color(0xFF1A1A2E)]
              : isAuth
                  ? [const Color(0xFF1E3A5F), const Color(0xFF1A1A2E)]
                  : [const Color(0xFF3A1E1E), const Color(0xFF1A1A2E)],
        ),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: isBlocked
              ? Colors.red.withOpacity(0.5)
              : isAuth
                  ? Colors.blue.withOpacity(0.3)
                  : Colors.red.withOpacity(0.3),
        ),
      ),
      child: Row(
        children: [
          CircleAvatar(
            radius: 22,
            backgroundColor: const Color(0xFF7C3AED),
            child: Text(
              (_auth.state.googleName ??
                      _auth.state.displayName ??
                      '?')[0]
                  .toUpperCase(),
              style: const TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.bold),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  _auth.state.displayName ??
                      _auth.state.googleName ??
                      'Usuário',
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                      fontWeight: FontWeight.bold),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                Text(
                  _auth.state.googleEmail ?? '',
                  style: TextStyle(
                      color: Colors.white.withOpacity(0.5), fontSize: 12),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                if (isBlocked)
                  Text(
                    'BLOQUEADO: ${_auth.state.blockMessage ?? "403"}',
                    style: const TextStyle(
                        color: Colors.redAccent,
                        fontSize: 10,
                        fontWeight: FontWeight.bold),
                  ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: isBlocked
                  ? Colors.red.withOpacity(0.15)
                  : isAuth
                      ? Colors.green.withOpacity(0.15)
                      : Colors.amber.withOpacity(0.15),
              borderRadius: BorderRadius.circular(6),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                    isBlocked
                        ? Icons.block
                        : isAuth
                            ? Icons.check_circle
                            : Icons.warning,
                    size: 12,
                    color: isBlocked
                        ? Colors.redAccent
                        : isAuth
                            ? Colors.greenAccent
                            : Colors.amber),
                const SizedBox(width: 4),
                Text(
                    isBlocked
                        ? 'Ban'
                        : isAuth
                            ? 'Auth'
                            : 'Parcial',
                    style: TextStyle(
                        color: isBlocked
                            ? Colors.redAccent
                            : isAuth
                                ? Colors.greenAccent
                                : Colors.amber,
                        fontSize: 10,
                        fontWeight: FontWeight.bold)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAuthFlowCard() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFF1A1A2E),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFF2A2A4A)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('FLUXO DE AUTENTICAÇÃO',
              style: TextStyle(
                  color: Colors.white.withOpacity(0.3),
                  fontSize: 10,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1.5)),
          const SizedBox(height: 10),
          _buildStepRow(
              '1. OAuth2 Authorize (com DCR)',
              _stepStatus['OAuth2 Authorize']!),
          _buildStepRow(
              '2. Google Login (WebView)', _stepStatus['Google Login']!),
          _buildStepRow('3. Session Cookie', _stepStatus['Session Cookie']!),
          _buildStepRow(
              '4. WebView Bridge (com DCR)',
              _stepStatus['WebView Bridge']!),
          _buildStepRow(
              '5. User Info (via Bridge)', _stepStatus['User Info']!),
        ],
      ),
    );
  }

  Widget _buildTokenCard(String name, String value) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: const Color(0xFF1A1A2E),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: const Color(0xFF2A2A4A)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Expanded(
              child: Text(name,
                  style: const TextStyle(
                      color: Color(0xFF7C3AED),
                      fontSize: 11,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'monospace')),
            ),
            GestureDetector(
              onTap: () {
                Clipboard.setData(ClipboardData(text: value));
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                      content: Text('$name copiado!'),
                      duration: const Duration(seconds: 1)),
                );
              },
              child:
                  Icon(Icons.copy, size: 14, color: Colors.white.withOpacity(0.3)),
            ),
          ]),
          const SizedBox(height: 4),
          Text(
            value.length > 100 ? '${value.substring(0, 100)}...' : value,
            style: TextStyle(
                color: Colors.white.withOpacity(0.5),
                fontSize: 10,
                fontFamily: 'monospace'),
            maxLines: 3,
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }

  void _copyAllTokens() {
    final tokens = _auth.state.toTokenMap();
    final text =
        tokens.entries.map((e) => '${e.key}: ${e.value}').join('\n\n');
    Clipboard.setData(ClipboardData(text: text));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
          content: Text('Todos os tokens copiados!'),
          duration: Duration(seconds: 1)),
    );
  }

  // ── Explorer View ───────────────────────────────────────────────────────────
  Widget _buildExplorerView() {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
          color: const Color(0xFF1A1A2E),
          child: Row(
            children: [
              IconButton(
                icon: const Icon(Icons.arrow_back, color: Colors.white),
                onPressed: () => setState(() => _currentView = 1),
              ),
              const Expanded(
                child: Text('API Explorer',
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.bold)),
              ),
            ],
          ),
        ),
        Expanded(
          child: _bridgeController != null
              ? _ApiExplorerWidget(bridge: _bridgeController!)
              : Center(
                  child: Text('Bridge não disponível',
                      style:
                          TextStyle(color: Colors.white.withOpacity(0.3)))),
        ),
      ],
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// API Explorer Widget v11 - usa WebView Bridge com DCR
// ═══════════════════════════════════════════════════════════════════════════════
class _ApiExplorerWidget extends StatefulWidget {
  final WebViewApiBridgeController bridge;
  const _ApiExplorerWidget({required this.bridge});

  @override
  State<_ApiExplorerWidget> createState() => _ApiExplorerWidgetState();
}

class _ApiExplorerWidgetState extends State<_ApiExplorerWidget> {
  final List<_ApiCallResult> _results = [];
  bool _isLoading = false;

  static const _endpoints = [
    _EndpointInfo(
        'CheckRegion', 'user.v1.UserPublicService/CheckRegion', false),
    _EndpointInfo('GetGlobalSettings',
        'user.v1.UserPublicService/GetGlobalSettings', false),
    _EndpointInfo('GetExchangeInfo',
        'user.v1.UserPublicService/GetExchangeInfo', false),
    _EndpointInfo('UserInfo', 'user.v1.UserService/UserInfo', true),
    _EndpointInfo(
        'GetCredits', 'user.v1.UserService/GetAvailableCredits', true),
    _EndpointInfo(
        'GetClientConfig', 'user.v1.UserService/GetUserClientConfig', true),
    _EndpointInfo('GetExperimentVars',
        'user.v1.UserService/GetUserExperimentVars', true),
    _EndpointInfo(
        'ListSessions', 'session.v1.SessionService/ListSessions', true),
    _EndpointInfo('ListSkills', 'skill.v1.SkillService/ListSkills', true),
    _EndpointInfo(
        'ListProjects', 'session.v1.ProjectService/ListProjects', true),
    _EndpointInfo('ListConnectors',
        'connectors.v1.ConnectorsService/ListConnectors', true),
    _EndpointInfo('GetNotifications',
        'notifier.v1.NotificationService/GetNotificationListV2', true),
    _EndpointInfo('ListTeam', 'team.v1.TeamService/ListTeam', true),
    _EndpointInfo(
        'GetAgentEmail', 'user.v1.UserService/GetAgentEmail', true),
    _EndpointInfo('GetInviteCodes',
        'user.v1.UserService/GetPersonalInvitationCodes', true),
  ];

  Future<void> _callEndpoint(_EndpointInfo ep) async {
    setState(() => _isLoading = true);

    try {
      Map<String, dynamic>? body;
      if (ep.path.contains('ListSessions')) body = {'limit': 35};
      if (ep.path.contains('ListTeam')) {
        body = {'page': 1, 'pageSize': 999};
      }
      if (ep.path.contains('ListConnectors')) body = {'limit': 150};
      if (ep.path.contains('ListProjects')) body = {'limit': 9999};
      if (ep.path.contains('GetNotification')) body = {'limit': 10};

      final result = await widget.bridge.callApi(ep.path, body: body);
      _results.insert(
          0,
          _ApiCallResult(
            endpoint: ep.name,
            path: ep.path,
            jsonResult: result,
            timestamp: DateTime.now(),
          ));
    } catch (e) {
      _results.insert(
          0,
          _ApiCallResult(
            endpoint: ep.name,
            path: ep.path,
            jsonResult: {'error': true, 'message': e.toString()},
            timestamp: DateTime.now(),
          ));
    }

    setState(() => _isLoading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          height: 44,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            itemCount: _endpoints.length,
            itemBuilder: (ctx, i) => _buildEndpointChip(_endpoints[i]),
          ),
        ),
        if (_isLoading)
          const LinearProgressIndicator(
              color: Color(0xFF7C3AED),
              backgroundColor: Color(0xFF1A1A2E)),
        Expanded(
          child: _results.isEmpty
              ? Center(
                  child: Text(
                      'Toque em um endpoint para testar\n(via WebView Bridge + DCR)',
                      textAlign: TextAlign.center,
                      style:
                          TextStyle(color: Colors.white.withOpacity(0.3))))
              : ListView.builder(
                  padding: const EdgeInsets.all(12),
                  itemCount: _results.length,
                  itemBuilder: (ctx, i) => _buildResultCard(_results[i]),
                ),
        ),
      ],
    );
  }

  Widget _buildEndpointChip(_EndpointInfo ep) {
    return Padding(
      padding: const EdgeInsets.only(right: 6),
      child: GestureDetector(
        onTap: _isLoading ? null : () => _callEndpoint(ep),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
          decoration: BoxDecoration(
            color: const Color(0xFF1A1A2E),
            borderRadius: BorderRadius.circular(8),
            border: Border.all(
              color: ep.requiresAuth
                  ? Colors.amber.withOpacity(0.3)
                  : Colors.greenAccent.withOpacity(0.3),
            ),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(ep.requiresAuth ? Icons.lock : Icons.public,
                  size: 12,
                  color: ep.requiresAuth ? Colors.amber : Colors.greenAccent),
              const SizedBox(width: 4),
              Text(ep.name,
                  style: TextStyle(
                      color: Colors.white.withOpacity(0.8),
                      fontSize: 11,
                      fontFamily: 'monospace')),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildResultCard(_ApiCallResult result) {
    final isOk = result.isSuccess;
    final displayBody = result.displayBody;

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
        color: isOk
            ? Colors.green.withOpacity(0.06)
            : Colors.red.withOpacity(0.06),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: isOk
              ? Colors.green.withOpacity(0.2)
              : Colors.red.withOpacity(0.2),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 10, 12, 4),
            child: Row(
              children: [
                Icon(isOk ? Icons.check_circle : Icons.error,
                    size: 14,
                    color: isOk ? Colors.greenAccent : Colors.redAccent),
                const SizedBox(width: 6),
                Expanded(
                  child: Text('${result.endpoint} (Bridge+DCR)',
                      style: TextStyle(
                          color: Colors.white.withOpacity(0.9),
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'monospace')),
                ),
                GestureDetector(
                  onTap: () {
                    Clipboard.setData(ClipboardData(text: displayBody));
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                          content: Text('Copiado!'),
                          duration: Duration(seconds: 1)),
                    );
                  },
                  child: Icon(Icons.copy,
                      size: 14, color: Colors.white.withOpacity(0.3)),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 4, 12, 10),
            child: Text(displayBody,
                style: TextStyle(
                    color: Colors.white.withOpacity(0.5),
                    fontSize: 10,
                    fontFamily: 'monospace'),
                maxLines: 15,
                overflow: TextOverflow.ellipsis),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 0, 12, 8),
            child: Text(
                '${result.timestamp.hour}:${result.timestamp.minute.toString().padLeft(2, '0')}:${result.timestamp.second.toString().padLeft(2, '0')}',
                style: TextStyle(
                    color: Colors.white.withOpacity(0.2), fontSize: 9)),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// Manus Web Login WebView v11
// ═══════════════════════════════════════════════════════════════════════════════
class _ManusWebLoginView extends StatefulWidget {
  final String redirectUrl;
  final String userAgent;
  const _ManusWebLoginView(
      {required this.redirectUrl, required this.userAgent});

  @override
  State<_ManusWebLoginView> createState() => _ManusWebLoginViewState();
}

class _ManusWebLoginViewState extends State<_ManusWebLoginView> {
  late final WebViewController _controller;
  bool _loading = true;
  bool _completed = false;
  String _statusText = 'Carregando...';

  Map<String, String> _collectedCookies = {};
  String? _collectedToken;
  String? _collectedUrl;

  @override
  void initState() {
    super.initState();

    late final PlatformWebViewControllerCreationParams params;
    if (Platform.isAndroid) {
      params = AndroidWebViewControllerCreationParams();
    } else {
      params = const PlatformWebViewControllerCreationParams();
    }

    _controller = WebViewController.fromPlatformCreationParams(params)
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setUserAgent(widget.userAgent) // Mesmo UA do perfil!
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageStarted: (url) {
            setState(() {
              _loading = true;
              _statusText = 'Carregando...';
            });
            debugPrint('[WebView] Page started: $url');
            _checkForCompletion(url);
          },
          onPageFinished: (url) {
            setState(() => _loading = false);
            debugPrint('[WebView] Page finished: $url');
            _checkForCompletion(url);
          },
          onNavigationRequest: (req) {
            debugPrint('[WebView] Navigation: ${req.url}');
            _checkForCompletion(req.url);
            return NavigationDecision.navigate;
          },
          onWebResourceError: (error) {
            debugPrint('[WebView] Error: ${error.description}');
          },
        ),
      );

    if (Platform.isAndroid) {
      final androidController =
          _controller.platform as AndroidWebViewController;
      AndroidWebViewController.enableDebugging(true);
      androidController.setMediaPlaybackRequiresUserGesture(false);
    }

    _controller.addJavaScriptChannel(
      'FlutterAuth',
      onMessageReceived: (message) {
        debugPrint('[WebView] JS: ${message.message}');
        _processJsMessage(message.message);
      },
    );

    _controller.loadRequest(Uri.parse(widget.redirectUrl));
  }

  void _checkForCompletion(String url) {
    if (_completed) return;

    if (url.contains('manus.im') &&
        !url.contains('accounts.google.com') &&
        !url.contains('oauth2_callback')) {
      setState(() => _statusText = 'Login bem-sucedido! Capturando sessão...');
      Future.delayed(const Duration(milliseconds: 2000), () {
        if (!_completed && mounted) {
          _extractAndReturn();
        }
      });
    }

    if (url.contains('api.manus.im/api/oauth2_callback')) {
      setState(() => _statusText = 'Processando autenticação...');
    }
  }

  Future<void> _extractAndReturn() async {
    if (_completed) return;

    try {
      await _controller.runJavaScript('''
        (function() {
          var data = {
            cookies: document.cookie,
            url: window.location.href,
            localStorage: {},
            sessionStorage: {}
          };
          try {
            for (var i = 0; i < localStorage.length; i++) {
              var key = localStorage.key(i);
              if (key.toLowerCase().includes('token') || 
                  key.toLowerCase().includes('auth') || 
                  key.toLowerCase().includes('session') ||
                  key.toLowerCase().includes('user')) {
                data.localStorage[key] = localStorage.getItem(key);
              }
            }
          } catch(e) {}
          try {
            for (var i = 0; i < sessionStorage.length; i++) {
              var key = sessionStorage.key(i);
              if (key.toLowerCase().includes('token') || 
                  key.toLowerCase().includes('auth') || 
                  key.toLowerCase().includes('session') ||
                  key.toLowerCase().includes('user')) {
                data.sessionStorage[key] = sessionStorage.getItem(key);
              }
            }
          } catch(e) {}
          FlutterAuth.postMessage(JSON.stringify(data));
        })();
      ''');

      await Future.delayed(const Duration(milliseconds: 1500));

      _completed = true;
      if (mounted) {
        Navigator.pop(context, {
          'cookies': _collectedCookies,
          'token': _collectedToken,
          'finalUrl': _collectedUrl ?? await _controller.currentUrl(),
        });
      }
    } catch (e) {
      debugPrint('[WebView] Extract error: $e');
      if (!_completed) {
        await Future.delayed(const Duration(seconds: 2));
        if (!_completed && mounted) {
          _extractAndReturn();
        }
      }
    }
  }

  void _processJsMessage(String message) {
    try {
      final data = jsonDecode(message);
      final cookies = <String, String>{};

      final cookieStr = data['cookies'] as String? ?? '';
      _parseCookieString(cookieStr, cookies);

      final localStorage = data['localStorage'] as Map<String, dynamic>? ?? {};
      final sessionStorage =
          data['sessionStorage'] as Map<String, dynamic>? ?? {};

      String? token;
      for (final storage in [localStorage, sessionStorage]) {
        for (final entry in storage.entries) {
          if (entry.value is String && (entry.value as String).length > 20) {
            final key = entry.key.toLowerCase();
            if (key.contains('token') ||
                key.contains('auth') ||
                key.contains('jwt')) {
              token = entry.value as String;
              break;
            }
          }
        }
      }

      _collectedCookies = cookies;
      _collectedToken = token;
      _collectedUrl = data['url'] as String?;
    } catch (e) {
      debugPrint('[WebView] Parse error: $e');
    }
  }

  void _parseCookieString(String cookieStr, Map<String, String> cookies) {
    if (cookieStr.isEmpty) return;
    for (final part in cookieStr.split(';')) {
      final trimmed = part.trim();
      final eqIdx = trimmed.indexOf('=');
      if (eqIdx > 0) {
        final key = trimmed.substring(0, eqIdx).trim();
        final value = trimmed.substring(eqIdx + 1).trim();
        if (key.isNotEmpty && value.isNotEmpty) {
          cookies[key] = value;
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Login com Google'),
        backgroundColor: const Color(0xFF1A1A2E),
        leading: IconButton(
          icon: const Icon(Icons.close),
          onPressed: () => Navigator.pop(context, null),
        ),
        actions: [
          if (_loading)
            const Padding(
              padding: EdgeInsets.all(16),
              child: SizedBox(
                width: 16,
                height: 16,
                child: CircularProgressIndicator(
                    strokeWidth: 2, color: Color(0xFF7C3AED)),
              ),
            ),
        ],
      ),
      body: Column(
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            color: const Color(0xFF1A1A2E),
            child: Text(_statusText,
                style: TextStyle(
                    color: Colors.white.withOpacity(0.5), fontSize: 11)),
          ),
          Expanded(child: WebViewWidget(controller: _controller)),
        ],
      ),
    );
  }
}

// ── Helper Classes ────────────────────────────────────────────────────────────
class _EndpointInfo {
  final String name;
  final String path;
  final bool requiresAuth;
  const _EndpointInfo(this.name, this.path, this.requiresAuth);
}

class _ApiCallResult {
  final String endpoint;
  final String path;
  final Map<String, dynamic>? jsonResult;
  final DateTime timestamp;

  _ApiCallResult(
      {required this.endpoint,
      required this.path,
      this.jsonResult,
      required this.timestamp});

  bool get isSuccess => jsonResult != null && jsonResult!['error'] != true;

  String get displayBody {
    if (jsonResult != null) {
      return const JsonEncoder.withIndent('  ').convert(jsonResult);
    }
    return 'No data';
  }
}

class _GoogleIcon extends StatelessWidget {
  const _GoogleIcon();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 24,
      height: 24,
      decoration: BoxDecoration(
          color: Colors.white, borderRadius: BorderRadius.circular(4)),
      padding: const EdgeInsets.all(3),
      child: const Text('G',
          textAlign: TextAlign.center,
          style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.bold,
              color: Color(0xFF4285F4))),
    );
  }
}
