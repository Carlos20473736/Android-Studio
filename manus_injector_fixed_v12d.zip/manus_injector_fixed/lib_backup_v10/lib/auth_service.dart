import 'dart:convert';
import 'package:http/http.dart' as http;
import 'anti_detect.dart';
import 'webview_api_bridge.dart';

/// Estado da autenticação completa
class AuthState {
  String? googleEmail;
  String? googleName;
  String? googlePhotoUrl;
  String? sessionToken;
  String? sessionCookieName;
  Map<String, String> cookies = {};
  Map<String, dynamic>? userInfo;
  String? userId;
  String? displayName;
  bool isBlocked = false;
  String? blockMessage;

  bool get hasSession => sessionToken != null && sessionToken!.isNotEmpty;
  bool get hasUserInfo => userInfo != null;
  bool get isFullyAuthenticated => hasSession && hasUserInfo;

  Map<String, String> toTokenMap() {
    final map = <String, String>{};
    if (sessionToken != null) map['SESSION_TOKEN'] = sessionToken!;
    if (sessionCookieName != null) map['COOKIE_NAME'] = sessionCookieName!;
    if (googleEmail != null) map['EMAIL'] = googleEmail!;
    if (googleName != null) map['NAME'] = googleName!;
    if (userId != null) map['USER_ID'] = userId!;
    if (cookies.isNotEmpty) {
      map['ALL_COOKIES'] = cookies.entries
          .map((e) =>
              '${e.key}=${e.value.length > 50 ? '${e.value.substring(0, 50)}...' : e.value}')
          .join('; ');
    }
    return map;
  }
}

/// Log de cada etapa da autenticação
class AuthLog {
  final String step;
  final String status;
  final String message;
  final DateTime timestamp;
  final Map<String, dynamic>? details;

  AuthLog({
    required this.step,
    required this.status,
    required this.message,
    this.details,
  }) : timestamp = DateTime.now();
}

/// Serviço de autenticação v11 - Anti-Ban Edition
///
/// Diferenças do v10:
/// 1. Usa DeviceProfile consistente (mesmo clientId, UA, locale em todas as chamadas)
/// 2. Envia x-client-dcr (Device Change Record) com fingerprint cifrado
/// 3. Inclui todos os headers Sec-Ch-Ua, Sec-Fetch-* idênticos ao Chrome
/// 4. WebView Bridge herda o perfil de dispositivo
class AuthService {
  static const String _apiBase = 'https://api.manus.im';

  WebViewApiBridgeController? _bridge;
  final AuthState state = AuthState();
  final List<AuthLog> logs = [];
  late final DeviceProfile profile;

  AuthService() {
    profile = generateDeviceProfile();
  }

  void setBridge(WebViewApiBridgeController bridge) {
    _bridge = bridge;
  }

  void _log(String step, String status, String message,
      {Map<String, dynamic>? details}) {
    logs.add(AuthLog(
        step: step, status: status, message: message, details: details));
  }

  /// Step 1: Obter URL de redirect do Google OAuth
  /// Inclui x-client-dcr para não ser detectado como bot
  Future<String?> getOauth2AuthorizeUrl() async {
    _log('OAuth2 Authorize', 'info', 'Obtendo URL de redirect do Google...');
    _log('OAuth2 Authorize', 'info',
        'Client ID: ${profile.clientId}, DCR: ativo');

    try {
      // Gerar headers completos com DCR
      final headers = profile.generateHeaders(includeDCR: true);

      final resp = await http
          .post(
            Uri.parse(
                '$_apiBase/user.v1.UserAuthPublicService/Oauth2Authorize'),
            headers: headers,
            body: jsonEncode({
              'type': 'O_AUTH2_TYPE_GOOGLE',
              'authCommand': {
                'locale': profile.locale,
                'tz': profile.timezone,
                'tzOffset': profile.timezoneOffset.toString(),
                'firstEntry': '1',
              },
            }),
          )
          .timeout(const Duration(seconds: 10));

      if (resp.statusCode == 200) {
        final data = jsonDecode(resp.body);
        final redirectUrl = data['redirectUrl'] as String?;
        if (redirectUrl != null && redirectUrl.isNotEmpty) {
          _log('OAuth2 Authorize', 'success', 'URL obtida!', details: {
            'url_length': redirectUrl.length,
            'has_state': redirectUrl.contains('state='),
          });
          return redirectUrl;
        }
      }

      _log('OAuth2 Authorize', 'error',
          'Erro ${resp.statusCode}: ${resp.body}');
      return null;
    } catch (e) {
      _log('OAuth2 Authorize', 'error', 'Exceção: $e');
      return null;
    }
  }

  /// Step 2: Processar cookies recebidos após o callback do Google
  void processSessionCookies(Map<String, String> cookies) {
    state.cookies = cookies;

    if (cookies.containsKey('session_id') &&
        cookies['session_id']!.isNotEmpty) {
      state.sessionToken = cookies['session_id'];
      state.sessionCookieName = 'session_id';
      _log('Session', 'success', 'Cookie session_id encontrado', details: {
        'token_length': cookies['session_id']!.length,
      });
    } else {
      String? longestKey;
      int longestLen = 0;
      for (final entry in cookies.entries) {
        if (entry.value.length > longestLen) {
          longestLen = entry.value.length;
          longestKey = entry.key;
        }
      }
      if (longestKey != null && longestLen > 20) {
        state.sessionToken = cookies[longestKey];
        state.sessionCookieName = longestKey;
        _log('Session', 'info',
            'Usando cookie $longestKey ($longestLen chars) como sessão');
      } else {
        _log('Session', 'warning',
            'Nenhum cookie visível, mas cookies httpOnly podem estar no WebView');
      }
    }

    _log('Session', 'info', 'Cookies processados', details: {
      'total_cookies': cookies.length,
      'cookie_names': cookies.keys.toList(),
    });
  }

  void processSessionToken(String token) {
    state.sessionToken = token;
    _log('Session', 'success',
        'Token de sessão configurado (${token.length} chars)');
  }

  /// Step 3: Buscar informações do usuário VIA WEBVIEW BRIDGE
  Future<bool> fetchUserInfo() async {
    if (state.isBlocked) {
      _log('User Info', 'error', 'Conta bloqueada, não tentando novamente');
      return false;
    }

    if (_bridge == null || !_bridge!.isReady) {
      _log('User Info', 'error', 'WebView Bridge não está pronto');
      return false;
    }

    _log('User Info', 'info', 'Buscando UserInfo via WebView Bridge (com DCR)...');

    try {
      final result = await _bridge!.getUserInfo();

      if (result.containsKey('error') && result['error'] == true) {
        if (result['blocked'] == true) {
          state.isBlocked = true;
          state.blockMessage = result['message'] as String?;
          _log('User Info', 'error', 'CONTA BLOQUEADA!', details: result);
          return false;
        }
        _log('User Info', 'error', 'Erro na chamada', details: result);
        return false;
      }

      return _processUserInfoResponse(result);
    } catch (e) {
      _log('User Info', 'error', 'Exceção: $e');
      return false;
    }
  }

  bool _processUserInfoResponse(Map<String, dynamic> data) {
    state.userInfo = data;
    state.googleEmail =
        data['email'] as String? ?? state.googleEmail;
    state.googleName = data['name'] as String? ??
        data['displayName'] as String? ??
        state.googleName;
    state.userId = data['userId'] as String? ??
        data['id'] as String? ??
        data['openId'] as String?;
    state.displayName = data['displayname'] as String? ??
        data['displayName'] as String? ??
        data['name'] as String?;

    _log('User Info', 'success', 'UserInfo obtido via WebView Bridge!',
        details: {
          'email': state.googleEmail,
          'name': state.displayName,
          'userId': state.userId,
          'fields': data.keys.toList(),
        });
    return true;
  }

  /// Chamada genérica via WebView Bridge
  Future<Map<String, dynamic>?> callConnect(String servicePath,
      {Map<String, dynamic>? body}) async {
    if (state.isBlocked) {
      return {'error': true, 'message': 'Conta bloqueada.', 'blocked': true};
    }
    if (_bridge == null || !_bridge!.isReady) {
      return {'error': true, 'message': 'Bridge não está pronto'};
    }
    return _bridge!.callApi(servicePath, body: body);
  }

  Future<void> runPostLoginFlow({
    Function(String step, String status)? onProgress,
  }) async {
    onProgress?.call('User Info', 'loading');
    final userInfoOk = await fetchUserInfo();
    onProgress?.call('User Info', userInfoOk ? 'success' : 'error');
  }
}
